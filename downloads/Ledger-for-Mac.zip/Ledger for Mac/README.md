# Ledger — Payment Management & Credit Health

A lightweight administrator application for client accounts, projects, scheduled obligations, full settlements, and explainable internal credit health. The approved MVP uses USD with two decimal places and Asia/Amman as its configurable business timezone.

## Implemented

- Secure administrator login/logout, Argon2id password hashing, opaque expiring sessions, CSRF verification, and login throttling.
- Searchable/filterable accounts and projects, detail pages, edits, and archiving.
- Exact-decimal financial totals across each account's projects, with contract/schedule discrepancy flags.
- Payment scheduling, all five backend-calculated statuses, settlement, and controlled corrections.
- Append-only audit history, transactional updates, and optimistic record versions.
- The approved credit policy, including insufficient-history handling, deterioration, recovery, and explanations.
- Dashboard summaries and links to underlying records; responsive tables, dialogs, and forms.

No payment processing, partial payments, external credit reporting, or production deployment is included. Test data is created in disposable databases rather than preloaded into the application.

## Architecture

`backend/src/accounts`, `projects`, `payments`, `credit_health`, and `dashboard` are modules in one Axum application sharing PostgreSQL. Database records, API validation, payment status rules, credit policy, and audit handling have distinct responsibilities. React pages live under `frontend/src/pages`, with shared components, typed API models, and a small application shell.

See [API specification](docs/api.md), [credit policy](docs/credit-policy.md), and [validation report](docs/validation.md).

## Development setup

For a guided macOS setup without installing developer tools, see [Use Ledger on your Mac](START%20HERE%20-%20macOS.txt). The Finder launchers use `compose.mac.yaml` to run the same application stack in Docker Desktop, with a persistent local database and a browser frontend. This is separate from the developer Compose workflow below.

Requirements: Rust stable, rustfmt, Clippy, Node.js 22.12+ or 24+, Docker Compose, Python 3 for the isolated browser runner, and Chromium/Playwright for browser tests. Use the existing checkout; isolated cloud tasks do not need a Git worktree.

In this cloud machine:

```bash
export RUSTUP_HOME=/workspace/.rustup
export CARGO_HOME=/workspace/.cargo
export PATH="$CARGO_HOME/bin:$PATH"
cd /workspace/beta-repo-rust
cargo build --locked --manifest-path backend/Cargo.toml
npm ci --prefix frontend --cache /workspace/.npm-cache
```

Generate and securely retain a local database password, then initialize PostgreSQL:

```bash
export POSTGRES_PASSWORD="$(openssl rand -hex 32)"
docker compose up -d --wait
export DATABASE_URL="postgres://payment:${POSTGRES_PASSWORD}@127.0.0.1:5432/payment_health"
export APP_ORIGIN=http://localhost:5173
export COOKIE_SECURE=false
export BUSINESS_TIMEZONE=Asia/Amman
export BUSINESS_CURRENCY=USD
export BIND_ADDRESS=127.0.0.1:3000
```

Reuse the same password when restarting an existing volume; changing its environment variable does not change PostgreSQL's stored password. Hexadecimal passwords are URL-safe; encode arbitrary passwords before placing them in a connection URL. Do not commit credentials. `.env.example` documents variables; it is not loaded automatically.

Optionally retain the local database configuration privately for future shells (administrator passwords are never captured):

```bash
python3 scripts/with-dev-env.py --capture
# Later commands can reuse it without displaying values:
python3 scripts/with-dev-env.py docker compose up -d --wait
python3 scripts/with-dev-env.py cargo run --locked --manifest-path backend/Cargo.toml
python3 scripts/with-dev-env.py python3 scripts/check-e2e.py
```

This saves a mode-600 file under the ignored `.local` directory and refuses to overwrite an existing file. Explicit environment bindings override retained values. Do not add `.local` to Git.

Provision an administrator without putting a password in shell history:

```bash
read -r -p 'Administrator email: ' ADMIN_EMAIL
read -r -s -p 'Administrator password (at least 12 bytes): ' ADMIN_PASSWORD
printf '\n'
export ADMIN_EMAIL ADMIN_PASSWORD
cargo run --locked --manifest-path backend/Cargo.toml -- provision-admin
unset ADMIN_PASSWORD ADMIN_EMAIL
```

Provisioning applies migrations and inserts an administrator. Duplicate emails fail; existing passwords are not silently overwritten.

Start the backend and frontend in separate shells:

```bash
# Shell 1, with the configuration above
cargo run --locked --manifest-path backend/Cargo.toml

# Shell 2
npm run dev --prefix frontend
```

For local development, use localhost port 5173, matching `APP_ORIGIN`. Vite forwards `/api` to Axum on loopback port 3000. Its server-side `API_PROXY_TARGET` override is used by isolated tests, not as a browser-exposed credential. The onboarding UI does not provide a localhost preview.

Readiness:

```bash
curl --fail http://127.0.0.1:3000/api/v1/health
```

The result should have `data.status: "ok"` and `data.business_timezone: "Asia/Amman"`. It queries the actual database. Startup applies migrations and verifies already-applied migration checksums.

## Validation commands

With the local `DATABASE_URL` configured:

```bash
cargo fmt --manifest-path backend/Cargo.toml --check
cargo test --locked --manifest-path backend/Cargo.toml
cargo clippy --locked --manifest-path backend/Cargo.toml --all-targets -- -D warnings
npm run build --prefix frontend
npm test --prefix frontend
npm run format:check --prefix frontend
npm audit --prefix frontend --cache /workspace/.npm-cache
python3 scripts/check-e2e.py
```

SQLx tests need permission to create temporary databases. The Compose role has this permission; production application credentials must not. The browser runner creates its own database and random administrator, starts isolated servers on ports 3001/5174, runs real Chromium checks, exercises backup/restore, and removes only its temporary databases and processes. Use it only with the local Compose database. It does not modify your business records or require your administrator password.

System Chromium is detected in this cloud machine. Elsewhere install Playwright Chromium or set `PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH`. Browser traces are disabled to avoid recording credentials. Test/server outputs are ignored by Git.

## Security and production deployment

The eight-hour session cookie is HttpOnly, SameSite=Strict, and Secure by default. Token hashes are stored in the database; the tab retains its CSRF token in sessionStorage. Logout revokes its session; expired/inactive users cannot retrieve business data. Login allows 30 attempts per minute globally per process and resets on restart. Add trusted proxy-level limits for a public deployment.

Build the frontend and release backend, then serve both under one HTTPS origin. Set `APP_ORIGIN` to that exact origin, `COOKIE_SECURE=true`, `BUSINESS_CURRENCY=USD`, and your production `DATABASE_URL`. Axum binds to loopback behind the reverse proxy. [The Caddy template](deploy/Caddyfile) routes `/api` to Axum and serves `frontend/dist`; supply a real hostname and place the built files in its configured directory. Public hosting, TLS issuance, and production credentials have not been configured or tested.

The development Compose database is loopback-only and uses a privileged development role. Production needs a restricted runtime role, controlled migrations, protected database transport, and encrypted backups. Grant runtime access to domain/session tables as needed, and INSERT/SELECT on audit records; do not grant audit UPDATE/DELETE or schema ownership. Run the `migrate` command with migration-role credentials, then use `MIGRATE_ON_START=false` with the restricted runtime role. In that mode startup only reads migration versions/checksums and refuses missing, changed, failed, or newer migrations. Grant SELECT on `_sqlx_migrations` to the runtime role.

Back up PostgreSQL with `pg_dump -Fc`; restore with `pg_restore --exit-on-error --no-owner` into a separate database before switching traffic. Protect backup artifacts because they contain client records and password hashes. The automated runner verifies fixture record counts, audit counts, and exact settled totals after restoration. This local rehearsal does not establish production backup retention or disaster recovery.
