#!/bin/bash
source "$(cd "$(dirname "$0")" && pwd)/scripts/mac-common.sh"
ledger_docker
ledger_config
if ! ledger_compose exec -T db pg_isready -U payment -d payment_health </dev/null >/dev/null 2>&1; then
    printf 'Start Ledger first, then run this backup launcher again.\n'
    ledger_error
fi
mkdir -p "$LEDGER_ROOT/backups"
chmod 700 "$LEDGER_ROOT/backups"
LEDGER_BACKUP="$(mktemp "$LEDGER_ROOT/backups/Ledger-$(date +%Y-%m-%d-%H%M%S)-XXXXXX")"
if ledger_compose exec -T db pg_dump -U payment -d payment_health -Fc </dev/null > "$LEDGER_BACKUP"; then
    mv "$LEDGER_BACKUP" "$LEDGER_BACKUP.dump"
    printf '\nBackup saved in the backups folder:\n%s.dump\n' "$(basename "$LEDGER_BACKUP")"
    printf 'Keep a copy somewhere safe. Backups contain private account and payment records.\n'
    if [ "$(uname -s)" = Darwin ]; then
        open "$LEDGER_ROOT/backups"
    fi
else
    rm -f "$LEDGER_BACKUP"
    ledger_error
fi
ledger_pause
