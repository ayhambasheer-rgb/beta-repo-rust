import { test, expect } from "@playwright/test";

test("accounts, projects, installments, settlements, corrections, and credit recovery", async ({
  page,
}) => {
  test.setTimeout(120_000);
  const email = process.env.E2E_ADMIN_EMAIL,
    password = process.env.E2E_ADMIN_PASSWORD;
  if (!email || !password)
    throw new Error("Set test administrator credentials.");
  await page.goto("/");
  await page.getByLabel("Email address").fill(email);
  await page.getByLabel("Password", { exact: true }).fill(password);
  await page.getByRole("button", { name: "Sign in", exact: true }).click();
  await expect(
    page.getByRole("heading", { name: "Dashboard", exact: true }),
  ).toBeVisible();
  const settings = (await (await page.request.get("/api/v1/settings")).json())
    .data;
  const relative = (days: number) =>
    new Date(
      new Date(`${settings.business_date}T12:00:00Z`).getTime() +
        days * 86400000,
    )
      .toISOString()
      .slice(0, 10);
  await page.getByRole("button", { name: "Accounts", exact: true }).click();
  await page
    .getByRole("button", { name: "Create account", exact: true })
    .click();
  let dialog = page.getByRole("dialog");
  await dialog.getByLabel("Account name").fill("E2E client");
  await dialog.getByLabel("Contact name").fill("Taylor Client");
  await dialog.getByLabel("Email address").fill("client@example.test");
  await dialog.getByLabel("Phone number").fill("+1 555 0100");
  await dialog.getByRole("button", { name: "Save record" }).click();
  await expect(
    page.getByRole("heading", { name: "E2E client", exact: true }),
  ).toBeVisible();
  const accountId = (await page.evaluate(() => location.hash)).split("/")[2];
  await expect(page.getByText("Unrated", { exact: true })).toBeVisible();
  await page
    .getByRole("button", { name: "Create project", exact: true })
    .click();
  dialog = page.getByRole("dialog");
  await dialog.getByLabel("Project name").fill("Initial engagement");
  await dialog.getByLabel("Contract value (USD)").fill("100.00");
  await dialog.getByRole("button", { name: "Save record" }).click();
  await expect(
    page.getByRole("heading", { name: "Initial engagement", exact: true }),
  ).toBeVisible();
  await page
    .getByRole("button", { name: "Schedule payment", exact: true })
    .click();
  dialog = page.getByRole("dialog");
  await dialog.getByLabel("Payment title").fill("Late installment");
  await dialog.getByLabel("Amount (USD)").fill("100.00");
  await dialog.getByLabel("Due date", { exact: true }).fill(relative(-10));
  await dialog.getByRole("button", { name: "Save record" }).click();
  await expect(
    page.getByRole("heading", { name: "Late installment", exact: true }),
  ).toBeVisible();
  await expect(page.getByText("Overdue", { exact: true })).toBeVisible();
  await page
    .getByRole("button", { name: "Record settlement", exact: true })
    .click();
  await page
    .getByRole("dialog")
    .getByRole("button", { name: "Record settlement", exact: true })
    .click();
  await expect(page.getByRole("dialog")).not.toBeVisible();
  await expect(page.getByText("Paid Late", { exact: true })).toBeVisible();
  await page
    .getByRole("button", { name: "Correct payment", exact: true })
    .click();
  dialog = page.getByRole("dialog");
  await dialog.getByLabel("Payment title").fill("Corrected installment");
  await dialog.getByLabel("Amount (USD)").fill("90.00");
  await dialog
    .getByLabel("Reason for change")
    .fill("Corrected agreed installment amount");
  await dialog.getByRole("button", { name: "Save correction" }).click();
  await expect(
    page.getByRole("heading", { name: "Corrected installment", exact: true }),
  ).toBeVisible();
  await expect(
    page.getByText("Corrected agreed installment amount", { exact: true }),
  ).toBeVisible();
  await page.getByRole("button", { name: "View project", exact: true }).click();
  await expect(
    page.getByText(/Scheduled payments differ from the contract by USD -10.00/),
  ).toBeVisible();
  await page.getByRole("button", { name: "Edit project", exact: true }).click();
  dialog = page.getByRole("dialog");
  await dialog.getByLabel("Contract value (USD)").fill("90.00");
  await dialog
    .getByLabel("Reason for change")
    .fill("Contract adjusted to corrected schedule");
  await dialog.getByRole("button", { name: "Save record" }).click();
  await expect(
    page.getByText("Contract adjusted to corrected schedule", { exact: true }),
  ).toBeVisible();
  await expect(
    page.getByText(/Scheduled payments differ from the contract/),
  ).not.toBeVisible();
  await page
    .getByRole("button", { name: "View account: E2E client", exact: true })
    .click();
  await page
    .getByRole("button", { name: "Create project", exact: true })
    .click();
  dialog = page.getByRole("dialog");
  await dialog.getByLabel("Project name").fill("Recovery engagement");
  await dialog.getByLabel("Contract value (USD)").fill("90.00");
  await dialog.getByRole("button", { name: "Save record" }).click();
  await expect(
    page.getByRole("heading", { name: "Recovery engagement", exact: true }),
  ).toBeVisible();
  const projectId = (await page.evaluate(() => location.hash)).split("/")[2];
  for (let index = 0; index < 3; index++) {
    await page
      .getByRole("button", { name: "Schedule payment", exact: true })
      .click();
    dialog = page.getByRole("dialog");
    await dialog
      .getByLabel("Payment title")
      .fill(`On-time installment ${index + 1}`);
    await dialog.getByLabel("Amount (USD)").fill("10.00");
    await dialog
      .getByLabel("Due date", { exact: true })
      .fill(relative(-8 + index));
    await dialog.getByRole("button", { name: "Save record" }).click();
    await expect(
      page.getByRole("heading", {
        name: `On-time installment ${index + 1}`,
        exact: true,
      }),
    ).toBeVisible();
    await page
      .getByRole("button", { name: "Record settlement", exact: true })
      .click();
    dialog = page.getByRole("dialog");
    await dialog
      .getByLabel("Actual settlement date")
      .fill(relative(-8 + index - (index === 0 ? 1 : 0)));
    await dialog
      .getByRole("button", { name: "Record settlement", exact: true })
      .click();
    await expect(page.getByText("Paid On Time", { exact: true })).toBeVisible();
    await page
      .getByRole("button", { name: "View project", exact: true })
      .click();
    await expect(
      page.getByRole("heading", { name: "Recovery engagement", exact: true }),
    ).toBeVisible();
  }
  let health = (
    await (
      await page.request.get(`/api/v1/accounts/${accountId}/credit-health`)
    ).json()
  ).data;
  expect(health.classification).toBe("RECOVERING");
  expect(health.recovery_streak).toBe(3);
  const csrf = await page.evaluate(() => sessionStorage.getItem("csrf")!);
  const headers = {
    Origin: new URL(process.env.E2E_BASE_URL ?? "http://localhost:5173").origin,
    "X-CSRF-Token": csrf,
  };
  for (let offset = -5; offset <= 0; offset++) {
    const created = await page.request.post("/api/v1/payments", {
      headers,
      data: {
        project_id: projectId,
        title: `Recovery fixture ${offset}`,
        amount: "10.00",
        currency: "USD",
        due_date: relative(offset),
      },
    });
    expect(created.status()).toBe(201);
    const payment = (await created.json()).data;
    const settled = await page.request.post(
      `/api/v1/payments/${payment.id}/settlement`,
      { headers, data: { version: 1, settlement_date: relative(offset) } },
    );
    expect(settled.status()).toBe(200);
  }
  health = (
    await (
      await page.request.get(`/api/v1/accounts/${accountId}/credit-health`)
    ).json()
  ).data;
  expect(health.classification).toBe("HEALTHY");
  expect(health.historical_late_count).toBe(1);
  expect(health.on_time_rate).toBe("90.00");
  await page.getByRole("button", { name: "Dashboard", exact: true }).click();
  await page.screenshot({
    path: "test-results/dashboard-desktop.png",
    fullPage: true,
  });
  await expect(page.getByRole("button", { name: /Collected/ })).toContainText(
    "USD 180.00",
  );
  await page.getByRole("button", { name: /Collected/ }).click();
  await expect(
    page.getByRole("heading", { name: "Payments", exact: true }),
  ).toBeVisible();
  await expect(page.getByLabel("Payment status filter")).toHaveValue("SETTLED");
  await page.getByLabel("Payment status filter").selectOption("PAID_LATE");
  await expect(
    page.getByRole("button", { name: "Corrected installment", exact: true }),
  ).toBeVisible();
  await expect(page.getByText("1 record · Page 1 of 1")).toBeVisible();
  await page.setViewportSize({ width: 390, height: 844 });
  await page.screenshot({ path: "test-results/workflow-mobile.png" });
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= window.innerWidth,
    ),
  ).toBe(true);
  await page.getByRole("button", { name: "Sign out", exact: true }).click();
  await expect(
    page.getByRole("heading", { name: "Welcome back" }),
  ).toBeVisible();
  expect((await page.request.get("/api/v1/accounts")).status()).toBe(401);
});
