import { useEffect, useState, type FormEvent } from "react";
import { ArrowUpRight, ShieldCheck, Wallet } from "lucide-react";
import Workspace from "./Workspace";
import { Button } from "./components/ui/button";
import { request, type User } from "./api";
export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  useEffect(() => {
    if (!sessionStorage.getItem("csrf")) {
      setLoading(false);
      return;
    }
    request<User>("/auth/me")
      .then(setUser)
      .catch(() => sessionStorage.removeItem("csrf"))
      .finally(() => setLoading(false));
  }, []);
  useEffect(() => {
    const expired = () => {
      sessionStorage.removeItem("csrf");
      setUser(null);
      setError("Your session expired. Sign in again.");
    };
    window.addEventListener("session-expired", expired);
    return () => window.removeEventListener("session-expired", expired);
  }, []);
  async function login(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError("");
    const form = new FormData(event.currentTarget);
    try {
      const data = await request<User & { csrf_token: string }>("/auth/login", {
        method: "POST",
        body: JSON.stringify({
          email: form.get("email"),
          password: form.get("password"),
        }),
      });
      sessionStorage.setItem("csrf", data.csrf_token);
      setUser(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to sign in.");
    } finally {
      setBusy(false);
    }
  }
  async function logout() {
    setBusy(true);
    setError("");
    try {
      await request("/auth/logout", {
        method: "POST",
        headers: { "X-CSRF-Token": sessionStorage.getItem("csrf") ?? "" },
      });
      sessionStorage.removeItem("csrf");
      setUser(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to sign out.");
    } finally {
      setBusy(false);
    }
  }
  if (loading)
    return (
      <main className="grid min-h-screen place-items-center" role="status">
        Loading your workspace…
      </main>
    );
  if (!user)
    return (
      <main className="login-layout">
        <section className="login-story">
          <a className="brand" href="/">
            <Wallet size={26} />
            <span>
              ledger<span className="brand-dot">.</span>
            </span>
          </a>
          <div>
            <p className="eyebrow">PAYMENT MANAGEMENT</p>
            <h1>
              Clarity for every
              <br />
              commitment.
            </h1>
            <p className="story-copy">
              One place for your client accounts, payment schedules, and
              financial relationships.
            </p>
            <div className="story-rule" />
            <p className="story-note">
              A simpler view of what’s due.
              <br />A clearer understanding of who’s on track.
            </p>
          </div>
          <p className="story-footer">
            Built around reliable records and responsible access.
          </p>
        </section>
        <section className="login-form-panel">
          <div className="login-form">
            <span className="access-label">
              <ShieldCheck size={16} /> ADMINISTRATOR ACCESS
            </span>
            <h2>Welcome back</h2>
            <p className="muted">Sign in to your payment workspace.</p>
            <form onSubmit={login}>
              <label htmlFor="email">Email address</label>
              <input
                id="email"
                name="email"
                type="email"
                autoComplete="username"
                placeholder="you@company.com"
                required
                maxLength={254}
              />
              <label htmlFor="password">Password</label>
              <input
                id="password"
                name="password"
                type="password"
                autoComplete="current-password"
                required
                maxLength={1024}
              />
              {error && (
                <p className="error" role="alert">
                  {error}
                </p>
              )}
              <Button className="w-full mt-6" disabled={busy}>
                {busy ? "Signing in…" : "Sign in"}
                <ArrowUpRight size={16} />
              </Button>
            </form>
            <p className="access-note">
              <ShieldCheck size={16} /> Access is restricted to authorized
              administrators.
            </p>
          </div>
          <p className="login-bottom">
            Internal payment discipline insights. No external credit reporting.
          </p>
        </section>
      </main>
    );
  return <Workspace user={user} onLogout={logout} busy={busy} error={error} />;
}
