import { useEffect, useState } from "react";
import { Plus } from "lucide-react";
import { Button } from "../components/ui/button";
import {
  Badge,
  date,
  Feedback,
  FinancialCards,
  label,
  money,
  PageHeading,
  Pagination,
} from "../components/common";
import { Toolbar, ProjectTable, AuditPanel } from "../components/record-tables";
import { PaymentTable } from "../components/payment-table";
import { all, api, get, useData } from "../data";
import type { Account, Project, Payment, Page } from "../types";
import type { Navigate, Open, Route, Handlers } from "../navigation";
export function ProjectsList({
  revision,
  route,
  nav,
  open,
}: {
  revision: number;
  route: Route;
  nav: Navigate;
  open: Open;
}) {
  const [search, setSearch] = useState(""),
    [status, setStatus] = useState(route.filter ?? ""),
    [accountId, setAccountId] = useState(route.accountId ?? ""),
    [page, setPage] = useState(1);
  useEffect(() => {
    setStatus(route.filter ?? "");
    setAccountId(route.accountId ?? "");
    setPage(1);
  }, [route.filter, route.accountId]);
  const choices = useData(() => all<Account>("/accounts"), [revision]);
  const query = new URLSearchParams({ page: String(page), search });
  if (status) query.set("status", status);
  if (accountId) query.set("account_id", accountId);
  const data = useData(
    () => api<Page<Project>>(`/projects?${query}`),
    [revision, search, status, accountId, page],
  );
  return (
    <>
      <PageHeading
        title="Projects"
        description="Contracts, installment schedules, and financial progress."
        action={
          <Button onClick={() => open("project")}>
            <Plus size={16} />
            Create project
          </Button>
        }
      />
      <section className="panel">
        <Toolbar
          search={search}
          onSearch={(v) => {
            setSearch(v);
            setPage(1);
          }}
        >
          <select
            aria-label="Project status filter"
            value={status}
            onChange={(e) => {
              setStatus(e.target.value);
              setPage(1);
            }}
          >
            <option value="">All statuses</option>
            {["planned", "active", "completed", "archived"].map((s) => (
              <option key={s} value={s}>
                {label(s)}
              </option>
            ))}
          </select>
          <select
            aria-label="Account filter"
            value={accountId}
            onChange={(e) => {
              setAccountId(e.target.value);
              setPage(1);
            }}
          >
            <option value="">All accounts</option>
            {choices.data?.map((a) => (
              <option key={a.id} value={a.id}>
                {a.name}
              </option>
            ))}
          </select>
        </Toolbar>
        <Feedback loading={data.loading} error={data.error}>
          {data.data && (
            <>
              <ProjectTable projects={data.data.data} nav={nav} />
              <Pagination
                page={page}
                total={data.data.meta.total}
                onPage={setPage}
              />
            </>
          )}
        </Feedback>
      </section>
    </>
  );
}
export function ProjectDetail({
  id,
  revision,
  nav,
  open,
  handlers,
}: {
  id: string;
  revision: number;
  nav: Navigate;
  open: Open;
  handlers: Omit<Handlers, "payments">;
}) {
  const data = useData(() => get<Project>(`/projects/${id}`), [id, revision]);
  const [page, setPage] = useState(1);
  useEffect(() => setPage(1), [id]);
  const payments = useData(
    () => api<Page<Payment>>(`/payments?project_id=${id}&page=${page}`),
    [id, revision, page],
  );
  return (
    <Feedback loading={data.loading} error={data.error}>
      {data.data && (
        <>
          <PageHeading
            title={data.data.name}
            description={
              data.data.description ||
              "Project information and scheduled obligations."
            }
            back={() => nav({ section: "Projects" })}
            action={
              <Button
                variant="ghost"
                onClick={() => open("project", data.data!)}
              >
                Edit project
              </Button>
            }
          />
          <div className="project-overview">
            <button
              className="text-link"
              aria-label={`View account: ${data.data.account_name}`}
              onClick={() =>
                nav({ section: "Accounts", id: data.data!.account_id })
              }
            >
              {data.data.account_name}
            </button>
            <Badge value={data.data.status} />
            <span>
              {date(data.data.start_date)}
              {data.data.end_date ? ` – ${date(data.data.end_date)}` : ""}
            </span>
          </div>
          <FinancialCards
            financial={data.data.financial}
            contracted={[
              {
                currency: data.data.currency,
                amount: data.data.contract_value,
              },
            ]}
          />
          {!data.data.schedule_matches_contract && (
            <div className="notice warning">
              Scheduled payments differ from the contract by{" "}
              {money(data.data.schedule_difference, data.data.currency)}. Review
              the schedule; records have not been adjusted automatically.
            </div>
          )}
          <section className="panel">
            <div className="panel-heading">
              <h2>Payment schedule</h2>
              <Button
                disabled={data.data.status === "archived"}
                onClick={() => open("payment", undefined, { projectId: id })}
              >
                <Plus size={16} />
                Schedule payment
              </Button>
            </div>
            <Feedback loading={payments.loading} error={payments.error}>
              {payments.data && (
                <>
                  <PaymentTable payments={payments.data.data} {...handlers} />
                  <Pagination
                    page={page}
                    total={payments.data.meta.total}
                    onPage={setPage}
                  />
                </>
              )}
            </Feedback>
          </section>
          <AuditPanel
            path={`/projects/${id}/history`}
            revision={revision}
            title="Project history"
          />
        </>
      )}
    </Feedback>
  );
}
