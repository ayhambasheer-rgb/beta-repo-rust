import { useEffect, useState } from "react";
import { Plus } from "lucide-react";
import { Button } from "../components/ui/button";
import {
  Badge,
  date,
  Feedback,
  label,
  money,
  PageHeading,
  Pagination,
} from "../components/common";
import { Toolbar, AuditPanel } from "../components/record-tables";
import { PaymentTable } from "../components/payment-table";
import { all, api, get, useData } from "../data";
import type { Account, Project, Payment, Page } from "../types";
import { paymentStatuses } from "../types";
import type { Navigate, Open, Route, Handlers } from "../navigation";
export function PaymentsList({
  revision,
  route,
  nav,
  open,
  handlers,
}: {
  revision: number;
  route: Route;
  nav: Navigate;
  open: Open;
  handlers: Omit<Handlers, "payments">;
}) {
  const [search, setSearch] = useState(""),
    [status, setStatus] = useState(route.filter ?? ""),
    [accountId, setAccountId] = useState(route.accountId ?? ""),
    [projectId, setProjectId] = useState(route.projectId ?? ""),
    [from, setFrom] = useState(""),
    [to, setTo] = useState(""),
    [page, setPage] = useState(1);
  useEffect(() => {
    setStatus(route.filter ?? "");
    setAccountId(route.accountId ?? "");
    setProjectId(route.projectId ?? "");
    setPage(1);
  }, [route.filter, route.accountId, route.projectId]);
  const choices = useData(
    async () => ({
      accounts: await all<Account>("/accounts"),
      projects: await all<Project>("/projects"),
    }),
    [revision],
  );
  const query = new URLSearchParams({ page: String(page), search });
  if (status === "UNPAID" || status === "SETTLED")
    query.set("settlement_status", status.toLowerCase());
  else if (status) query.set("status", status);
  if (accountId) query.set("account_id", accountId);
  if (projectId) query.set("project_id", projectId);
  if (from) query.set("date_from", from);
  if (to) query.set("date_to", to);
  const data = useData(
    () => api<Page<Payment>>(`/payments?${query}`),
    [revision, search, status, accountId, projectId, from, to, page],
  );
  return (
    <>
      <PageHeading
        title="Payments"
        description="Every obligation, its due date, and its settlement history."
        action={
          <Button onClick={() => open("payment")}>
            <Plus size={16} />
            Schedule payment
          </Button>
        }
      />
      <section className="panel">
        <Toolbar
          search={search}
          onSearch={(v) => {
            setSearch(v);
            setPage(1);
          }}
        >
          <select
            aria-label="Payment status filter"
            value={status}
            onChange={(e) => {
              setStatus(e.target.value);
              setPage(1);
            }}
          >
            <option value="">All payment statuses</option>
            {[...paymentStatuses, "UNPAID", "SETTLED"].map((s) => (
              <option key={s} value={s}>
                {label(s)}
              </option>
            ))}
          </select>
          <select
            aria-label="Account filter"
            value={accountId}
            onChange={(e) => {
              setAccountId(e.target.value);
              setProjectId("");
              setPage(1);
            }}
          >
            <option value="">All accounts</option>
            {choices.data?.accounts.map((a) => (
              <option key={a.id} value={a.id}>
                {a.name}
              </option>
            ))}
          </select>
          <select
            aria-label="Project filter"
            value={projectId}
            onChange={(e) => {
              setProjectId(e.target.value);
              setPage(1);
            }}
          >
            <option value="">All projects</option>
            {choices.data?.projects
              .filter((p) => !accountId || p.account_id === accountId)
              .map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
          </select>
        </Toolbar>
        <div className="date-filters">
          <label>
            Due from
            <input
              type="date"
              value={from}
              onChange={(e) => {
                setFrom(e.target.value);
                setPage(1);
              }}
            />
          </label>
          <label>
            Due through
            <input
              type="date"
              value={to}
              onChange={(e) => {
                setTo(e.target.value);
                setPage(1);
              }}
            />
          </label>
          {(route.accountId || route.projectId) && (
            <Button
              variant="ghost"
              onClick={() => nav({ section: "Payments" })}
            >
              Clear linked filters
            </Button>
          )}
        </div>
        <Feedback loading={data.loading} error={data.error}>
          {data.data && (
            <>
              <PaymentTable payments={data.data.data} {...handlers} />
              <Pagination
                page={page}
                total={data.data.meta.total}
                onPage={setPage}
              />
            </>
          )}
        </Feedback>
      </section>
    </>
  );
}
export function PaymentDetail({
  id,
  revision,
  nav,
  open,
}: {
  id: string;
  revision: number;
  nav: Navigate;
  open: Open;
}) {
  const data = useData(() => get<Payment>(`/payments/${id}`), [id, revision]);
  return (
    <Feedback loading={data.loading} error={data.error}>
      {data.data && (
        <>
          <PageHeading
            title={data.data.title}
            description={`${data.data.account_name} · ${data.data.project_name}`}
            back={() => nav({ section: "Payments" })}
            action={
              <div className="heading-actions">
                <Button
                  variant="ghost"
                  onClick={() => open("correction", data.data!)}
                >
                  Correct payment
                </Button>
                {!data.data.settlement_date && (
                  <Button onClick={() => open("settlement", data.data!)}>
                    Record settlement
                  </Button>
                )}
              </div>
            }
          />
          <section className="panel payment-overview">
            <div>
              <span className="stat-label">Obligation amount</span>
              <h2>{money(data.data.amount, data.data.currency)}</h2>
            </div>
            <div>
              <span className="stat-label">Due date</span>
              <strong>{date(data.data.due_date)}</strong>
            </div>
            <div>
              <span className="stat-label">Settlement date</span>
              <strong>
                {data.data.settlement_date
                  ? date(data.data.settlement_date)
                  : "Not settled"}
              </strong>
            </div>
            <Badge value={data.data.status} />
          </section>
          <div className="project-overview">
            <button
              className="text-link"
              aria-label={`View account: ${data.data.account_name}`}
              onClick={() =>
                nav({ section: "Accounts", id: data.data!.account_id })
              }
            >
              View account
            </button>
            <button
              className="text-link"
              onClick={() =>
                nav({ section: "Projects", id: data.data!.project_id })
              }
            >
              View project
            </button>
          </div>
          <AuditPanel
            path={`/payments/${id}/history`}
            revision={revision}
            title="Payment history"
          />
        </>
      )}
    </Feedback>
  );
}
