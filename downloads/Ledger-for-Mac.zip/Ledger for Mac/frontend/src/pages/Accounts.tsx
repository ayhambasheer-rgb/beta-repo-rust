import { useEffect, useState } from "react";
import { Plus, ArrowUpRight } from "lucide-react";
import { Button } from "../components/ui/button";
import {
  Badge,
  Empty,
  Feedback,
  FinancialCards,
  HealthPanel,
  label,
  money,
  PageHeading,
  Pagination,
} from "../components/common";
import { Toolbar, ProjectTable, AuditPanel } from "../components/record-tables";
import { PaymentTable } from "../components/payment-table";
import { api, get, useData } from "../data";
import type { Account, Project, Payment, Page } from "../types";
import { healthClasses } from "../types";
import type { Navigate, Open, Handlers } from "../navigation";
export function AccountsList({
  revision,
  filter,
  nav,
  open,
}: {
  revision: number;
  filter?: string;
  nav: Navigate;
  open: Open;
}) {
  const [search, setSearch] = useState(""),
    [status, setStatus] = useState(""),
    [health, setHealth] = useState(filter ?? ""),
    [page, setPage] = useState(1);
  useEffect(() => {
    setHealth(filter ?? "");
    setPage(1);
  }, [filter]);
  const query = new URLSearchParams({ page: String(page), search });
  if (status) query.set("status", status);
  if (health) query.set("credit_health", health);
  const data = useData(
    () => api<Page<Account>>(`/accounts?${query}`),
    [revision, search, status, health, page],
  );
  return (
    <>
      <PageHeading
        title="Accounts"
        description="Your client relationships, balances, and payment discipline."
        action={
          <Button onClick={() => open("account")}>
            <Plus size={16} />
            Create account
          </Button>
        }
      />
      <section className="panel">
        <Toolbar
          search={search}
          onSearch={(v) => {
            setSearch(v);
            setPage(1);
          }}
        >
          <select
            aria-label="Account status filter"
            value={status}
            onChange={(e) => {
              setStatus(e.target.value);
              setPage(1);
            }}
          >
            <option value="">All statuses</option>
            <option value="active">Active</option>
            <option value="archived">Archived</option>
          </select>
          <select
            aria-label="Credit health filter"
            value={health}
            onChange={(e) => {
              setHealth(e.target.value);
              setPage(1);
            }}
          >
            <option value="">All credit health</option>
            {healthClasses.map((s) => (
              <option key={s} value={s}>
                {label(s)}
              </option>
            ))}
          </select>
        </Toolbar>
        <Feedback loading={data.loading} error={data.error}>
          {data.data &&
            (data.data.data.length ? (
              <>
                <div className="table-scroll">
                  <table>
                    <thead>
                      <tr>
                        <th>Account</th>
                        <th>Contact</th>
                        <th>Projects</th>
                        <th className="number-cell">Outstanding</th>
                        <th>Credit health</th>
                        <th>Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {data.data.data.map((a) => (
                        <tr key={a.id}>
                          <td>
                            <button
                              className="record-link"
                              onClick={() =>
                                nav({ section: "Accounts", id: a.id })
                              }
                            >
                              {a.name}
                            </button>
                            <small>{a.email}</small>
                          </td>
                          <td>{a.contact_name}</td>
                          <td>{a.project_count}</td>
                          <td className="number-cell">
                            {a.financial.length
                              ? a.financial.map((f) => (
                                  <div key={f.currency}>
                                    {money(f.outstanding, f.currency)}
                                  </div>
                                ))
                              : "—"}
                          </td>
                          <td>
                            <Badge value={a.credit_health.classification} />
                          </td>
                          <td>
                            <Badge value={a.status} />
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <Pagination
                  page={page}
                  total={data.data.meta.total}
                  onPage={setPage}
                />
              </>
            ) : (
              <Empty title="No accounts found" />
            ))}
        </Feedback>
      </section>
    </>
  );
}
export function AccountDetail({
  id,
  revision,
  nav,
  open,
  handlers,
}: {
  id: string;
  revision: number;
  nav: Navigate;
  open: Open;
  handlers: Omit<Handlers, "payments">;
}) {
  const data = useData(() => get<Account>(`/accounts/${id}`), [id, revision]);
  const projects = useData(
    () => api<Page<Project>>(`/projects?account_id=${id}&page_size=100`),
    [id, revision],
  );
  const [page, setPage] = useState(1);
  useEffect(() => setPage(1), [id]);
  const payments = useData(
    () => api<Page<Payment>>(`/accounts/${id}/payments?page=${page}`),
    [id, revision, page],
  );
  return (
    <Feedback loading={data.loading} error={data.error}>
      {data.data && (
        <>
          <PageHeading
            title={data.data.name}
            description={`${data.data.contact_name} · ${data.data.email} · ${data.data.phone}`}
            back={() => nav({ section: "Accounts" })}
            action={
              <div className="heading-actions">
                <Badge value={data.data.status} />
                <Button
                  variant="ghost"
                  onClick={() => open("account", data.data!)}
                >
                  Edit account
                </Button>
              </div>
            }
          />
          <FinancialCards
            financial={data.data.financial}
            contracted={data.data.contracted}
          />
          <HealthPanel
            health={data.data.credit_health}
            onPayment={handlers.onPayment}
          />
          <section className="panel">
            <div className="panel-heading">
              <h2>Projects</h2>
              <Button
                disabled={data.data.status === "archived"}
                onClick={() => open("project", undefined, { accountId: id })}
              >
                <Plus size={16} />
                Create project
              </Button>
            </div>
            <Feedback loading={projects.loading} error={projects.error}>
              {projects.data && (
                <>
                  <ProjectTable projects={projects.data.data} nav={nav} />
                  {projects.data.meta.total > 100 && (
                    <Button
                      variant="ghost"
                      onClick={() =>
                        nav({ section: "Projects", accountId: id })
                      }
                    >
                      View all projects
                    </Button>
                  )}
                </>
              )}
            </Feedback>
          </section>
          <section className="panel">
            <div className="panel-heading">
              <h2>Consolidated payment history</h2>
              <Button
                variant="ghost"
                onClick={() => nav({ section: "Payments", accountId: id })}
              >
                Open payment filters
                <ArrowUpRight size={14} />
              </Button>
            </div>
            <Feedback loading={payments.loading} error={payments.error}>
              {payments.data && (
                <>
                  <PaymentTable payments={payments.data.data} {...handlers} />
                  <Pagination
                    page={page}
                    total={payments.data.meta.total}
                    onPage={setPage}
                  />
                </>
              )}
            </Feedback>
          </section>
          <AuditPanel
            path={`/accounts/${id}/history`}
            revision={revision}
            title="Account history"
          />
        </>
      )}
    </Feedback>
  );
}
