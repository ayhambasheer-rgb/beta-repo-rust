import {
  Plus,
  ArrowUpRight,
  CalendarDays,
  CreditCard,
  ShieldCheck,
} from "lucide-react";
import { Button } from "../components/ui/button";
import {
  Badge,
  date,
  Empty,
  Feedback,
  money,
  PageHeading,
  Stat,
} from "../components/common";
import { get, useData } from "../data";
import type { Dashboard } from "../types";
import { healthClasses, paymentStatuses } from "../types";
import type { Navigate, Open } from "../navigation";
export function DashboardPage({
  revision,
  nav,
  onPayment,
  onAccount,
  open,
}: {
  revision: number;
  nav: Navigate;
  onPayment: (id: string) => void;
  onAccount: (id: string) => void;
  open: Open;
}) {
  const data = useData(() => get<Dashboard>("/dashboard"), [revision]);
  return (
    <>
      <PageHeading
        title="Dashboard"
        description="Stay ahead of obligations. Keep every client relationship in view."
        action={
          <Button onClick={() => open("payment")}>
            <Plus size={16} />
            Schedule payment
          </Button>
        }
      />
      <Feedback loading={data.loading} error={data.error}>
        {data.data && (
          <>
            {(() => {
              const d = data.data!;
              const f = d.financial.find((f) => f.currency === d.currency);
              return (
                <>
                  <div className="summary-grid dashboard-stats">
                    <Stat
                      title="Accounts"
                      value={String(d.total_accounts)}
                      detail="All client relationships"
                      onClick={() => nav({ section: "Accounts" })}
                    />
                    <Stat
                      title="Active projects"
                      value={String(d.active_projects)}
                      onClick={() =>
                        nav({ section: "Projects", filter: "active" })
                      }
                    />
                    <Stat
                      title="Outstanding"
                      value={money(f?.outstanding, d.currency ?? "USD")}
                      detail={`${d.payment_status_counts.OVERDUE + d.payment_status_counts.DUE_TODAY + d.payment_status_counts.UPCOMING} unpaid obligations`}
                      onClick={() =>
                        nav({ section: "Payments", filter: "UNPAID" })
                      }
                    />
                    <Stat
                      title="Overdue"
                      value={money(f?.overdue, d.currency ?? "USD")}
                      detail={`${d.payment_status_counts.OVERDUE} overdue obligations`}
                      danger={d.payment_status_counts.OVERDUE > 0}
                      onClick={() =>
                        nav({ section: "Payments", filter: "OVERDUE" })
                      }
                    />
                    <Stat
                      title="Collected"
                      value={money(f?.paid, d.currency ?? "USD")}
                      onClick={() =>
                        nav({ section: "Payments", filter: "SETTLED" })
                      }
                    />
                    <Stat
                      title="Upcoming payments"
                      value={String(d.payment_status_counts.UPCOMING)}
                      detail={`${d.payment_status_counts.DUE_TODAY} due today`}
                      onClick={() =>
                        nav({ section: "Payments", filter: "UPCOMING" })
                      }
                    />
                  </div>
                  <div className="dashboard-grid">
                    <section className="panel">
                      <div className="panel-heading">
                        <h2>Payment status overview</h2>
                        <CreditCard size={18} />
                      </div>
                      <div className="distribution-list">
                        {paymentStatuses.map((s) => (
                          <button
                            key={s}
                            onClick={() =>
                              nav({ section: "Payments", filter: s })
                            }
                          >
                            <Badge value={s} />
                            <strong>{d.payment_status_counts[s]}</strong>
                            <ArrowUpRight size={14} />
                          </button>
                        ))}
                      </div>
                    </section>
                    <section className="panel">
                      <div className="panel-heading">
                        <h2>Credit health distribution</h2>
                        <ShieldCheck size={18} />
                      </div>
                      <div className="distribution-list">
                        {healthClasses.map((s) => (
                          <button
                            key={s}
                            onClick={() =>
                              nav({ section: "Accounts", filter: s })
                            }
                          >
                            <Badge value={s} />
                            <strong>{d.credit_health_distribution[s]}</strong>
                            <ArrowUpRight size={14} />
                          </button>
                        ))}
                      </div>
                    </section>
                  </div>
                  <div className="dashboard-grid">
                    <section className="panel">
                      <div className="panel-heading">
                        <h2>Upcoming schedule</h2>
                        <CalendarDays size={18} />
                      </div>
                      {d.upcoming_payments.length ? (
                        <div className="schedule-list">
                          {d.upcoming_payments.map((p) => (
                            <button key={p.id} onClick={() => onPayment(p.id)}>
                              <div>
                                <strong>{p.title}</strong>
                                <small>
                                  {p.account_name} · {date(p.due_date)}
                                </small>
                              </div>
                              <div>
                                <strong>{money(p.amount, p.currency)}</strong>
                                <Badge value={p.status} />
                              </div>
                            </button>
                          ))}
                        </div>
                      ) : (
                        <Empty title="No upcoming obligations">
                          Scheduled obligations will appear here.
                        </Empty>
                      )}
                    </section>
                    <section className="panel">
                      <div className="panel-heading">
                        <h2>Overdue obligations</h2>
                        <Button
                          variant="ghost"
                          onClick={() =>
                            nav({ section: "Payments", filter: "OVERDUE" })
                          }
                        >
                          View all
                          <ArrowUpRight size={14} />
                        </Button>
                      </div>
                      {d.overdue_payments.length ? (
                        <div className="schedule-list">
                          {d.overdue_payments.map((p) => (
                            <button key={p.id} onClick={() => onPayment(p.id)}>
                              <div>
                                <strong>{p.title}</strong>
                                <small>
                                  {p.account_name} · {p.days_overdue} days
                                  overdue
                                </small>
                              </div>
                              <strong className="danger-text">
                                {money(p.amount, p.currency)}
                              </strong>
                            </button>
                          ))}
                        </div>
                      ) : (
                        <Empty title="No overdue obligations">
                          Your outstanding schedule is on track.
                        </Empty>
                      )}
                    </section>
                  </div>
                  <div className="dashboard-grid">
                    <section className="panel">
                      <div className="panel-heading">
                        <h2>Accounts requiring attention</h2>
                      </div>
                      {d.accounts_requiring_attention.length ? (
                        <div className="attention-list">
                          {d.accounts_requiring_attention.map((a) => (
                            <button key={a.id} onClick={() => onAccount(a.id)}>
                              <div>
                                <strong>{a.name}</strong>
                                <small>{a.credit_health.reasons[0]}</small>
                              </div>
                              <Badge value={a.credit_health.classification} />
                            </button>
                          ))}
                        </div>
                      ) : (
                        <Empty title="No accounts requiring attention">
                          New accounts remain unrated until enough history is
                          available.
                        </Empty>
                      )}
                    </section>
                    <section className="panel">
                      <div className="panel-heading">
                        <h2>Recent payment activity</h2>
                      </div>
                      {d.recent_activity.length ? (
                        <div className="schedule-list">
                          {d.recent_activity.map((e) => (
                            <button
                              key={e.id}
                              onClick={() => onPayment(e.payment_id)}
                            >
                              <div>
                                <strong>{e.title}</strong>
                                <small>
                                  {e.account_name} ·{" "}
                                  {new Date(e.created_at).toLocaleDateString()}
                                </small>
                              </div>
                              <Badge value={e.action} />
                            </button>
                          ))}
                        </div>
                      ) : (
                        <Empty title="No payment activity yet" />
                      )}
                    </section>
                  </div>
                </>
              );
            })()}
          </>
        )}
      </Feedback>
    </>
  );
}
