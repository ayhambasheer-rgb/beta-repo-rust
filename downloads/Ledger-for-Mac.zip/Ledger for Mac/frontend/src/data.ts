import { useEffect, useState } from "react";
import { ApiError } from "./api";
import type { Page } from "./types";
export async function api<T>(
  path: string,
  options: RequestInit = {},
): Promise<T> {
  const csrf = sessionStorage.getItem("csrf") ?? "";
  const response = await fetch(`/api/v1${path}`, {
    ...options,
    credentials: "same-origin",
    headers: {
      "Content-Type": "application/json",
      "X-CSRF-Token": csrf,
      ...options.headers,
    },
  });
  if (response.status === 401) {
    window.dispatchEvent(new Event("session-expired"));
    throw new ApiError(401, "Your session expired. Sign in again.");
  }
  if (response.status === 204) return undefined as T;
  let body;
  try {
    body = await response.json();
  } catch {
    throw new Error(
      "The server returned an unexpected response. Please try again.",
    );
  }
  if (!response.ok)
    throw new ApiError(
      response.status,
      body.error?.message ?? "The request could not be completed.",
    );
  return body as T;
}
export async function get<T>(path: string): Promise<T> {
  return (await api<{ data: T }>(path)).data;
}
export async function save<T>(
  path: string,
  body: unknown,
  method = "POST",
): Promise<T> {
  return (await api<{ data: T }>(path, { method, body: JSON.stringify(body) }))
    .data;
}
export function useData<T>(loader: () => Promise<T>, dependencies: unknown[]) {
  const [data, setData] = useState<T | null>(null),
    [error, setError] = useState(""),
    [loading, setLoading] = useState(true);
  useEffect(() => {
    let live = true;
    setLoading(true);
    setError("");
    loader()
      .then((v) => {
        if (live) setData(v);
      })
      .catch((e) => {
        if (live)
          setError(e instanceof Error ? e.message : "Unable to load records.");
      })
      .finally(() => {
        if (live) setLoading(false);
      });
    return () => {
      live = false;
    };
  }, dependencies);
  return { data, error, loading };
}
export async function all<T>(path: string): Promise<T[]> {
  const output: T[] = [];
  let page = 1;
  while (true) {
    const data = await api<Page<T>>(
      `${path}${path.includes("?") ? "&" : "?"}page_size=100&page=${page}`,
    );
    output.push(...data.data);
    if (!data.data.length || output.length >= data.meta.total) return output;
    page += 1;
  }
}
