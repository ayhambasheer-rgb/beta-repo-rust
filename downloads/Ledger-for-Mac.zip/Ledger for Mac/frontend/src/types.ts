export type Financial = {
  currency: string;
  scheduled: string;
  paid: string;
  outstanding: string;
  overdue: string;
  overdue_count: number;
  completion_percent: string | null;
};
export type Health = {
  classification: string;
  policy_version: string;
  as_of_date: string;
  window_start: string;
  on_time_rate: string | null;
  settled_count: number;
  historical_late_count: number;
  lifetime_late_count: number;
  overdue_count: number;
  max_days_overdue: number;
  recovery_streak: number;
  reasons: string[];
  contributing_payment_ids: string[];
  exposure: {
    currency: string;
    overdue_amount: string;
    matured_exposure: string;
    overdue_percent: string;
  }[];
  disclaimer: string;
};
export type Account = {
  id: string;
  name: string;
  contact_name: string;
  email: string;
  phone: string;
  status: string;
  version: number;
  project_count: number;
  financial: Financial[];
  contracted: { currency: string; amount: string }[];
  credit_health: Health;
  created_at: string;
  updated_at: string;
};
export type Project = {
  id: string;
  account_id: string;
  account_name: string;
  name: string;
  description: string;
  contract_value: string;
  currency: string;
  status: string;
  start_date: string;
  end_date: string | null;
  version: number;
  financial: Financial[];
  schedule_difference: string;
  schedule_matches_contract: boolean;
};
export type Payment = {
  id: string;
  project_id: string;
  account_id: string;
  account_name: string;
  project_name: string;
  title: string;
  amount: string;
  currency: string;
  due_date: string;
  settlement_date: string | null;
  status: string;
  settlement_status: string;
  days_overdue: number;
  version: number;
};
export type Audit = {
  id: string;
  action: string;
  reason: string;
  actor_email: string;
  before: Record<string, unknown> | null;
  after: Record<string, unknown>;
  created_at: string;
};
export type Settings = {
  currency: string | null;
  monetary_precision: number;
  business_timezone: string;
  business_date: string;
};
export type Dashboard = {
  business_date: string;
  currency: string | null;
  total_accounts: number;
  active_projects: number;
  financial: Financial[];
  payment_status_counts: Record<string, number>;
  credit_health_distribution: Record<string, number>;
  accounts_requiring_attention: {
    id: string;
    name: string;
    credit_health: Health;
  }[];
  upcoming_payments: Payment[];
  overdue_payments: Payment[];
  recent_activity: {
    id: string;
    action: string;
    created_at: string;
    title: string;
    amount: string;
    currency: string;
    account_name: string;
    account_id: string;
    payment_id: string;
    reason: string;
  }[];
};
export type Page<T> = {
  data: T[];
  meta: { page: number; page_size: number; total: number };
  business_date: string;
};
export const paymentStatuses = [
  "UPCOMING",
  "DUE_TODAY",
  "OVERDUE",
  "PAID_ON_TIME",
  "PAID_LATE",
];
export const healthClasses = [
  "HEALTHY",
  "AT_RISK",
  "RECOVERING",
  "POOR",
  "UNRATED",
];
