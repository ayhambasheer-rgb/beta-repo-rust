import {
  Building2,
  CreditCard,
  FolderKanban,
  LayoutDashboard,
} from "lucide-react";
import type { FormKind, Editable } from "./components/forms";
import type { PaymentTable } from "./components/payment-table";
export type Section = "Dashboard" | "Accounts" | "Projects" | "Payments";
export type Route = {
  section: Section;
  id?: string;
  filter?: string;
  accountId?: string;
  projectId?: string;
};
export const sections = [
  { name: "Dashboard", icon: LayoutDashboard },
  { name: "Accounts", icon: Building2 },
  { name: "Projects", icon: FolderKanban },
  { name: "Payments", icon: CreditCard },
] as const;
export function readRoute(): Route {
  const parts = location.hash.replace(/^#\/?/, "").split("?");
  const [section, id] = parts[0].split("/");
  const name =
    sections.find((s) => s.name.toLowerCase() === section)?.name ?? "Dashboard";
  const params = new URLSearchParams(parts[1]);
  return {
    section: name,
    id: id || undefined,
    filter: params.get("status") ?? params.get("credit_health") ?? undefined,
    accountId: params.get("account_id") ?? undefined,
    projectId: params.get("project_id") ?? undefined,
  };
}
export function writeRoute(r: Route) {
  const params = new URLSearchParams();
  if (r.filter)
    params.set(r.section === "Accounts" ? "credit_health" : "status", r.filter);
  if (r.accountId) params.set("account_id", r.accountId);
  if (r.projectId) params.set("project_id", r.projectId);
  location.hash = `/${r.section.toLowerCase()}${r.id ? `/${r.id}` : ""}${params.size ? `?${params}` : ""}`;
}
export type Navigate = (route: Route) => void;
export type Open = (
  kind: FormKind,
  record?: Editable,
  context?: { accountId?: string; projectId?: string },
) => void;
export type Handlers = Parameters<typeof PaymentTable>[0];
