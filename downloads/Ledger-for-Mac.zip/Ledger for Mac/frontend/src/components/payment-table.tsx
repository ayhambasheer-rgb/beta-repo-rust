import { Button } from "./ui/button";
import { Badge, date, Empty, money } from "./common";
import type { Payment } from "../types";
export function PaymentTable({
  payments,
  onAccount,
  onProject,
  onPayment,
  onSettle,
}: {
  payments: Payment[];
  onAccount: (id: string) => void;
  onProject: (id: string) => void;
  onPayment: (id: string) => void;
  onSettle?: (payment: Payment) => void;
}) {
  if (!payments.length)
    return (
      <Empty title="No payments found">
        Try another filter or schedule a payment.
      </Empty>
    );
  return (
    <div className="table-scroll">
      <table>
        <thead>
          <tr>
            <th>Payment</th>
            <th>Account / Project</th>
            <th>Due date</th>
            <th className="number-cell">Amount</th>
            <th>Status</th>
            <th>
              <span className="sr-only">Actions</span>
            </th>
          </tr>
        </thead>
        <tbody>
          {payments.map((p) => (
            <tr key={p.id}>
              <td>
                <button className="record-link" onClick={() => onPayment(p.id)}>
                  {p.title}
                </button>
                {p.settlement_date && (
                  <small>Settled {date(p.settlement_date)}</small>
                )}
              </td>
              <td>
                <button
                  className="text-link"
                  onClick={() => onAccount(p.account_id)}
                >
                  {p.account_name}
                </button>
                <small>
                  <button onClick={() => onProject(p.project_id)}>
                    {p.project_name}
                  </button>
                </small>
              </td>
              <td>
                {date(p.due_date)}
                {p.days_overdue > 0 && (
                  <small className="danger-text">
                    {p.days_overdue} days overdue
                  </small>
                )}
              </td>
              <td className="number-cell">{money(p.amount, p.currency)}</td>
              <td>
                <Badge value={p.status} />
              </td>
              <td>
                {!p.settlement_date && onSettle ? (
                  <Button variant="ghost" onClick={() => onSettle(p)}>
                    Settle
                  </Button>
                ) : (
                  <Button variant="ghost" onClick={() => onPayment(p.id)}>
                    View
                  </Button>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
