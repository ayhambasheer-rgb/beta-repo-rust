import { afterEach, describe, expect, it } from "vitest";
import { cleanup, render, screen } from "@testing-library/react";
import { Badge, FinancialCards, money } from "./common";
afterEach(cleanup);
describe("financial presentation", () => {
  it("preserves cent precision beyond JavaScript safe integers", () => {
    expect(money("9007199254740993.01", "USD")).toBe(
      "USD 9,007,199,254,740,993.01",
    );
    expect(money("-10.20", "USD")).toBe("USD -10.20");
  });
  it("shows currency totals separately and status text without relying on color", () => {
    render(
      <>
        <FinancialCards
          financial={[
            {
              currency: "USD",
              scheduled: "100.00",
              paid: "50.00",
              outstanding: "50.00",
              overdue: "0.00",
              overdue_count: 0,
              completion_percent: "50.00",
            },
            {
              currency: "EUR",
              scheduled: "20.00",
              paid: "0.00",
              outstanding: "20.00",
              overdue: "20.00",
              overdue_count: 1,
              completion_percent: "0.00",
            },
          ]}
        />
        <Badge value="PAID_LATE" />
      </>,
    );
    expect(screen.getAllByText("USD 50.00")).toHaveLength(2);
    expect(screen.getAllByText("EUR 20.00")).toHaveLength(3);
    expect(screen.getByText("Paid Late")).toBeInTheDocument();
  });
});
