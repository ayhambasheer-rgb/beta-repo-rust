import { useState, type FormEvent, type ReactNode } from "react";
import * as Dialog from "@radix-ui/react-dialog";
import { X } from "lucide-react";
import { Button } from "./ui/button";
import { all, save, useData } from "../data";
import { Feedback, money } from "./common";
import type { Account, Project, Payment, Settings } from "../types";
export type FormKind =
  "account" | "project" | "payment" | "settlement" | "correction";
export type Editable = Account | Project | Payment;
function Field({
  name,
  label,
  value = "",
  type = "text",
  required = true,
  children,
  maxLength,
}: {
  name: string;
  label: string;
  value?: string | number;
  type?: string;
  required?: boolean;
  children?: ReactNode;
  maxLength?: number;
}) {
  return (
    <div className="form-field">
      <label htmlFor={`field-${name}`}>
        {label}
        {!required && <span> Optional</span>}
      </label>
      {children ?? (
        <input
          id={`field-${name}`}
          name={name}
          type={type}
          defaultValue={value}
          required={required}
          maxLength={maxLength}
        />
      )}
    </div>
  );
}
export function RecordForm({
  kind,
  record,
  settings,
  accountId,
  projectId,
  onClose,
  onSaved,
}: {
  kind: FormKind;
  record?: Editable;
  settings: Settings;
  accountId?: string;
  projectId?: string;
  onClose: () => void;
  onSaved: (id: string) => void;
}) {
  const [busy, setBusy] = useState(false),
    [error, setError] = useState("");
  const options = useData(
    async () => ({
      accounts:
        kind === "project" && !record
          ? await all<Account>("/accounts?status=active")
          : [],
      projects: kind === "payment" ? await all<Project>("/projects") : [],
    }),
    [kind, record?.id],
  );
  const account =
    kind === "account" ? (record as Account | undefined) : undefined;
  const project =
    kind === "project" ? (record as Project | undefined) : undefined;
  const payment =
    kind === "settlement" || kind === "correction"
      ? (record as Payment)
      : undefined;
  const title =
    kind === "settlement"
      ? "Record settlement"
      : kind === "correction"
        ? "Correct payment"
        : `${record ? "Edit" : "Create"} ${kind === "payment" ? "scheduled payment" : kind}`;
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError("");
    const form = new FormData(event.currentTarget);
    const value = (name: string) => String(form.get(name) ?? "").trim();
    try {
      let path = "",
        body: Record<string, unknown> = {},
        method = "POST";
      if (kind === "account") {
        path = record ? `/accounts/${record.id}` : "/accounts";
        method = record ? "PATCH" : "POST";
        body = {
          name: value("name"),
          contact_name: value("contact_name"),
          email: value("email"),
          phone: value("phone"),
          status: value("status"),
        };
      }
      if (kind === "project") {
        path = record ? `/projects/${record.id}` : "/projects";
        method = record ? "PATCH" : "POST";
        body = {
          name: value("name"),
          description: value("description"),
          contract_value: value("contract_value"),
          status: value("status"),
          start_date: value("start_date"),
          end_date: value("end_date") || null,
        };
        if (!record) {
          body.account_id = value("account_id");
          body.currency = settings.currency;
        }
      }
      if (kind === "payment") {
        path = "/payments";
        body = {
          project_id: value("project_id"),
          title: value("title"),
          amount: value("amount"),
          currency: settings.currency,
          due_date: value("due_date"),
        };
      }
      if (kind === "settlement") {
        path = `/payments/${record!.id}/settlement`;
        body = {
          version: record!.version,
          settlement_date: value("settlement_date"),
        };
      }
      if (kind === "correction") {
        path = `/payments/${record!.id}/corrections`;
        body = {
          version: record!.version,
          reason: value("reason"),
          title: value("title"),
          amount: value("amount"),
          due_date: value("due_date"),
          settlement_date: value("settlement_date") || null,
        };
      }
      if (record && (kind === "account" || kind === "project")) {
        body.version = record.version;
        body.reason = value("reason");
      }
      const result = await save<{ id: string }>(path, body, method);
      onSaved(result.id);
    } catch (err) {
      setError(
        err instanceof Error ? err.message : "Unable to save this record.",
      );
    } finally {
      setBusy(false);
    }
  }
  const amountField = (name: string, label: string, value: string) => (
    <Field
      name={name}
      label={`${label} (${settings.currency ?? "currency not configured"})`}
    >
      <input
        id={`field-${name}`}
        name={name}
        type="text"
        inputMode="decimal"
        pattern="[0-9]+(\.[0-9]{1,2})?"
        defaultValue={value}
        required
        placeholder="0.00"
      />
    </Field>
  );
  return (
    <Dialog.Root
      open
      onOpenChange={(open) => {
        if (!open && !busy) onClose();
      }}
    >
      <Dialog.Portal>
        <Dialog.Overlay className="dialog-overlay" />
        <Dialog.Content
          className="dialog-content"
          onEscapeKeyDown={(e) => {
            if (busy) e.preventDefault();
          }}
        >
          <div className="dialog-heading">
            <Dialog.Title>{title}</Dialog.Title>
            <Dialog.Close asChild>
              <Button variant="ghost" aria-label="Close form" disabled={busy}>
                <X size={18} />
              </Button>
            </Dialog.Close>
          </div>
          <Dialog.Description className="muted">
            {kind === "correction"
              ? "Correct the current facts while preserving their previous values and your reason in history."
              : kind === "settlement"
                ? "Record the actual date this obligation was paid in full."
                : "Keep your client records clear and up to date."}
          </Dialog.Description>
          <Feedback loading={options.loading} error={options.error}>
            {options.data && (
              <form onSubmit={submit}>
                {kind === "account" && (
                  <>
                    <Field
                      name="name"
                      label="Account name"
                      value={account?.name}
                      maxLength={200}
                    />
                    <Field
                      name="contact_name"
                      label="Contact name"
                      value={account?.contact_name}
                      maxLength={200}
                    />
                    <Field
                      name="email"
                      label="Email address"
                      type="email"
                      value={account?.email}
                      maxLength={254}
                    />
                    <Field
                      name="phone"
                      label="Phone number"
                      type="tel"
                      value={account?.phone}
                      maxLength={50}
                    />
                    <Field name="status" label="Account status">
                      <select
                        id="field-status"
                        name="status"
                        defaultValue={account?.status ?? "active"}
                      >
                        <option value="active">Active</option>
                        <option value="archived">Archived</option>
                      </select>
                    </Field>
                  </>
                )}
                {kind === "project" && (
                  <>
                    {!record && (
                      <Field name="account_id" label="Account">
                        <select
                          id="field-account_id"
                          name="account_id"
                          required
                          defaultValue={accountId ?? ""}
                        >
                          <option value="">Select an account</option>
                          {options.data.accounts.map((a) => (
                            <option key={a.id} value={a.id}>
                              {a.name}
                            </option>
                          ))}
                        </select>
                      </Field>
                    )}
                    <Field
                      name="name"
                      label="Project name"
                      value={project?.name}
                      maxLength={200}
                    />
                    <Field
                      name="description"
                      label="Description"
                      required={false}
                    >
                      <textarea
                        id="field-description"
                        name="description"
                        defaultValue={project?.description ?? ""}
                        maxLength={5000}
                      />
                    </Field>
                    {amountField(
                      "contract_value",
                      "Contract value",
                      project?.contract_value ?? "",
                    )}
                    <div className="form-grid">
                      <Field
                        name="start_date"
                        label="Start date"
                        type="date"
                        value={project?.start_date ?? settings.business_date}
                      />
                      <Field
                        name="end_date"
                        label="End date"
                        type="date"
                        value={project?.end_date ?? ""}
                        required={false}
                      />
                    </div>
                    <Field name="status" label="Project status">
                      <select
                        id="field-status"
                        name="status"
                        defaultValue={project?.status ?? "active"}
                      >
                        {["planned", "active", "completed", "archived"].map(
                          (s) => (
                            <option key={s} value={s}>
                              {s[0].toUpperCase() + s.slice(1)}
                            </option>
                          ),
                        )}
                      </select>
                    </Field>
                  </>
                )}
                {kind === "payment" && (
                  <>
                    <Field name="project_id" label="Project">
                      <select
                        id="field-project_id"
                        name="project_id"
                        required
                        defaultValue={projectId ?? ""}
                      >
                        <option value="">Select a project</option>
                        {options.data.projects
                          .filter((p) => p.status !== "archived")
                          .map((p) => (
                            <option key={p.id} value={p.id}>
                              {p.account_name} · {p.name}
                            </option>
                          ))}
                      </select>
                    </Field>
                    <Field name="title" label="Payment title" maxLength={200} />
                    {amountField("amount", "Amount", "")}
                    <Field
                      name="due_date"
                      label="Due date"
                      type="date"
                      value={settings.business_date}
                    />
                  </>
                )}
                {kind === "settlement" && (
                  <>
                    <div className="notice">
                      <strong>{payment!.title}</strong>
                      <p>
                        {money(payment!.amount, payment!.currency)} · Full
                        settlement
                      </p>
                    </div>
                    <Field
                      name="settlement_date"
                      label="Actual settlement date"
                    >
                      <input
                        id="field-settlement_date"
                        name="settlement_date"
                        type="date"
                        required
                        defaultValue={settings.business_date}
                        max={settings.business_date}
                      />
                    </Field>
                  </>
                )}
                {kind === "correction" && (
                  <>
                    <Field
                      name="title"
                      label="Payment title"
                      value={payment!.title}
                      maxLength={200}
                    />
                    {amountField("amount", "Amount", payment!.amount)}
                    <Field
                      name="due_date"
                      label="Due date"
                      type="date"
                      value={payment!.due_date}
                    />
                    <Field
                      name="settlement_date"
                      label="Actual settlement date"
                      required={false}
                    >
                      <input
                        id="field-settlement_date"
                        name="settlement_date"
                        type="date"
                        defaultValue={payment!.settlement_date ?? ""}
                        max={settings.business_date}
                      />
                    </Field>
                    <p className="muted">
                      Leave the settlement date blank to mark this obligation
                      unpaid. Earlier settlement records remain in its audit
                      history.
                    </p>
                  </>
                )}
                {((record && (kind === "account" || kind === "project")) ||
                  kind === "correction") && (
                  <Field name="reason" label="Reason for change">
                    <textarea
                      id="field-reason"
                      name="reason"
                      required
                      maxLength={1000}
                    />
                  </Field>
                )}
                {!settings.currency &&
                  (kind === "project" || kind === "payment") && (
                    <p className="error" role="alert">
                      The business currency must be configured before creating
                      financial records.
                    </p>
                  )}
                {error && (
                  <p className="error" role="alert">
                    {error}
                  </p>
                )}
                <div className="dialog-actions">
                  <Button
                    variant="ghost"
                    type="button"
                    disabled={busy}
                    onClick={onClose}
                  >
                    Cancel
                  </Button>
                  <Button
                    disabled={
                      busy ||
                      (!settings.currency &&
                        (kind === "project" || kind === "payment"))
                    }
                  >
                    {busy
                      ? "Saving…"
                      : kind === "settlement"
                        ? "Record settlement"
                        : kind === "correction"
                          ? "Save correction"
                          : "Save record"}
                  </Button>
                </div>
              </form>
            )}
          </Feedback>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}
