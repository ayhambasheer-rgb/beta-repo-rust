import { useEffect, useState, type ReactNode } from "react";
import { Badge, label, money, Empty, Feedback, Pagination } from "./common";
import { api, useData } from "../data";
import type { Project, Audit, Page } from "../types";
import type { Navigate } from "../navigation";
export function Toolbar({
  search,
  onSearch,
  children,
}: {
  search: string;
  onSearch: (s: string) => void;
  children?: ReactNode;
}) {
  return (
    <div className="toolbar">
      <input
        type="search"
        aria-label="Search records"
        value={search}
        onChange={(e) => onSearch(e.target.value)}
        placeholder="Search records…"
      />
      {children}
    </div>
  );
}
export function ProjectTable({
  projects,
  nav,
}: {
  projects: Project[];
  nav: Navigate;
}) {
  return projects.length ? (
    <div className="table-scroll">
      <table>
        <thead>
          <tr>
            <th>Project</th>
            <th>Account</th>
            <th className="number-cell">Contract value</th>
            <th>Financial progress</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {projects.map((p) => (
            <tr key={p.id}>
              <td>
                <button
                  className="record-link"
                  onClick={() => nav({ section: "Projects", id: p.id })}
                >
                  {p.name}
                </button>
                {!p.schedule_matches_contract && (
                  <small className="warning-text">
                    Schedule differs by{" "}
                    {money(p.schedule_difference, p.currency)}
                  </small>
                )}
              </td>
              <td>
                <button
                  className="text-link"
                  onClick={() => nav({ section: "Accounts", id: p.account_id })}
                >
                  {p.account_name}
                </button>
              </td>
              <td className="number-cell">
                {money(p.contract_value, p.currency)}
              </td>
              <td>
                {p.financial.length ? (
                  <>
                    <span>
                      {p.financial[0].completion_percent ?? "0"}% paid
                    </span>
                    <progress
                      max={100}
                      value={Number(p.financial[0].completion_percent ?? 0)}
                      aria-label={`${p.name} payment completion`}
                    />
                  </>
                ) : (
                  <span className="muted">No schedule</span>
                )}
              </td>
              <td>
                <Badge value={p.status} />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  ) : (
    <Empty title="No projects found" />
  );
}
export function AuditPanel({
  path,
  revision,
  title,
}: {
  path: string;
  revision: number;
  title: string;
}) {
  const [page, setPage] = useState(1);
  useEffect(() => setPage(1), [path]);
  const history = useData(
    () => api<Page<Audit>>(`${path}?page=${page}`),
    [path, revision, page],
  );
  return (
    <section className="panel">
      <div className="panel-heading">
        <h2>{title}</h2>
        <span className="muted">Material changes are preserved</span>
      </div>
      <Feedback loading={history.loading} error={history.error}>
        {history.data && (
          <>
            <div className="audit-list">
              {history.data.data.map((event) => (
                <article key={event.id}>
                  <div>
                    <Badge value={event.action} />
                    <time>{new Date(event.created_at).toLocaleString()}</time>
                  </div>
                  <h3>{event.reason}</h3>
                  <p className="muted">By {event.actor_email}</p>
                  <details>
                    <summary>View recorded changes</summary>
                    <div className="table-scroll">
                      <table>
                        <thead>
                          <tr>
                            <th>Field</th>
                            <th>Before</th>
                            <th>After</th>
                          </tr>
                        </thead>
                        <tbody>
                          {[
                            "name",
                            "title",
                            "amount",
                            "contract_value",
                            "due_date",
                            "settlement_date",
                            "status",
                            "version",
                          ]
                            .filter(
                              (field) =>
                                field in event.after &&
                                (!event.before ||
                                  event.before[field] !== event.after[field]),
                            )
                            .map((field) => (
                              <tr key={field}>
                                <td>{label(field)}</td>
                                <td>{String(event.before?.[field] ?? "—")}</td>
                                <td>{String(event.after[field] ?? "—")}</td>
                              </tr>
                            ))}
                        </tbody>
                      </table>
                    </div>
                  </details>
                </article>
              ))}
            </div>
            <Pagination
              page={page}
              total={history.data.meta.total}
              onPage={setPage}
            />
          </>
        )}
      </Feedback>
    </section>
  );
}
