import type { ReactNode } from "react";
import { ArrowLeft, ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "./ui/button";
import type { Financial, Health } from "../types";
export function label(value: string) {
  return value
    .toLowerCase()
    .split("_")
    .map((s) => s[0]?.toUpperCase() + s.slice(1))
    .join(" ");
}
export function money(amount: string | undefined, currency = "USD") {
  const raw = amount ?? "0";
  const negative = raw.startsWith("-");
  const [whole, fraction = ""] = raw.replace(/^-/, "").split(".");
  return `${currency} ${negative ? "-" : ""}${whole.replace(/\B(?=(\d{3})+(?!\d))/g, ",")}.${fraction.padEnd(2, "0").slice(0, 2)}`;
}
export function date(value: string) {
  return new Intl.DateTimeFormat("en", {
    year: "numeric",
    month: "short",
    day: "numeric",
    timeZone: "UTC",
  }).format(new Date(`${value}T12:00:00Z`));
}
export function Badge({ value }: { value: string }) {
  return (
    <span className={`status-badge status-${value.toLowerCase()}`}>
      {label(value)}
    </span>
  );
}
export function Feedback({
  loading,
  error,
  children,
}: {
  loading?: boolean;
  error?: string;
  children?: ReactNode;
}) {
  if (loading)
    return (
      <p role="status" className="loading-state">
        Loading records…
      </p>
    );
  if (error)
    return (
      <p role="alert" className="error">
        {error}
      </p>
    );
  return <>{children}</>;
}
export function Empty({
  title,
  children,
}: {
  title: string;
  children?: ReactNode;
}) {
  return (
    <div className="records-empty">
      <h3>{title}</h3>
      <p>{children ?? "Create your first record to get started."}</p>
    </div>
  );
}
export function PageHeading({
  title,
  description,
  action,
  back,
}: {
  title: string;
  description: string;
  action?: ReactNode;
  back?: () => void;
}) {
  return (
    <>
      <div className="page-heading">
        <div>
          {back && (
            <Button variant="ghost" onClick={back} className="back-button">
              <ArrowLeft size={14} />
              Back to list
            </Button>
          )}
          <p className="eyebrow">YOUR WORKSPACE</p>
          <h1>{title}</h1>
          <p className="muted">{description}</p>
        </div>
        {action}
      </div>
    </>
  );
}
export function Pagination({
  page,
  total,
  size = 20,
  onPage,
}: {
  page: number;
  total: number;
  size?: number;
  onPage: (p: number) => void;
}) {
  const last = Math.max(1, Math.ceil(total / size));
  return (
    <div className="pagination">
      <span>
        {total} record{total === 1 ? "" : "s"} · Page {page} of {last}
      </span>
      <div>
        <Button
          variant="ghost"
          aria-label="Previous page"
          disabled={page <= 1}
          onClick={() => onPage(page - 1)}
        >
          <ChevronLeft size={16} />
        </Button>
        <Button
          variant="ghost"
          aria-label="Next page"
          disabled={page >= last}
          onClick={() => onPage(page + 1)}
        >
          <ChevronRight size={16} />
        </Button>
      </div>
    </div>
  );
}
export function FinancialCards({
  financial,
  contracted,
}: {
  financial: Financial[];
  contracted?: { currency: string; amount: string }[];
}) {
  const currencies = [
    ...new Set([
      ...financial.map((f) => f.currency),
      ...(contracted ?? []).map((c) => c.currency),
    ]),
  ];
  if (!currencies.length)
    return (
      <div className="notice">
        No financial obligations have been scheduled.
      </div>
    );
  return (
    <>
      {currencies.map((currency) => {
        const f = financial.find((x) => x.currency === currency);
        const contract = contracted?.find((x) => x.currency === currency);
        return (
          <div key={currency} className="summary-grid">
            {contract && (
              <Stat
                title="Contracted value"
                value={money(contract.amount, currency)}
              />
            )}
            <Stat title="Scheduled" value={money(f?.scheduled, currency)} />
            <Stat title="Collected" value={money(f?.paid, currency)} />
            <Stat title="Outstanding" value={money(f?.outstanding, currency)} />
            <Stat
              title="Overdue"
              value={money(f?.overdue, currency)}
              danger={!!f?.overdue_count}
            />
          </div>
        );
      })}
    </>
  );
}
export function Stat({
  title,
  value,
  detail,
  onClick,
  danger,
}: {
  title: string;
  value: string;
  detail?: string;
  onClick?: () => void;
  danger?: boolean;
}) {
  const contents = (
    <>
      <p className="stat-label">{title}</p>
      <strong className={danger ? "danger-text" : ""}>{value}</strong>
      {detail && <span>{detail}</span>}
    </>
  );
  return onClick ? (
    <button className="stat-card interactive" onClick={onClick}>
      {contents}
    </button>
  ) : (
    <div className="stat-card">{contents}</div>
  );
}
export function HealthPanel({
  health,
  onPayment,
}: {
  health: Health;
  onPayment?: (id: string) => void;
}) {
  return (
    <section className="panel health-panel">
      <div className="panel-heading">
        <h2>Credit health</h2>
        <Badge value={health.classification} />
      </div>
      <p className="muted">
        Internal payment discipline · As of {date(health.as_of_date)}
      </p>
      <ul className="health-reasons">
        {health.reasons.map((reason) => (
          <li key={reason}>{reason}</li>
        ))}
      </ul>
      <div className="health-factors">
        <div>
          <strong>
            {health.on_time_rate === null ? "—" : `${health.on_time_rate}%`}
          </strong>
          <span>On-time rate</span>
        </div>
        <div>
          <strong>{health.overdue_count}</strong>
          <span>Overdue obligations</span>
        </div>
        <div>
          <strong>{health.historical_late_count}</strong>
          <span>Recent late payments</span>
        </div>
        <div>
          <strong>{health.recovery_streak}</strong>
          <span>On-time recovery groups</span>
        </div>
      </div>
      {health.exposure.map((e) => (
        <p key={e.currency} className="muted">
          Overdue: {money(e.overdue_amount, e.currency)} · {e.overdue_percent}%
          of matured exposure
        </p>
      ))}
      <details>
        <summary>Assessment details and contributing records</summary>
        <p className="muted">
          Window: {date(health.window_start)}–{date(health.as_of_date)}.{" "}
          {health.settled_count} matured settlements;{" "}
          {health.lifetime_late_count} lifetime late settlements. Maximum
          outstanding lateness: {health.max_days_overdue} days. Policy:{" "}
          {health.policy_version}.
        </p>
        <div className="contributing-records">
          {health.contributing_payment_ids.map((id, index) => (
            <button
              key={id}
              className="text-link"
              onClick={() => onPayment?.(id)}
            >
              Payment {index + 1}
            </button>
          ))}
        </div>
      </details>
      <p className="disclaimer">{health.disclaimer}</p>
    </section>
  );
}
