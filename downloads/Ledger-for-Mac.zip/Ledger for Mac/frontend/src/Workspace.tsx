import { useEffect, useState } from "react";
import { LogOut, ShieldCheck, Wallet } from "lucide-react";
import { Button } from "./components/ui/button";
import { Feedback, date } from "./components/common";
import { RecordForm, type FormKind, type Editable } from "./components/forms";
import { get, useData } from "./data";
import type { Payment, Settings } from "./types";
import type { User } from "./api";
import { readRoute, writeRoute, sections, type Route } from "./navigation";
import { AccountsList, AccountDetail } from "./pages/Accounts";
import { ProjectsList, ProjectDetail } from "./pages/Projects";
import { PaymentsList, PaymentDetail } from "./pages/Payments";
import { DashboardPage } from "./pages/Dashboard";
export default function Workspace({
  user,
  onLogout,
  busy,
  error,
}: {
  user: User;
  onLogout: () => void;
  busy: boolean;
  error: string;
}) {
  const [route, setRoute] = useState<Route>(readRoute),
    [revision, setRevision] = useState(0),
    [form, setForm] = useState<{
      kind: FormKind;
      record?: Editable;
      accountId?: string;
      projectId?: string;
    } | null>(null);
  const settings = useData(() => get<Settings>("/settings"), [revision]);
  useEffect(() => {
    const changed = () => setRoute(readRoute());
    window.addEventListener("hashchange", changed);
    const refresh = () => setRevision((v) => v + 1);
    window.addEventListener("focus", refresh);
    const timer = setInterval(refresh, 60000);
    return () => {
      window.removeEventListener("hashchange", changed);
      window.removeEventListener("focus", refresh);
      clearInterval(timer);
    };
  }, []);
  const nav = (r: Route) => {
    setRoute(r);
    writeRoute(r);
  };
  const account = (id: string) => nav({ section: "Accounts", id }),
    project = (id: string) => nav({ section: "Projects", id }),
    payment = (id: string) => nav({ section: "Payments", id });
  const open = (
    kind: FormKind,
    record?: Editable,
    context?: {
      accountId?: string;
      projectId?: string;
    },
  ) => setForm({ kind, record, ...context });
  const handlers = {
    onAccount: account,
    onProject: project,
    onPayment: payment,
    onSettle: (p: Payment) => open("settlement", p),
  };
  return (
    <div className="app-layout">
      <aside className="sidebar">
        <a className="brand" href="#/dashboard">
          <Wallet size={24} />
          <span>
            ledger<span className="brand-dot">.</span>
          </span>
        </a>
        <p className="nav-label">WORKSPACE</p>
        <nav aria-label="Primary navigation">
          {sections.map(({ name, icon: Icon }) => (
            <button
              key={name}
              aria-current={route.section === name ? "page" : undefined}
              className={`nav-item ${route.section === name ? "selected" : ""}`}
              onClick={() => nav({ section: name })}
            >
              <Icon size={18} />
              {name}
            </button>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <ShieldCheck size={18} />
          <div>
            <strong>Administrator workspace</strong>
            <p>Secure access enabled</p>
          </div>
        </div>
      </aside>
      <div className="workspace">
        <header className="topbar">
          <span>
            Workspace <span className="breadcrumb">/ {route.section}</span>
          </span>
          <div className="user-tools">
            <span>{user.email}</span>
            <Button variant="ghost" disabled={busy} onClick={onLogout}>
              <LogOut size={16} />
              Sign out
            </Button>
          </div>
        </header>
        <main className="workspace-main">
          {error && (
            <p role="alert" className="error">
              {error}
            </p>
          )}
          <Feedback
            loading={settings.loading && !settings.data}
            error={settings.data ? undefined : settings.error}
          >
            {settings.data && (
              <>
                {route.section === "Dashboard" ? (
                  <DashboardPage
                    revision={revision}
                    nav={nav}
                    onPayment={payment}
                    onAccount={account}
                    open={open}
                  />
                ) : route.section === "Accounts" ? (
                  route.id ? (
                    <AccountDetail
                      id={route.id}
                      revision={revision}
                      nav={nav}
                      open={open}
                      handlers={handlers}
                    />
                  ) : (
                    <AccountsList
                      revision={revision}
                      filter={route.filter}
                      nav={nav}
                      open={open}
                    />
                  )
                ) : route.section === "Projects" ? (
                  route.id ? (
                    <ProjectDetail
                      id={route.id}
                      revision={revision}
                      nav={nav}
                      open={open}
                      handlers={handlers}
                    />
                  ) : (
                    <ProjectsList
                      revision={revision}
                      route={route}
                      nav={nav}
                      open={open}
                    />
                  )
                ) : route.id ? (
                  <PaymentDetail
                    id={route.id}
                    revision={revision}
                    nav={nav}
                    open={open}
                  />
                ) : (
                  <PaymentsList
                    revision={revision}
                    route={route}
                    nav={nav}
                    open={open}
                    handlers={handlers}
                  />
                )}
                <p className="workspace-note">
                  Business date: {date(settings.data.business_date)} ·{" "}
                  {settings.data.business_timezone} ·{" "}
                  {settings.data.currency ?? "Currency not configured"} ·
                  Internal payment discipline only
                </p>
              </>
            )}
          </Feedback>
        </main>
      </div>
      {form && settings.data && (
        <RecordForm
          {...form}
          settings={settings.data}
          onClose={() => setForm(null)}
          onSaved={(id) => {
            setRevision((v) => v + 1);
            setForm(null);
            if (form.kind === "account") account(id);
            if (form.kind === "project") project(id);
            if (form.kind === "payment") payment(id);
          }}
        />
      )}
    </div>
  );
}
