import { afterEach, describe, expect, it, vi } from "vitest";
import {
  cleanup,
  fireEvent,
  render,
  screen,
  waitFor,
} from "@testing-library/react";
import App from "./App";
afterEach(() => {
  cleanup();
  sessionStorage.clear();
  vi.unstubAllGlobals();
});
describe("administrator access", () => {
  it("shows validation feedback when authentication fails", async () => {
    vi.stubGlobal(
      "fetch",
      vi.fn().mockResolvedValue({
        status: 401,
        ok: false,
        json: async () => ({
          error: { message: "Invalid email or password." },
        }),
      }),
    );
    render(<App />);
    fireEvent.change(screen.getByLabelText("Email address"), {
      target: { value: "admin@example.com" },
    });
    fireEvent.change(screen.getByLabelText("Password"), {
      target: { value: "incorrect" },
    });
    fireEvent.click(screen.getByRole("button", { name: /sign in/i }));
    expect(await screen.findByRole("alert")).toHaveTextContent(
      "Invalid email or password.",
    );
    expect(screen.queryByRole("navigation")).not.toBeInTheDocument();
  });
  it("opens the protected shell and revokes the session on logout", async () => {
    const fetch = vi
      .fn()
      .mockImplementation(async (url: string, _options?: RequestInit) => {
        if (url.endsWith("/auth/logout")) return { status: 204, ok: true };
        if (url.endsWith("/auth/login"))
          return {
            status: 200,
            ok: true,
            json: async () => ({
              data: {
                id: "test",
                email: "admin@example.com",
                csrf_token: "csrf-test",
              },
            }),
          };
        if (url.endsWith("/settings"))
          return {
            status: 200,
            ok: true,
            json: async () => ({
              data: {
                currency: "USD",
                business_date: "2026-10-11",
                business_timezone: "Asia/Amman",
              },
            }),
          };
        return {
          status: 200,
          ok: true,
          json: async () => ({
            data: {
              total_accounts: 0,
              active_projects: 0,
              currency: "USD",
              financial: [],
              payment_status_counts: {
                OVERDUE: 0,
                DUE_TODAY: 0,
                UPCOMING: 0,
                PAID_LATE: 0,
                PAID_ON_TIME: 0,
              },
              credit_health_distribution: {},
              accounts_requiring_attention: [],
              upcoming_payments: [],
              overdue_payments: [],
              recent_activity: [],
            },
          }),
        };
      });
    vi.stubGlobal("fetch", fetch);
    render(<App />);
    fireEvent.change(screen.getByLabelText("Email address"), {
      target: { value: "admin@example.com" },
    });
    fireEvent.change(screen.getByLabelText("Password"), {
      target: { value: "test-password" },
    });
    fireEvent.click(screen.getByRole("button", { name: /sign in/i }));
    expect(await screen.findByRole("navigation")).toBeInTheDocument();
    fireEvent.click(screen.getByRole("button", { name: /sign out/i }));
    await waitFor(() =>
      expect(
        screen.getByRole("heading", { name: "Welcome back" }),
      ).toBeInTheDocument(),
    );
    expect(sessionStorage.getItem("csrf")).toBeNull();
    const logoutCall = fetch.mock.calls.find((call) =>
      String(call[0]).endsWith("/auth/logout"),
    );
    expect((logoutCall?.[1] as RequestInit).headers).toMatchObject({
      "X-CSRF-Token": "csrf-test",
    });
  });
});
