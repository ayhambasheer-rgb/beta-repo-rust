#!/bin/bash
source "$(cd "$(dirname "$0")" && pwd)/scripts/mac-common.sh"
ledger_docker
ledger_config
ledger_compose stop </dev/null
printf '\nLedger has stopped. Your records are saved.\n'
printf 'Use Start Ledger.command when you want to use it again.\n'
ledger_pause
