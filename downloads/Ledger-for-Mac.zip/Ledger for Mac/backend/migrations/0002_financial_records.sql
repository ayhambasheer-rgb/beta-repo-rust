CREATE TABLE accounts (
    id UUID PRIMARY KEY,
    name TEXT NOT NULL CHECK (length(trim(name)) BETWEEN 1 AND 200),
    contact_name TEXT NOT NULL CHECK (length(trim(contact_name)) BETWEEN 1 AND 200),
    email TEXT NOT NULL CHECK (length(email) BETWEEN 3 AND 254),
    phone TEXT NOT NULL CHECK (length(trim(phone)) BETWEEN 1 AND 50),
    status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','archived')),
    version BIGINT NOT NULL DEFAULT 1 CHECK (version > 0),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE projects (
    id UUID PRIMARY KEY,
    account_id UUID NOT NULL REFERENCES accounts(id) ON DELETE RESTRICT,
    name TEXT NOT NULL CHECK (length(trim(name)) BETWEEN 1 AND 200),
    description TEXT NOT NULL DEFAULT '' CHECK (length(description) <= 5000),
    contract_value NUMERIC(19,2) NOT NULL CHECK (contract_value >= 0),
    currency VARCHAR(3) NOT NULL CHECK (currency ~ '^[A-Z]{3}$'),
    status TEXT NOT NULL DEFAULT 'planned' CHECK (status IN ('planned','active','completed','archived')),
    start_date DATE NOT NULL,
    end_date DATE,
    version BIGINT NOT NULL DEFAULT 1 CHECK (version > 0),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    CHECK (end_date IS NULL OR end_date >= start_date),
    UNIQUE (id,currency)
);
CREATE INDEX projects_account_idx ON projects(account_id);
CREATE TABLE scheduled_payments (
    id UUID PRIMARY KEY,
    project_id UUID NOT NULL,
    title TEXT NOT NULL CHECK (length(trim(title)) BETWEEN 1 AND 200),
    amount NUMERIC(19,2) NOT NULL CHECK (amount > 0),
    currency VARCHAR(3) NOT NULL,
    due_date DATE NOT NULL,
    settlement_date DATE,
    version BIGINT NOT NULL DEFAULT 1 CHECK (version > 0),
    created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
    FOREIGN KEY (project_id,currency) REFERENCES projects(id,currency) ON DELETE RESTRICT
);
CREATE INDEX payments_project_idx ON scheduled_payments(project_id);
CREATE INDEX payments_unpaid_due_idx ON scheduled_payments(due_date) WHERE settlement_date IS NULL;
CREATE INDEX payments_due_idx ON scheduled_payments(due_date,id);
CREATE TABLE audit_events (
    id UUID PRIMARY KEY,
    actor_id UUID NOT NULL REFERENCES admin_users(id) ON DELETE RESTRICT,
    entity_type TEXT NOT NULL CHECK (entity_type IN ('account','project','payment')),
    entity_id UUID NOT NULL,
    payment_id UUID REFERENCES scheduled_payments(id) ON DELETE RESTRICT,
    action TEXT NOT NULL,
    reason TEXT NOT NULL CHECK (length(trim(reason)) BETWEEN 1 AND 1000),
    before_data JSONB,
    after_data JSONB NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX audit_entity_idx ON audit_events(entity_type,entity_id,created_at);
CREATE FUNCTION prevent_audit_mutation() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
    RAISE EXCEPTION 'Audit history is append-only';
END;
$$;
CREATE TRIGGER immutable_audit BEFORE UPDATE OR DELETE ON audit_events
FOR EACH ROW EXECUTE FUNCTION prevent_audit_mutation();
