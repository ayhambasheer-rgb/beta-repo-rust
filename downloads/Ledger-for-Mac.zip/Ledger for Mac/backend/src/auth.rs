use crate::error::ApiError;
use argon2::{Argon2, PasswordHash, PasswordHasher, PasswordVerifier, password_hash::SaltString};
use axum::{
    Json,
    extract::{Request, State},
    http::{HeaderMap, StatusCode, header},
    middleware::Next,
    response::{IntoResponse, Response},
};
use rand::{RngCore, rngs::OsRng};
use serde::Deserialize;
use serde_json::json;
use sha2::{Digest, Sha256};
use sqlx::{PgPool, Row};
use std::{
    sync::{Arc, Mutex},
    time::{Duration, Instant},
};
use uuid::Uuid;

#[derive(Clone)]
pub struct AppState {
    pub db: PgPool,
    pub origin: String,
    pub secure: bool,
    pub timezone: String,
    pub currency: Option<String>,
    pub dummy_hash: Arc<String>,
    pub attempts: Arc<Mutex<(Instant, u32)>>,
}
fn token() -> String {
    let mut bytes = [0_u8; 32];
    OsRng.fill_bytes(&mut bytes);
    hex::encode(bytes)
}
fn digest(value: &str) -> String {
    hex::encode(Sha256::digest(value.as_bytes()))
}
pub fn hash_password(password: &str) -> Result<String, argon2::password_hash::Error> {
    Argon2::default()
        .hash_password(password.as_bytes(), &SaltString::generate(&mut OsRng))
        .map(|h| h.to_string())
}
fn session_token(headers: &HeaderMap) -> Result<String, ApiError> {
    headers
        .get(header::COOKIE)
        .and_then(|v| v.to_str().ok())
        .and_then(|cookies| {
            cookies
                .split(';')
                .filter_map(|c| c.trim().split_once('='))
                .find(|(k, _)| *k == "payment_session")
                .map(|(_, v)| v.to_owned())
        })
        .filter(|v| v.len() == 64 && v.bytes().all(|b| b.is_ascii_hexdigit()))
        .ok_or_else(ApiError::unauthorized)
}
fn check_origin(state: &AppState, headers: &HeaderMap) -> Result<(), ApiError> {
    if headers.get(header::ORIGIN).and_then(|v| v.to_str().ok()) == Some(state.origin.as_str()) {
        Ok(())
    } else {
        Err(ApiError::forbidden())
    }
}
fn cookie(state: &AppState, value: &str, age: u32) -> String {
    format!(
        "payment_session={value}; Path=/api; HttpOnly; SameSite=Strict; Max-Age={age}{}",
        if state.secure { "; Secure" } else { "" }
    )
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Login {
    email: String,
    password: String,
}

pub async fn login(
    State(state): State<AppState>,
    headers: HeaderMap,
    payload: Result<Json<Login>, axum::extract::rejection::JsonRejection>,
) -> Result<Response, ApiError> {
    check_origin(&state, &headers)?;
    {
        let mut counter = state.attempts.lock().map_err(|_| {
            ApiError(
                StatusCode::INTERNAL_SERVER_ERROR,
                "internal_error",
                "Request unavailable.",
            )
        })?;
        if counter.0.elapsed() >= Duration::from_secs(60) {
            *counter = (Instant::now(), 0);
        }
        if counter.1 >= 30 {
            return Err(ApiError(
                StatusCode::TOO_MANY_REQUESTS,
                "rate_limited",
                "Too many login attempts. Try again in one minute.",
            ));
        }
        counter.1 += 1;
    }
    let Json(input) = payload.map_err(|_| {
        ApiError(
            StatusCode::UNPROCESSABLE_ENTITY,
            "validation_error",
            "Provide an email and password.",
        )
    })?;
    let email = input.email.trim().to_lowercase();
    if email.len() > 254 || input.password.len() > 1024 || input.password.is_empty() {
        return Err(ApiError(
            StatusCode::UNAUTHORIZED,
            "invalid_credentials",
            "Invalid email or password.",
        ));
    }
    let user =
        sqlx::query("SELECT id, password_hash FROM admin_users WHERE email = $1 AND active = true")
            .bind(&email)
            .fetch_optional(&state.db)
            .await?;
    let hash = user
        .as_ref()
        .map(|row| row.get::<String, _>("password_hash"))
        .unwrap_or_else(|| (*state.dummy_hash).clone());
    let verified = tokio::task::spawn_blocking(move || {
        PasswordHash::new(&hash).ok().is_some_and(|h| {
            Argon2::default()
                .verify_password(input.password.as_bytes(), &h)
                .is_ok()
        })
    })
    .await
    .map_err(|_| {
        ApiError(
            StatusCode::INTERNAL_SERVER_ERROR,
            "internal_error",
            "Request unavailable.",
        )
    })?;
    let user = user.filter(|_| verified).ok_or(ApiError(
        StatusCode::UNAUTHORIZED,
        "invalid_credentials",
        "Invalid email or password.",
    ))?;
    let user_id: Uuid = user.get("id");
    let session = token();
    let csrf = token();
    let mut tx = state.db.begin().await?;
    sqlx::query("DELETE FROM sessions WHERE expires_at <= now()")
        .execute(&mut *tx)
        .await?;
    if let Ok(old) = session_token(&headers) {
        sqlx::query("DELETE FROM sessions WHERE token_hash = $1")
            .bind(digest(&old))
            .execute(&mut *tx)
            .await?;
    }
    sqlx::query("INSERT INTO sessions (id, admin_user_id, token_hash, csrf_hash, expires_at) VALUES ($1,$2,$3,$4,now() + interval '8 hours')")
        .bind(Uuid::new_v4()).bind(user_id).bind(digest(&session)).bind(digest(&csrf)).execute(&mut *tx).await?;
    tx.commit().await?;
    Ok((
        [(header::SET_COOKIE, cookie(&state, &session, 28800))],
        Json(json!({"data": {"id": user_id, "email": email, "csrf_token": csrf}})),
    )
        .into_response())
}
pub async fn current(
    state: &AppState,
    headers: &HeaderMap,
) -> Result<sqlx::postgres::PgRow, ApiError> {
    sqlx::query("SELECT u.id, u.email, s.csrf_hash FROM sessions s JOIN admin_users u ON u.id = s.admin_user_id WHERE s.token_hash = $1 AND s.expires_at > now() AND u.active = true")
        .bind(digest(&session_token(headers)?)).fetch_optional(&state.db).await?.ok_or_else(ApiError::unauthorized)
}
pub async fn me(
    State(state): State<AppState>,
    headers: HeaderMap,
) -> Result<Json<serde_json::Value>, ApiError> {
    let row = current(&state, &headers).await?;
    Ok(Json(
        json!({"data": {"id": row.get::<Uuid,_>("id"), "email": row.get::<String,_>("email")}}),
    ))
}
pub async fn logout(
    State(state): State<AppState>,
    headers: HeaderMap,
) -> Result<Response, ApiError> {
    check_origin(&state, &headers)?;
    let row = current(&state, &headers).await?;
    let csrf = headers
        .get("x-csrf-token")
        .and_then(|h| h.to_str().ok())
        .ok_or_else(ApiError::forbidden)?;
    if digest(csrf) != row.get::<String, _>("csrf_hash") {
        return Err(ApiError::forbidden());
    }
    sqlx::query("DELETE FROM sessions WHERE token_hash = $1")
        .bind(digest(&session_token(&headers)?))
        .execute(&state.db)
        .await?;
    Ok((
        [(header::SET_COOKIE, cookie(&state, "", 0))],
        StatusCode::NO_CONTENT,
    )
        .into_response())
}
pub async fn security_headers(request: Request, next: Next) -> Response {
    let mut response = next.run(request).await;
    let headers = response.headers_mut();
    headers.insert(header::CACHE_CONTROL, "no-store".parse().unwrap());
    headers.insert("x-content-type-options", "nosniff".parse().unwrap());
    headers.insert("referrer-policy", "same-origin".parse().unwrap());
    response
}
/// Authenticate every domain request; verify CSRF and Origin for every mutation.
pub async fn protect(
    State(state): State<AppState>,
    mut request: Request,
    next: Next,
) -> Result<Response, ApiError> {
    let row = current(&state, request.headers()).await?;
    if !matches!(
        *request.method(),
        axum::http::Method::GET | axum::http::Method::HEAD | axum::http::Method::OPTIONS
    ) {
        check_origin(&state, request.headers())?;
        let csrf = request
            .headers()
            .get("x-csrf-token")
            .and_then(|h| h.to_str().ok())
            .ok_or_else(ApiError::forbidden)?;
        if digest(csrf) != row.get::<String, _>("csrf_hash") {
            return Err(ApiError::forbidden());
        }
    }
    request.extensions_mut().insert(Admin { id: row.get("id") });
    Ok(next.run(request).await)
}
#[derive(Clone, Copy)]
pub struct Admin {
    pub id: Uuid,
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn password_hash_verification() {
        let hash = hash_password("long-test-password").unwrap();
        let parsed = PasswordHash::new(&hash).unwrap();
        assert!(
            Argon2::default()
                .verify_password(b"long-test-password", &parsed)
                .is_ok()
        );
        assert!(
            Argon2::default()
                .verify_password(b"wrong-password", &parsed)
                .is_err()
        );
    }
    #[test]
    fn malformed_cookie_rejected() {
        let mut headers = HeaderMap::new();
        headers.insert(header::COOKIE, "payment_session=invalid".parse().unwrap());
        assert!(session_token(&headers).is_err());
    }
}
