use crate::error::ApiError;
use serde_json::Value;
use sqlx::{Postgres, Transaction};
use uuid::Uuid;

pub struct Change<'a> {
    pub actor: Uuid,
    pub entity: &'a str,
    pub id: Uuid,
    pub action: &'a str,
    pub reason: &'a str,
    pub before: Option<Value>,
    pub after: Value,
}
pub async fn record(
    tx: &mut Transaction<'_, Postgres>,
    change: Change<'_>,
) -> Result<(), ApiError> {
    sqlx::query("INSERT INTO audit_events (id,actor_id,entity_type,entity_id,payment_id,action,reason,before_data,after_data) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)")
        .bind(Uuid::new_v4()).bind(change.actor).bind(change.entity).bind(change.id).bind(if change.entity=="payment" {Some(change.id)} else {None}).bind(change.action).bind(change.reason).bind(change.before).bind(change.after).execute(&mut **tx).await?;
    Ok(())
}

pub async fn history(
    state: &crate::auth::AppState,
    entity: &str,
    id: Uuid,
    q: &crate::common::ListQuery,
) -> Result<axum::Json<Value>, ApiError> {
    use serde_json::json;
    use sqlx::Row;
    let total: i64 = sqlx::query_scalar(
        "SELECT count(*) FROM audit_events WHERE entity_type=$1 AND entity_id=$2",
    )
    .bind(entity)
    .bind(id)
    .fetch_one(&state.db)
    .await?;
    let rows=sqlx::query("SELECT e.*,u.email actor_email FROM audit_events e JOIN admin_users u ON u.id=e.actor_id WHERE entity_type=$1 AND entity_id=$2 ORDER BY created_at DESC,id LIMIT $3 OFFSET $4").bind(entity).bind(id).bind(q.size()).bind(q.offset()).fetch_all(&state.db).await?;
    let data:Vec<Value>=rows.into_iter().map(|r|json!({"id":r.get::<Uuid,_>("id"),"action":r.get::<String,_>("action"),"reason":r.get::<String,_>("reason"),"actor_email":r.get::<String,_>("actor_email"),"before":r.get::<Option<Value>,_>("before_data"),"after":r.get::<Value,_>("after_data"),"created_at":r.get::<chrono::DateTime<chrono::Utc>,_>("created_at")})).collect();
    Ok(q.envelope(json!(data), total, crate::common::business_date(state)))
}
