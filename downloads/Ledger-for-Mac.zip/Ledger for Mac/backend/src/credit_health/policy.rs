use crate::payments::repository::PaymentView;
use chrono::{Days, NaiveDate};
use rust_decimal::Decimal;
use serde::Serialize;
use std::collections::BTreeMap;
use uuid::Uuid;

pub const CLASSES: &[&str] = &["HEALTHY", "AT_RISK", "RECOVERING", "POOR", "UNRATED"];
#[derive(Serialize)]
pub struct Exposure {
    pub currency: String,
    pub overdue_amount: Decimal,
    pub matured_exposure: Decimal,
    pub overdue_percent: Decimal,
}
#[derive(Serialize)]
pub struct Assessment {
    pub classification: &'static str,
    pub policy_version: &'static str,
    pub as_of_date: NaiveDate,
    pub window_start: NaiveDate,
    pub on_time_rate: Option<Decimal>,
    pub settled_count: usize,
    pub historical_late_count: usize,
    pub lifetime_late_count: usize,
    pub overdue_count: usize,
    pub max_days_overdue: i64,
    pub exposure: Vec<Exposure>,
    pub recovery_streak: usize,
    pub reasons: Vec<String>,
    pub contributing_payment_ids: Vec<Uuid>,
    pub disclaimer: &'static str,
}
pub fn assess(rows: &[PaymentView], today: NaiveDate) -> Assessment {
    let start = today
        .checked_sub_days(Days::new(365))
        .expect("business date range");
    let recent: Vec<_> = rows
        .iter()
        .filter(|r| r.payment.due_date >= start && r.payment.due_date <= today)
        .collect();
    let settled: Vec<_> = recent
        .iter()
        .filter(|r| r.payment.settlement_date.is_some())
        .collect();
    let late: Vec<_> = settled
        .iter()
        .filter(|r| {
            r.payment
                .settlement_date
                .is_some_and(|d| d > r.payment.due_date)
        })
        .collect();
    let overdue: Vec<_> = rows
        .iter()
        .filter(|r| r.payment.settlement_date.is_none() && r.payment.due_date < today)
        .collect();
    let lifetime_late_count = rows
        .iter()
        .filter(|r| {
            r.payment
                .settlement_date
                .is_some_and(|d| d > r.payment.due_date)
        })
        .count();
    let max_days = overdue
        .iter()
        .map(|r| (today - r.payment.due_date).num_days())
        .max()
        .unwrap_or(0);
    let rate = if settled.is_empty() {
        None
    } else {
        Some(
            Decimal::from((settled.len() - late.len()) as u64)
                / Decimal::from(settled.len() as u64)
                * Decimal::from(100),
        )
    };
    let mut exposure: BTreeMap<String, (Decimal, Decimal)> = BTreeMap::new();
    for r in rows {
        let p = &r.payment;
        let outstanding = p.settlement_date.is_none() && p.due_date < today;
        if (p.due_date >= start && p.due_date <= today) || outstanding {
            exposure.entry(p.currency.clone()).or_default().1 += p.amount;
        }
        if outstanding {
            exposure.entry(p.currency.clone()).or_default().0 += p.amount;
        }
    }
    let exposure: Vec<_> = exposure
        .into_iter()
        .map(|(currency, (overdue_amount, matured_exposure))| Exposure {
            currency,
            overdue_amount,
            matured_exposure,
            overdue_percent: if matured_exposure > Decimal::ZERO {
                overdue_amount / matured_exposure * Decimal::from(100)
            } else {
                Decimal::ZERO
            },
        })
        .collect();
    let last_late_due = late.iter().map(|r| r.payment.due_date).max();
    let mut groups: BTreeMap<NaiveDate, Vec<&PaymentView>> = BTreeMap::new();
    if let Some(last) = last_late_due {
        for r in &recent {
            if r.payment.due_date > last {
                groups.entry(r.payment.due_date).or_default().push(r);
            }
        }
    }
    let mut streak = 0;
    for (due, group) in groups {
        // An unfinished due-today group has not yet missed its deadline.
        if due == today && group.iter().any(|r| r.payment.settlement_date.is_none()) {
            continue;
        }
        if group
            .iter()
            .all(|r| r.payment.settlement_date.is_some_and(|d| d <= due))
        {
            streak += 1;
        } else {
            streak = 0;
        }
    }
    let mut reasons = Vec::new();
    let severe_amount = exposure
        .iter()
        .any(|e| e.overdue_percent >= Decimal::from(25));
    if max_days >= 30 {
        reasons.push(format!(
            "An outstanding obligation is {max_days} days overdue (threshold: 30)."
        ));
    }
    if overdue.len() >= 3 {
        reasons.push(format!(
            "{} obligations remain overdue (threshold: 3).",
            overdue.len()
        ));
    }
    if severe_amount {
        for e in &exposure {
            if e.overdue_percent >= Decimal::from(25) {
                reasons.push(format!(
                    "{}% of matured {} exposure is overdue (threshold: 25%).",
                    e.overdue_percent.round_dp(2),
                    e.currency
                ));
            }
        }
    }
    let repeated = late.len() >= 3
        && Decimal::from(late.len() as u64) / Decimal::from(settled.len().max(1) as u64)
            >= Decimal::new(40, 2);
    if repeated {
        reasons.push(format!(
            "{} recent settlements were late, representing at least 40% of recent settlements.",
            late.len()
        ));
    }
    let recovered = overdue.is_empty()
        && !late.is_empty()
        && streak >= 6
        && rate.is_some_and(|r| r >= Decimal::from(90));
    let classification = if max_days >= 30 || overdue.len() >= 3 || severe_amount || repeated {
        "POOR"
    } else if !overdue.is_empty() {
        reasons.push(format!("{} obligations remain overdue.", overdue.len()));
        "AT_RISK"
    } else if recovered {
        reasons.clear();
        reasons.push(format!("{streak} consecutive matured due-date groups paid on time after the latest late obligation; on-time rate is at least 90%."));
        "HEALTHY"
    } else if !late.is_empty() && streak >= 3 {
        reasons.clear();
        reasons.push(format!("No overdue debt remains; {streak} consecutive matured due-date groups were paid on time after the latest late obligation."));
        "RECOVERING"
    } else if !late.is_empty() {
        reasons.push(format!("{} recent settlements were late; three subsequent on-time due-date groups are needed to enter recovery.",late.len()));
        "AT_RISK"
    } else if settled.len() < 3 {
        reasons.push(format!("Only {} matured settlements are available; at least three are needed for a favorable reliability assessment.",settled.len()));
        "UNRATED"
    } else {
        reasons.push(format!(
            "All {} recent matured settlements were on time and no debt is overdue.",
            settled.len()
        ));
        "HEALTHY"
    };
    if lifetime_late_count > late.len() {
        reasons.push(format!(
            "{} earlier late settlements remain in lifetime history outside the assessment window.",
            lifetime_late_count - late.len()
        ));
    }
    let contributing_payment_ids = rows
        .iter()
        .filter(|r| {
            (r.payment.settlement_date.is_none() && r.payment.due_date < today)
                || (r.payment.due_date >= start && r.payment.due_date <= today)
        })
        .map(|r| r.payment.id)
        .collect();
    Assessment {
        classification,
        policy_version: "payment-discipline-v1",
        as_of_date: today,
        window_start: start,
        on_time_rate: rate.map(|r| r.round_dp(2)),
        settled_count: settled.len(),
        historical_late_count: late.len(),
        lifetime_late_count,
        overdue_count: overdue.len(),
        max_days_overdue: max_days,
        exposure,
        recovery_streak: streak,
        reasons,
        contributing_payment_ids,
        disclaimer: "Internal payment-discipline assessment; not a credit bureau score and no external reporting.",
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    use crate::payments::repository::{Payment, PaymentView};
    use chrono::Utc;
    fn row(offset: i64, late: Option<i64>) -> PaymentView {
        let today = NaiveDate::from_ymd_opt(2026, 10, 11).unwrap();
        let due = today + chrono::Duration::days(offset);
        PaymentView {
            payment: Payment {
                id: Uuid::new_v4(),
                project_id: Uuid::new_v4(),
                title: "Fixture".into(),
                amount: Decimal::from(100),
                currency: "USD".into(),
                due_date: due,
                settlement_date: late.map(|d| due + chrono::Duration::days(d)),
                version: 1,
                created_at: Utc::now(),
                updated_at: Utc::now(),
            },
            account_id: Uuid::new_v4(),
            account_name: "Fixture".into(),
            project_name: "Fixture".into(),
        }
    }
    fn today() -> NaiveDate {
        NaiveDate::from_ymd_opt(2026, 10, 11).unwrap()
    }
    #[test]
    fn insufficient_history() {
        assert_eq!(assess(&[], today()).classification, "UNRATED");
        assert_eq!(
            assess(&[row(-2, Some(0))], today()).classification,
            "UNRATED"
        );
    }
    #[test]
    fn healthy_and_overdue() {
        let mut rows = vec![row(-20, Some(0)), row(-10, Some(-1)), row(-5, Some(0))];
        assert_eq!(assess(&rows, today()).classification, "HEALTHY");
        rows.push(row(-31, None));
        assert_eq!(assess(&rows, today()).classification, "POOR");
    }
    #[test]
    fn late_payment_recovery_and_future_exclusion() {
        let mut rows = vec![row(-100, Some(1))];
        assert_eq!(assess(&rows, today()).classification, "AT_RISK");
        for d in [-80, -60, -40] {
            rows.push(row(d, Some(0)));
        }
        assert_eq!(assess(&rows, today()).classification, "RECOVERING");
        for d in [-30, -20, -10, -9, -8, -7] {
            rows.push(row(d, Some(0)));
        }
        assert_eq!(assess(&rows, today()).classification, "HEALTHY");
        let mut future = vec![row(-2, Some(1))];
        for d in [1, 2, 3] {
            future.push(row(d, Some(-5)));
        }
        assert_eq!(assess(&future, today()).recovery_streak, 0);
    }
    #[test]
    fn same_day_groups_and_pending_today() {
        let rows = vec![
            row(-10, Some(1)),
            row(-5, Some(0)),
            row(-5, Some(0)),
            row(0, None),
        ];
        assert_eq!(assess(&rows, today()).recovery_streak, 1);
    }
    #[test]
    fn short_overdue_exposure_and_archived_history() {
        let mut rows: Vec<_> = (1..=10).map(|d| row(-d, Some(0))).collect();
        rows.push(row(-1, None));
        let a = assess(&rows, today());
        assert_eq!(a.classification, "AT_RISK");
        assert_eq!(a.overdue_count, 1);
        assert_eq!(a.lifetime_late_count, 0);
    }
    #[test]
    fn severity_thresholds_and_historical_window() {
        let rows = vec![
            row(-10, Some(1)),
            row(-9, Some(1)),
            row(-8, Some(1)),
            row(-7, Some(0)),
            row(-6, Some(0)),
            row(-5, Some(0)),
        ];
        assert_eq!(assess(&rows, today()).classification, "POOR");
        let mut improved = rows;
        improved.extend([row(-4, Some(0)), row(-3, Some(0))]);
        assert_eq!(assess(&improved, today()).classification, "RECOVERING");
        let old = vec![row(-400, Some(2))];
        let a = assess(&old, today());
        assert_eq!(a.classification, "UNRATED");
        assert_eq!(a.lifetime_late_count, 1);
        assert_eq!(a.historical_late_count, 0);
        assert_eq!(assess(&[row(-400, None)], today()).classification, "POOR");
    }
    #[test]
    fn exposure_is_not_diluted_across_currencies() {
        let mut rows = vec![
            row(-4, Some(0)),
            row(-3, Some(0)),
            row(-2, Some(0)),
            row(-1, None),
        ];
        assert_eq!(assess(&rows, today()).classification, "POOR");
        let mut other = row(-1, Some(0));
        other.payment.currency = "EUR".into();
        other.payment.amount = Decimal::from(10000);
        rows.push(other);
        let a = assess(&rows, today());
        assert_eq!(a.classification, "POOR");
        assert_eq!(a.exposure.len(), 2);
    }
}
