pub mod policy;
use crate::{
    auth::AppState,
    common::{self, Id},
    error::ApiError,
};
use axum::{Json, Router, extract::State, routing::get};
use serde_json::{Value, json};
pub fn routes() -> Router<AppState> {
    Router::new().route("/api/v1/accounts/{id}/credit-health", get(detail))
}
async fn detail(State(state): State<AppState>, Id(id): Id) -> Result<Json<Value>, ApiError> {
    crate::accounts::repository::one(&state.db, id).await?;
    let rows = crate::payments::repository::snapshot(&state.db, Some(id), None).await?;
    Ok(Json(
        json!({"data":policy::assess(&rows,common::business_date(&state))}),
    ))
}
