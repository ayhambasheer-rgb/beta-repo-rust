use std::env;

pub struct Config {
    pub database_url: String,
    pub origin: String,
    pub bind: String,
    pub secure: bool,
    pub timezone: String,
    pub currency: Option<String>,
    pub migrate_on_start: bool,
}
impl Config {
    pub fn load() -> Result<Self, Box<dyn std::error::Error>> {
        let origin = env::var("APP_ORIGIN")?;
        let secure = env::var("COOKIE_SECURE")
            .unwrap_or_else(|_| "true".into())
            .parse::<bool>()?;
        let parsed = url::Url::parse(&origin)?;
        let valid_origin = parsed.path() == "/"
            && parsed.query().is_none()
            && parsed.fragment().is_none()
            && parsed.username().is_empty()
            && parsed.password().is_none()
            && !origin.ends_with('/');
        let valid_scheme = parsed.scheme() == "https"
            || (!secure && parsed.scheme() == "http" && parsed.host_str() == Some("localhost"));
        if !valid_origin || !valid_scheme {
            return Err("APP_ORIGIN must be an HTTPS origin (localhost HTTP allowed with COOKIE_SECURE=false)".into());
        }
        let timezone = env::var("BUSINESS_TIMEZONE").unwrap_or_else(|_| "Asia/Amman".into());
        timezone.parse::<chrono_tz::Tz>()?;
        let currency = env::var("BUSINESS_CURRENCY").ok();
        if currency
            .as_ref()
            .is_some_and(|c| c.len() != 3 || !c.bytes().all(|b| b.is_ascii_uppercase()))
        {
            return Err("BUSINESS_CURRENCY must be an uppercase three-letter currency code".into());
        }
        Ok(Self {
            database_url: env::var("DATABASE_URL")?,
            origin,
            bind: env::var("BIND_ADDRESS").unwrap_or_else(|_| "127.0.0.1:3000".into()),
            secure,
            timezone,
            currency,
            migrate_on_start: env::var("MIGRATE_ON_START")
                .unwrap_or_else(|_| "true".into())
                .parse()?,
        })
    }
}
