mod accounts;
mod audit;
mod auth;
mod common;
mod config;
mod credit_health;
mod dashboard;
mod db;
mod error;
mod payments;
mod projects;
use auth::AppState;
use axum::{
    Json, Router,
    extract::State,
    middleware,
    routing::{get, post},
};
use serde_json::json;
use sqlx::postgres::PgPoolOptions;
use std::{
    sync::{Arc, Mutex},
    time::Instant,
};
use uuid::Uuid;

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    tracing_subscriber::fmt()
        .with_env_filter("payment_health_api=info")
        .init();
    let config = config::Config::load()?;
    let db = PgPoolOptions::new()
        .max_connections(10)
        .connect(&config.database_url)
        .await?;
    let command = std::env::args().nth(1);
    db::prepare(
        &db,
        config.migrate_on_start || command.as_deref() == Some("migrate"),
    )
    .await?;
    if command.as_deref() == Some("migrate") {
        println!("Migrations applied and verified.");
        return Ok(());
    }
    if let Some(currency) = &config.currency {
        let mismatch: bool =
            sqlx::query_scalar("SELECT EXISTS(SELECT 1 FROM projects WHERE currency<>$1)")
                .bind(currency)
                .fetch_one(&db)
                .await?;
        if mismatch {
            return Err("BUSINESS_CURRENCY must match existing project currencies".into());
        }
    }
    if command.as_deref() == Some("provision-admin") {
        let email = std::env::var("ADMIN_EMAIL")?.trim().to_lowercase();
        let password = std::env::var("ADMIN_PASSWORD")?;
        if !email.contains('@') || email.len() > 254 || password.len() < 12 || password.len() > 1024
        {
            return Err("Use a valid email and a password of 12–1024 bytes".into());
        }
        let hash = auth::hash_password(&password).map_err(|_| "Password hashing failed")?;
        sqlx::query("INSERT INTO admin_users (id, email, password_hash) VALUES ($1,$2,$3)")
            .bind(Uuid::new_v4())
            .bind(email)
            .bind(hash)
            .execute(&db)
            .await?;
        println!("Administrator created.");
        return Ok(());
    }
    let dummy_hash = Arc::new(
        auth::hash_password(&Uuid::new_v4().to_string()).map_err(|_| "Password hashing failed")?,
    );
    let state = AppState {
        db,
        origin: config.origin,
        secure: config.secure,
        timezone: config.timezone,
        currency: config.currency,
        dummy_hash,
        attempts: Arc::new(Mutex::new((Instant::now(), 0))),
    };
    let app = router(state);
    let listener = tokio::net::TcpListener::bind(&config.bind).await?;
    tracing::info!(address = %config.bind, "API listening");
    axum::serve(listener, app)
        .with_graceful_shutdown(async {
            let _ = tokio::signal::ctrl_c().await;
        })
        .await?;
    Ok(())
}
async fn health(State(state): State<AppState>) -> Result<Json<serde_json::Value>, error::ApiError> {
    sqlx::query("SELECT 1").execute(&state.db).await?;
    Ok(Json(
        json!({"data": {"status": "ok", "business_timezone": state.timezone}}),
    ))
}

fn router(state: AppState) -> Router {
    let protected = Router::new()
        .merge(accounts::routes())
        .merge(projects::routes())
        .merge(payments::routes())
        .merge(credit_health::routes())
        .merge(dashboard::routes())
        .route("/api/v1/settings", get(common::settings))
        .route_layer(middleware::from_fn_with_state(state.clone(), auth::protect));
    Router::new()
        .merge(protected)
        .route("/api/v1/health", get(health))
        .route("/api/v1/auth/login", post(auth::login))
        .route("/api/v1/auth/me", get(auth::me))
        .route("/api/v1/auth/logout", post(auth::logout))
        .fallback(|| async {
            error::ApiError(
                axum::http::StatusCode::NOT_FOUND,
                "not_found",
                "Endpoint not found.",
            )
        })
        .method_not_allowed_fallback(|| async {
            error::ApiError(
                axum::http::StatusCode::METHOD_NOT_ALLOWED,
                "method_not_allowed",
                "Method not allowed.",
            )
        })
        .layer(axum::extract::DefaultBodyLimit::max(16 * 1024))
        .layer(middleware::from_fn(auth::security_headers))
        .with_state(state)
}

#[cfg(test)]
mod integration_tests {
    use super::*;
    use axum::{
        body::{Body, to_bytes},
        http::{Request, StatusCode},
    };
    use tower::ServiceExt;
    async fn call(
        app: &Router,
        method: &str,
        path: &str,
        body: &str,
        cookie: Option<&str>,
        csrf: Option<&str>,
        origin: bool,
    ) -> axum::response::Response {
        let mut req = Request::builder()
            .method(method)
            .uri(path)
            .header("content-type", "application/json");
        if origin {
            req = req.header("origin", "http://localhost:5173");
        }
        if let Some(value) = cookie {
            req = req.header("cookie", value);
        }
        if let Some(value) = csrf {
            req = req.header("x-csrf-token", value);
        }
        app.clone()
            .oneshot(req.body(Body::from(body.to_owned())).unwrap())
            .await
            .unwrap()
    }
    #[sqlx::test]
    async fn session_lifecycle_and_security(db: sqlx::PgPool) {
        let password = "integration-password-123";
        let user = Uuid::new_v4();
        sqlx::query("INSERT INTO admin_users (id,email,password_hash) VALUES ($1,$2,$3)")
            .bind(user)
            .bind("admin@example.test")
            .bind(auth::hash_password(password).unwrap())
            .execute(&db)
            .await
            .unwrap();
        let state = AppState {
            db: db.clone(),
            origin: "http://localhost:5173".into(),
            secure: true,
            timezone: "Asia/Amman".into(),
            currency: Some("USD".into()),
            dummy_hash: Arc::new(auth::hash_password("dummy-password").unwrap()),
            attempts: Arc::new(Mutex::new((Instant::now(), 0))),
        };
        let app = router(state.clone());
        assert_eq!(
            call(&app, "GET", "/api/v1/auth/me", "", None, None, false)
                .await
                .status(),
            StatusCode::UNAUTHORIZED
        );
        let login_body =
            serde_json::json!({"email":"ADMIN@example.test", "password":password}).to_string();
        assert_eq!(
            call(
                &app,
                "POST",
                "/api/v1/auth/login",
                &login_body,
                None,
                None,
                false
            )
            .await
            .status(),
            StatusCode::FORBIDDEN
        );
        assert_eq!(
            call(
                &app,
                "POST",
                "/api/v1/auth/login",
                r#"{"email":"admin@example.test","password":"wrong"}"#,
                None,
                None,
                true
            )
            .await
            .status(),
            StatusCode::UNAUTHORIZED
        );
        assert_eq!(
            call(&app, "POST", "/api/v1/auth/login", "{}", None, None, true)
                .await
                .status(),
            StatusCode::UNPROCESSABLE_ENTITY
        );
        let response = call(
            &app,
            "POST",
            "/api/v1/auth/login",
            &login_body,
            None,
            None,
            true,
        )
        .await;
        assert_eq!(response.status(), StatusCode::OK);
        let set_cookie = response.headers()["set-cookie"]
            .to_str()
            .unwrap()
            .to_string();
        assert!(
            set_cookie.contains("HttpOnly")
                && set_cookie.contains("Secure")
                && set_cookie.contains("SameSite=Strict")
        );
        let cookie = set_cookie.split(';').next().unwrap();
        let json: serde_json::Value =
            serde_json::from_slice(&to_bytes(response.into_body(), 16384).await.unwrap()).unwrap();
        let csrf = json["data"]["csrf_token"].as_str().unwrap();
        assert_eq!(
            call(
                &app,
                "GET",
                "/api/v1/auth/me",
                "",
                Some(cookie),
                None,
                false
            )
            .await
            .status(),
            StatusCode::OK
        );
        assert_eq!(
            call(
                &app,
                "POST",
                "/api/v1/auth/logout",
                "",
                Some(cookie),
                None,
                true
            )
            .await
            .status(),
            StatusCode::FORBIDDEN
        );
        assert_eq!(
            call(
                &app,
                "POST",
                "/api/v1/auth/logout",
                "",
                Some(cookie),
                Some(csrf),
                false
            )
            .await
            .status(),
            StatusCode::FORBIDDEN
        );
        assert_eq!(
            call(
                &app,
                "POST",
                "/api/v1/auth/logout",
                "",
                Some(cookie),
                Some(csrf),
                true
            )
            .await
            .status(),
            StatusCode::NO_CONTENT
        );
        assert_eq!(
            call(
                &app,
                "GET",
                "/api/v1/auth/me",
                "",
                Some(cookie),
                None,
                false
            )
            .await
            .status(),
            StatusCode::UNAUTHORIZED
        );
        let response = call(
            &app,
            "POST",
            "/api/v1/auth/login",
            &login_body,
            None,
            None,
            true,
        )
        .await;
        let cookie = response.headers()["set-cookie"]
            .to_str()
            .unwrap()
            .split(';')
            .next()
            .unwrap()
            .to_owned();
        sqlx::query("UPDATE sessions SET expires_at = now() - interval '1 second'")
            .execute(&db)
            .await
            .unwrap();
        assert_eq!(
            call(
                &app,
                "GET",
                "/api/v1/auth/me",
                "",
                Some(&cookie),
                None,
                false
            )
            .await
            .status(),
            StatusCode::UNAUTHORIZED
        );
        sqlx::query("UPDATE admin_users SET active = false")
            .execute(&db)
            .await
            .unwrap();
        assert_eq!(
            call(
                &app,
                "POST",
                "/api/v1/auth/login",
                &login_body,
                None,
                None,
                true
            )
            .await
            .status(),
            StatusCode::UNAUTHORIZED
        );
        *state.attempts.lock().unwrap() = (Instant::now(), 30);
        assert_eq!(
            call(
                &app,
                "POST",
                "/api/v1/auth/login",
                &login_body,
                None,
                None,
                true
            )
            .await
            .status(),
            StatusCode::TOO_MANY_REQUESTS
        );
    }
}

#[cfg(test)]
mod workflow_tests;
