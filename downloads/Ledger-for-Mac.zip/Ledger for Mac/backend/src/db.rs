use sqlx::PgPool;

pub async fn prepare(db: &PgPool, apply: bool) -> Result<(), Box<dyn std::error::Error>> {
    let migrator = sqlx::migrate!();
    if apply {
        migrator.run(db).await?;
    } else {
        let applied: Vec<(i64, Vec<u8>, bool)> = sqlx::query_as(
            "SELECT version,checksum,success FROM _sqlx_migrations ORDER BY version",
        )
        .fetch_all(db)
        .await?;
        let expected: Vec<_> = migrator
            .iter()
            .filter(|m| m.migration_type.is_up_migration())
            .collect();
        if applied.len() != expected.len()
            || expected.iter().any(|m| {
                !applied.iter().any(|(version, checksum, success)| {
                    *version == m.version && checksum.as_slice() == m.checksum.as_ref() && *success
                })
            })
        {
            return Err("Database migrations are missing, changed, failed, or newer than this binary; run the controlled migration command".into());
        }
    }
    Ok(())
}
#[cfg(test)]
mod tests {
    #[sqlx::test]
    async fn read_only_readiness_rejects_missing_migrations(db: sqlx::PgPool) {
        assert!(super::prepare(&db, false).await.is_ok());
        sqlx::query("DELETE FROM _sqlx_migrations WHERE version=2")
            .execute(&db)
            .await
            .unwrap();
        assert!(super::prepare(&db, false).await.is_err());
    }
}
