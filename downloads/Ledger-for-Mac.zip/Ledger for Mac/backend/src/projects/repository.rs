use crate::{
    common::{ListQuery, missing},
    error::ApiError,
};
use chrono::{DateTime, NaiveDate, Utc};
use rust_decimal::Decimal;
use serde::Serialize;
use sqlx::{FromRow, PgPool};
use uuid::Uuid;
#[derive(Serialize, FromRow)]
pub struct Project {
    pub id: Uuid,
    pub account_id: Uuid,
    pub name: String,
    pub description: String,
    pub contract_value: Decimal,
    pub currency: String,
    pub status: String,
    pub start_date: NaiveDate,
    pub end_date: Option<NaiveDate>,
    pub version: i64,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
}
#[derive(Serialize, FromRow)]
pub struct ProjectView {
    #[serde(flatten)]
    #[sqlx(flatten)]
    pub project: Project,
    pub account_name: String,
}
pub async fn one(db: &PgPool, id: Uuid) -> Result<ProjectView, ApiError> {
    sqlx::query_as("SELECT p.*,a.name account_name FROM projects p JOIN accounts a ON a.id=p.account_id WHERE p.id=$1").bind(id).fetch_optional(db).await?.ok_or_else(missing)
}
pub async fn list(db: &PgPool, q: &ListQuery) -> Result<(Vec<ProjectView>, i64), ApiError> {
    let count=sqlx::query_scalar("SELECT count(*) FROM projects p WHERE p.name ILIKE $1 AND ($2::text IS NULL OR p.status=$2) AND ($3::uuid IS NULL OR p.account_id=$3)").bind(q.pattern()).bind(&q.status).bind(q.account_id).fetch_one(db).await?;
    let rows=sqlx::query_as("SELECT p.*,a.name account_name FROM projects p JOIN accounts a ON a.id=p.account_id WHERE p.name ILIKE $1 AND ($2::text IS NULL OR p.status=$2) AND ($3::uuid IS NULL OR p.account_id=$3) ORDER BY p.created_at DESC,p.id LIMIT $4 OFFSET $5").bind(q.pattern()).bind(&q.status).bind(q.account_id).bind(q.size()).bind(q.offset()).fetch_all(db).await?;
    Ok((rows, count))
}
