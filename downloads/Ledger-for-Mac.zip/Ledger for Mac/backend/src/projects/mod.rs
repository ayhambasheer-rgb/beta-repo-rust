pub mod repository;
use crate::{
    audit::{self, Change},
    auth::{Admin, AppState},
    common::{self, ApiJson, Filters, Id},
    error::ApiError,
    payments::{repository::snapshot, status::metrics},
};
use axum::{Extension, Json, Router, extract::State, http::StatusCode, routing::get};
use chrono::NaiveDate;
use repository::{Project, ProjectView};
use serde::Deserialize;
use serde_json::{Value, json};
use uuid::Uuid;
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Fields {
    name: String,
    description: String,
    contract_value: String,
    status: String,
    start_date: NaiveDate,
    end_date: Option<NaiveDate>,
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Create {
    account_id: Uuid,
    currency: String,
    #[serde(flatten)]
    fields: Fields,
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Update {
    version: i64,
    reason: String,
    #[serde(flatten)]
    fields: Fields,
}
fn validate(i: &Fields) -> Result<(String, rust_decimal::Decimal), ApiError> {
    common::status(&i.status, &["planned", "active", "completed", "archived"])?;
    if i.description.len() > 5000 || i.end_date.is_some_and(|end| end < i.start_date) {
        return Err(common::invalid(
            "Description is too long or the end date precedes the start date.",
        ));
    }
    Ok((
        common::text(&i.name, 200)?,
        common::money(&i.contract_value, false)?,
    ))
}
pub fn routes() -> Router<AppState> {
    Router::new()
        .route("/api/v1/projects/{id}/history", get(audit_history))
        .route("/api/v1/projects", get(list).post(create))
        .route("/api/v1/projects/{id}", get(detail).patch(update))
}
async fn enrich(state: &AppState, p: ProjectView, today: NaiveDate) -> Result<Value, ApiError> {
    let payments = snapshot(&state.db, None, Some(p.project.id)).await?;
    let scheduled: rust_decimal::Decimal = payments.iter().map(|x| x.payment.amount).sum();
    let mut value = json!(p);
    value["financial"] = metrics(payments.iter().map(|p| &p.payment), today);
    value["schedule_difference"] = json!(scheduled - p.project.contract_value);
    value["schedule_matches_contract"] = json!(scheduled == p.project.contract_value);
    Ok(value)
}
async fn list(State(state): State<AppState>, Filters(q): Filters) -> Result<Json<Value>, ApiError> {
    if let Some(s) = &q.status {
        common::status(s, &["planned", "active", "completed", "archived"])?;
    }
    let today = common::business_date(&state);
    let (rows, total) = repository::list(&state.db, &q).await?;
    let mut values = Vec::new();
    for p in rows {
        values.push(enrich(&state, p, today).await?);
    }
    Ok(q.envelope(json!(values), total, today))
}
async fn detail(State(state): State<AppState>, Id(id): Id) -> Result<Json<Value>, ApiError> {
    let today = common::business_date(&state);
    Ok(Json(
        json!({"data":enrich(&state,repository::one(&state.db,id).await?,today).await?,"business_date":today}),
    ))
}
async fn create(
    State(state): State<AppState>,
    Extension(actor): Extension<Admin>,
    ApiJson(i): ApiJson<Create>,
) -> Result<(StatusCode, Json<Value>), ApiError> {
    let (name, amount) = validate(&i.fields)?;
    common::currency(&state, &i.currency)?;
    let id = Uuid::new_v4();
    let mut tx = state.db.begin().await?;
    let status: Option<String> =
        sqlx::query_scalar("SELECT status FROM accounts WHERE id=$1 FOR SHARE")
            .bind(i.account_id)
            .fetch_optional(&mut *tx)
            .await?;
    if status.as_deref() != Some("active") {
        return Err(common::invalid("Choose an active account."));
    }
    let p:Project=sqlx::query_as("INSERT INTO projects (id,account_id,name,description,contract_value,currency,status,start_date,end_date) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING *").bind(id).bind(i.account_id).bind(name).bind(i.fields.description.trim()).bind(amount).bind(i.currency).bind(i.fields.status).bind(i.fields.start_date).bind(i.fields.end_date).fetch_one(&mut *tx).await?;
    audit::record(
        &mut tx,
        Change {
            actor: actor.id,
            entity: "project",
            id,
            action: "created",
            reason: "Project created",
            before: None,
            after: json!(p),
        },
    )
    .await?;
    tx.commit().await?;
    Ok((StatusCode::CREATED, Json(json!({"data":p}))))
}
async fn update(
    State(state): State<AppState>,
    Extension(actor): Extension<Admin>,
    Id(id): Id,
    ApiJson(i): ApiJson<Update>,
) -> Result<Json<Value>, ApiError> {
    let (name, amount) = validate(&i.fields)?;
    common::version(i.version)?;
    let reason = common::text(&i.reason, 1000)?;
    let mut tx = state.db.begin().await?;
    let old: Project = sqlx::query_as("SELECT * FROM projects WHERE id=$1 FOR UPDATE")
        .bind(id)
        .fetch_optional(&mut *tx)
        .await?
        .ok_or_else(common::missing)?;
    if old.version != i.version {
        return Err(common::conflict());
    }
    let p:Project=sqlx::query_as("UPDATE projects SET name=$2,description=$3,contract_value=$4,status=$5,start_date=$6,end_date=$7,version=version+1,updated_at=now() WHERE id=$1 RETURNING *").bind(id).bind(name).bind(i.fields.description.trim()).bind(amount).bind(i.fields.status).bind(i.fields.start_date).bind(i.fields.end_date).fetch_one(&mut *tx).await?;
    audit::record(
        &mut tx,
        Change {
            actor: actor.id,
            entity: "project",
            id,
            action: "updated",
            reason: &reason,
            before: Some(json!(old)),
            after: json!(p),
        },
    )
    .await?;
    tx.commit().await?;
    Ok(Json(json!({"data":p})))
}

async fn audit_history(
    State(state): State<AppState>,
    Id(id): Id,
    Filters(q): Filters,
) -> Result<Json<Value>, ApiError> {
    repository::one(&state.db, id).await?;
    audit::history(&state, "project", id, &q).await
}
