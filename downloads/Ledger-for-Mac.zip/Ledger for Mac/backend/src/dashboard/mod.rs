use crate::{
    auth::AppState,
    common,
    credit_health::policy,
    error::ApiError,
    payments::{repository, status},
};
use axum::{Json, Router, extract::State, routing::get};
use serde_json::{Value, json};
use sqlx::Row;
use std::collections::BTreeMap;
use uuid::Uuid;
pub fn routes() -> Router<AppState> {
    Router::new().route("/api/v1/dashboard", get(summary))
}
async fn summary(State(state): State<AppState>) -> Result<Json<Value>, ApiError> {
    let today = common::business_date(&state);
    let rows = repository::snapshot(&state.db, None, None).await?;
    let accounts: Vec<(Uuid, String)> =
        sqlx::query_as("SELECT id,name FROM accounts ORDER BY name,id")
            .fetch_all(&state.db)
            .await?;
    let active_projects: i64 =
        sqlx::query_scalar("SELECT count(*) FROM projects WHERE status='active'")
            .fetch_one(&state.db)
            .await?;
    let mut counts: BTreeMap<String, usize> = status::STATUSES
        .iter()
        .map(|s| (s.to_string(), 0))
        .collect();
    for r in &rows {
        *counts
            .get_mut(status::classify(
                r.payment.due_date,
                r.payment.settlement_date,
                today,
            ))
            .unwrap() += 1;
    }
    let mut distribution: BTreeMap<String, usize> =
        policy::CLASSES.iter().map(|s| (s.to_string(), 0)).collect();
    let mut attention = Vec::new();
    for (id, name) in &accounts {
        let history: Vec<_> = rows
            .iter()
            .filter(|r| r.account_id == *id)
            .cloned()
            .collect();
        let health = policy::assess(&history, today);
        *distribution.get_mut(health.classification).unwrap() += 1;
        if ["POOR", "AT_RISK", "RECOVERING"].contains(&health.classification) {
            attention.push(json!({"id":id,"name":name,"credit_health":health}));
        }
    }
    attention.sort_by_key(|v| match v["credit_health"]["classification"].as_str() {
        Some("POOR") => 0,
        Some("AT_RISK") => 1,
        _ => 2,
    });
    let overdue = rows
        .iter()
        .filter(|r| r.payment.settlement_date.is_none() && r.payment.due_date < today)
        .take(8)
        .map(|r| status::view(r, today))
        .collect::<Vec<_>>();
    let upcoming = rows
        .iter()
        .filter(|r| r.payment.settlement_date.is_none() && r.payment.due_date >= today)
        .take(8)
        .map(|r| status::view(r, today))
        .collect::<Vec<_>>();
    let activity=sqlx::query("SELECT e.id,e.action,e.created_at,e.reason,e.after_data->>'title' title,e.after_data->>'amount' amount,e.after_data->>'currency' currency,a.name account_name,a.id account_id,p.id payment_id FROM audit_events e JOIN scheduled_payments p ON p.id=e.payment_id JOIN projects j ON j.id=p.project_id JOIN accounts a ON a.id=j.account_id ORDER BY e.created_at DESC,e.id LIMIT 8").fetch_all(&state.db).await?;
    let activity:Vec<_>=activity.iter().map(|r|json!({"id":r.get::<Uuid,_>("id"),"action":r.get::<String,_>("action"),"created_at":r.get::<chrono::DateTime<chrono::Utc>,_>("created_at"),"reason":r.get::<String,_>("reason"),"title":r.get::<String,_>("title"),"amount":r.get::<String,_>("amount"),"currency":r.get::<String,_>("currency"),"account_name":r.get::<String,_>("account_name"),"account_id":r.get::<Uuid,_>("account_id"),"payment_id":r.get::<Uuid,_>("payment_id")})).collect();
    Ok(Json(
        json!({"data":{"business_date":today,"currency":state.currency,"total_accounts":accounts.len(),"active_projects":active_projects,"financial":status::metrics(rows.iter().map(|r|&r.payment),today),"payment_status_counts":counts,"credit_health_distribution":distribution,"accounts_requiring_attention":attention.into_iter().take(8).collect::<Vec<_>>(),"upcoming_payments":upcoming,"overdue_payments":overdue,"recent_activity":activity}}),
    ))
}
