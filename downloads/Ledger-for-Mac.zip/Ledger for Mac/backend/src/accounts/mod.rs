pub mod repository;
use crate::{
    audit::{self, Change},
    auth::{Admin, AppState},
    common::{self, ApiJson, Filters, Id},
    credit_health::policy,
    error::ApiError,
    payments::{repository::snapshot, status::metrics},
};
use axum::{Extension, Json, Router, extract::State, http::StatusCode, routing::get};
use repository::Account;
use serde::Deserialize;
use serde_json::{Value, json};
use uuid::Uuid;
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Input {
    name: String,
    contact_name: String,
    email: String,
    phone: String,
    status: String,
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Update {
    #[serde(flatten)]
    fields: Input,
    version: i64,
    reason: String,
}
fn validate(input: Input) -> Result<Input, ApiError> {
    common::status(&input.status, &["active", "archived"])?;
    Ok(Input {
        name: common::text(&input.name, 200)?,
        contact_name: common::text(&input.contact_name, 200)?,
        email: common::email(&input.email)?,
        phone: common::text(&input.phone, 50)?,
        status: input.status,
    })
}
pub fn routes() -> Router<AppState> {
    Router::new()
        .route("/api/v1/accounts/{id}/history", get(audit_history))
        .route("/api/v1/accounts", get(list).post(create))
        .route("/api/v1/accounts/{id}", get(detail).patch(update))
        .route("/api/v1/accounts/{id}/payments", get(history))
}
async fn enrich(state: &AppState, a: Account, today: chrono::NaiveDate) -> Result<Value, ApiError> {
    let payments = snapshot(&state.db, Some(a.id), None).await?;
    let contracts:Vec<(String,rust_decimal::Decimal)>=sqlx::query_as("SELECT currency,sum(contract_value)::numeric FROM projects WHERE account_id=$1 GROUP BY currency").bind(a.id).fetch_all(&state.db).await?;
    let project_count: i64 =
        sqlx::query_scalar("SELECT count(*) FROM projects WHERE account_id=$1")
            .bind(a.id)
            .fetch_one(&state.db)
            .await?;
    let mut value = serde_json::to_value(a).expect("account serialization");
    value["project_count"] = json!(project_count);
    value["contracted"] = json!(
        contracts
            .into_iter()
            .map(|(currency, amount)| json!({"currency":currency,"amount":amount}))
            .collect::<Vec<_>>()
    );
    value["financial"] = metrics(payments.iter().map(|p| &p.payment), today);
    value["credit_health"] = json!(policy::assess(&payments, today));
    Ok(value)
}
async fn list(State(state): State<AppState>, Filters(q): Filters) -> Result<Json<Value>, ApiError> {
    if let Some(s) = &q.status {
        common::status(s, &["active", "archived"])?;
    }
    let today = common::business_date(&state);
    if let Some(health) = &q.credit_health {
        common::status(health, policy::CLASSES)?;
        let mut unpaged = q.clone();
        unpaged.page = Some(1);
        unpaged.page_size = Some(i64::MAX);
        let (rows, _) = repository::list(&state.db, &unpaged).await?;
        let mut values = Vec::new();
        for a in rows {
            let v = enrich(&state, a, today).await?;
            if v["credit_health"]["classification"].as_str() == Some(health) {
                values.push(v);
            }
        }
        let total = values.len() as i64;
        return Ok(q.envelope(
            json!(
                values
                    .into_iter()
                    .skip(q.offset() as usize)
                    .take(q.size() as usize)
                    .collect::<Vec<_>>()
            ),
            total,
            today,
        ));
    }
    let (rows, total) = repository::list(&state.db, &q).await?;
    let mut values = Vec::new();
    for a in rows {
        values.push(enrich(&state, a, today).await?);
    }
    Ok(q.envelope(json!(values), total, today))
}
async fn detail(State(state): State<AppState>, Id(id): Id) -> Result<Json<Value>, ApiError> {
    let today = common::business_date(&state);
    Ok(Json(
        json!({"data":enrich(&state,repository::one(&state.db,id).await?,today).await?,"business_date":today}),
    ))
}
async fn history(
    State(state): State<AppState>,
    Id(id): Id,
    Filters(mut q): Filters,
) -> Result<Json<Value>, ApiError> {
    repository::one(&state.db, id).await?;
    q.account_id = Some(id);
    crate::payments::listing(&state, q).await
}
async fn create(
    State(state): State<AppState>,
    Extension(actor): Extension<Admin>,
    ApiJson(input): ApiJson<Input>,
) -> Result<(StatusCode, Json<Value>), ApiError> {
    let i = validate(input)?;
    let id = Uuid::new_v4();
    let mut tx = state.db.begin().await?;
    let a:Account=sqlx::query_as("INSERT INTO accounts (id,name,contact_name,email,phone,status) VALUES ($1,$2,$3,$4,$5,$6) RETURNING *").bind(id).bind(i.name).bind(i.contact_name).bind(i.email).bind(i.phone).bind(i.status).fetch_one(&mut *tx).await?;
    audit::record(
        &mut tx,
        Change {
            actor: actor.id,
            entity: "account",
            id,
            action: "created",
            reason: "Account created",
            before: None,
            after: json!(a),
        },
    )
    .await?;
    tx.commit().await?;
    Ok((StatusCode::CREATED, Json(json!({"data":a}))))
}
async fn update(
    State(state): State<AppState>,
    Extension(actor): Extension<Admin>,
    Id(id): Id,
    ApiJson(input): ApiJson<Update>,
) -> Result<Json<Value>, ApiError> {
    common::version(input.version)?;
    let reason = common::text(&input.reason, 1000)?;
    let i = validate(input.fields)?;
    let mut tx = state.db.begin().await?;
    let old: Account = sqlx::query_as("SELECT * FROM accounts WHERE id=$1 FOR UPDATE")
        .bind(id)
        .fetch_optional(&mut *tx)
        .await?
        .ok_or_else(common::missing)?;
    if old.version != input.version {
        return Err(common::conflict());
    }
    let a:Account=sqlx::query_as("UPDATE accounts SET name=$2,contact_name=$3,email=$4,phone=$5,status=$6,version=version+1,updated_at=now() WHERE id=$1 RETURNING *").bind(id).bind(i.name).bind(i.contact_name).bind(i.email).bind(i.phone).bind(i.status).fetch_one(&mut *tx).await?;
    audit::record(
        &mut tx,
        Change {
            actor: actor.id,
            entity: "account",
            id,
            action: "updated",
            reason: &reason,
            before: Some(json!(old)),
            after: json!(a),
        },
    )
    .await?;
    tx.commit().await?;
    Ok(Json(json!({"data":a})))
}

async fn audit_history(
    State(state): State<AppState>,
    Id(id): Id,
    Filters(q): Filters,
) -> Result<Json<Value>, ApiError> {
    repository::one(&state.db, id).await?;
    audit::history(&state, "account", id, &q).await
}
