use crate::{
    common::{ListQuery, missing},
    error::ApiError,
};
use chrono::{DateTime, Utc};
use serde::Serialize;
use sqlx::{FromRow, PgPool};
use uuid::Uuid;
#[derive(Serialize, FromRow)]
pub struct Account {
    pub id: Uuid,
    pub name: String,
    pub contact_name: String,
    pub email: String,
    pub phone: String,
    pub status: String,
    pub version: i64,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
}
pub async fn one(db: &PgPool, id: Uuid) -> Result<Account, ApiError> {
    sqlx::query_as("SELECT * FROM accounts WHERE id=$1")
        .bind(id)
        .fetch_optional(db)
        .await?
        .ok_or_else(missing)
}
pub async fn list(db: &PgPool, q: &ListQuery) -> Result<(Vec<Account>, i64), ApiError> {
    let count=sqlx::query_scalar("SELECT count(*) FROM accounts WHERE (name ILIKE $1 OR contact_name ILIKE $1 OR email ILIKE $1) AND ($2::text IS NULL OR status=$2)").bind(q.pattern()).bind(&q.status).fetch_one(db).await?;
    let rows=sqlx::query_as("SELECT * FROM accounts WHERE (name ILIKE $1 OR contact_name ILIKE $1 OR email ILIKE $1) AND ($2::text IS NULL OR status=$2) ORDER BY created_at DESC,id LIMIT $3 OFFSET $4").bind(q.pattern()).bind(&q.status).bind(q.size()).bind(q.offset()).fetch_all(db).await?;
    Ok((rows, count))
}
