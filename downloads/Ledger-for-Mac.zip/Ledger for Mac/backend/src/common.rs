use crate::{auth::AppState, error::ApiError};
use axum::{
    extract::Request,
    extract::{FromRequest, FromRequestParts, Json, Path, Query, State},
    http::{StatusCode, request::Parts},
};
use chrono::{NaiveDate, Utc};
use rust_decimal::Decimal;
use serde::{Deserialize, de::DeserializeOwned};
use serde_json::{Value, json};
use uuid::Uuid;

pub fn invalid(message: &'static str) -> ApiError {
    ApiError(
        StatusCode::UNPROCESSABLE_ENTITY,
        "validation_error",
        message,
    )
}
pub fn missing() -> ApiError {
    ApiError(StatusCode::NOT_FOUND, "not_found", "Record not found.")
}
pub fn conflict() -> ApiError {
    ApiError(
        StatusCode::CONFLICT,
        "conflict",
        "The record changed or this operation is no longer valid. Refresh and try again.",
    )
}
pub fn business_date(state: &AppState) -> NaiveDate {
    date_at(Utc::now(), &state.timezone)
}
pub fn date_at(instant: chrono::DateTime<Utc>, timezone: &str) -> NaiveDate {
    instant
        .with_timezone(
            &timezone
                .parse::<chrono_tz::Tz>()
                .expect("validated timezone"),
        )
        .date_naive()
}
pub fn text(value: &str, max: usize) -> Result<String, ApiError> {
    let result = value.trim();
    if result.is_empty() || result.chars().count() > max || result.chars().any(|c| c.is_control()) {
        return Err(invalid(
            "Required text is empty, too long, or contains control characters.",
        ));
    }
    Ok(result.to_owned())
}
pub fn email(value: &str) -> Result<String, ApiError> {
    let email = text(value, 254)?.to_lowercase();
    let (local, domain) = email
        .split_once('@')
        .ok_or_else(|| invalid("Provide a valid email address."))?;
    if local.is_empty()
        || domain.is_empty()
        || !domain.contains('.')
        || email.contains(char::is_whitespace)
        || domain.contains('@')
    {
        return Err(invalid("Provide a valid email address."));
    }
    Ok(email)
}
pub fn money(value: &str, positive: bool) -> Result<Decimal, ApiError> {
    if value.len() > 24 || value.contains(['e', 'E', '+']) {
        return Err(invalid(
            "Use a decimal amount with at most two decimal places.",
        ));
    }
    let amount =
        Decimal::from_str_exact(value).map_err(|_| invalid("Use a valid decimal amount."))?;
    if amount.scale() > 2
        || amount < Decimal::ZERO
        || (positive && amount == Decimal::ZERO)
        || amount > Decimal::from_str_exact("99999999999999999.99").unwrap()
    {
        return Err(invalid(
            "Amount is outside the allowed range or exceeds two decimal places.",
        ));
    }
    Ok(amount)
}
pub fn currency(state: &AppState, value: &str) -> Result<(), ApiError> {
    match &state.currency {
        Some(configured) if configured == value => Ok(()),
        Some(_) => Err(invalid(
            "Currency must match the configured business currency.",
        )),
        None => Err(invalid(
            "Set BUSINESS_CURRENCY before creating financial records.",
        )),
    }
}
pub fn version(value: i64) -> Result<(), ApiError> {
    if value < 1 {
        Err(invalid("A positive record version is required."))
    } else {
        Ok(())
    }
}
pub fn status(value: &str, allowed: &[&str]) -> Result<(), ApiError> {
    if allowed.contains(&value) {
        Ok(())
    } else {
        Err(invalid("Unsupported status."))
    }
}
pub struct ApiJson<T>(pub T);
impl<S, T> FromRequest<S> for ApiJson<T>
where
    S: Send + Sync,
    T: DeserializeOwned,
{
    type Rejection = ApiError;
    async fn from_request(req: Request, state: &S) -> Result<Self, Self::Rejection> {
        Json::<T>::from_request(req, state)
            .await
            .map(|Json(v)| Self(v))
            .map_err(|e| {
                if e.status() == StatusCode::PAYLOAD_TOO_LARGE {
                    ApiError(
                        e.status(),
                        "payload_too_large",
                        "Request body is too large.",
                    )
                } else if e.status() == StatusCode::UNSUPPORTED_MEDIA_TYPE {
                    ApiError(
                        e.status(),
                        "unsupported_media_type",
                        "Use application/json.",
                    )
                } else {
                    invalid("Request fields are missing or invalid.")
                }
            })
    }
}
pub struct Id(pub Uuid);
impl<S: Send + Sync> FromRequestParts<S> for Id {
    type Rejection = ApiError;
    async fn from_request_parts(parts: &mut Parts, state: &S) -> Result<Self, Self::Rejection> {
        let Path(value) = Path::<String>::from_request_parts(parts, state)
            .await
            .map_err(|_| invalid("Invalid record identifier."))?;
        Ok(Self(
            value
                .parse()
                .map_err(|_| invalid("Invalid record identifier."))?,
        ))
    }
}
#[derive(Clone, Default, Deserialize)]
#[serde(deny_unknown_fields)]
pub struct ListQuery {
    pub credit_health: Option<String>,
    pub settlement_status: Option<String>,
    pub page: Option<i64>,
    pub page_size: Option<i64>,
    pub search: Option<String>,
    pub status: Option<String>,
    pub account_id: Option<Uuid>,
    pub project_id: Option<Uuid>,
    pub date_from: Option<NaiveDate>,
    pub date_to: Option<NaiveDate>,
}
impl ListQuery {
    pub fn page(&self) -> i64 {
        self.page.unwrap_or(1)
    }
    pub fn size(&self) -> i64 {
        self.page_size.unwrap_or(20)
    }
    pub fn offset(&self) -> i64 {
        (self.page() - 1) * self.size()
    }
    pub fn pattern(&self) -> String {
        format!("%{}%", self.search.as_deref().unwrap_or("").trim())
    }
    pub fn envelope(&self, data: Value, total: i64, today: NaiveDate) -> Json<Value> {
        Json(
            json!({"data":data,"meta":{"page":self.page(),"page_size":self.size(),"total":total},"business_date":today}),
        )
    }
}
pub struct Filters(pub ListQuery);
impl<S: Send + Sync> FromRequestParts<S> for Filters {
    type Rejection = ApiError;
    async fn from_request_parts(parts: &mut Parts, state: &S) -> Result<Self, Self::Rejection> {
        let Query(q) = Query::<ListQuery>::from_request_parts(parts, state)
            .await
            .map_err(|_| invalid("Invalid list filters."))?;
        if !(1..=1_000_000).contains(&q.page())
            || !(1..=100).contains(&q.size())
            || q.search.as_ref().is_some_and(|s| s.len() > 200)
            || matches!((q.date_from,q.date_to),(Some(a),Some(b)) if a>b)
        {
            return Err(invalid("Invalid pagination, search, or date range."));
        }
        Ok(Self(q))
    }
}
pub async fn settings(State(state): State<AppState>) -> Json<Value> {
    Json(
        json!({"data":{"currency":state.currency,"monetary_precision":2,"business_timezone":state.timezone,"business_date":business_date(&state)}}),
    )
}
pub fn nullable_date<'de, D: serde::Deserializer<'de>>(
    deserializer: D,
) -> Result<Option<NaiveDate>, D::Error> {
    Option::<NaiveDate>::deserialize(deserializer)
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn exact_amounts_and_bounds() {
        assert_eq!(
            money("0.10", true).unwrap() + money("0.20", true).unwrap(),
            money("0.30", true).unwrap()
        );
        for x in ["0", "-1", "1.001", "1e2", "100000000000000000.00"] {
            assert!(money(x, true).is_err());
        }
    }
    #[test]
    fn timezone_midnight() {
        let instant = "2026-01-01T21:00:00Z".parse().unwrap();
        assert_eq!(date_at(instant, "Asia/Amman").to_string(), "2026-01-02");
        assert_eq!(date_at(instant, "UTC").to_string(), "2026-01-01");
    }
}
