use super::repository::{Payment, PaymentView};
use chrono::NaiveDate;
use rust_decimal::Decimal;
use serde_json::{Value, json};
use std::collections::BTreeMap;

pub const STATUSES: &[&str] = &[
    "UPCOMING",
    "DUE_TODAY",
    "OVERDUE",
    "PAID_ON_TIME",
    "PAID_LATE",
];
pub fn classify(due: NaiveDate, settled: Option<NaiveDate>, today: NaiveDate) -> &'static str {
    match settled {
        Some(date) if date <= due => "PAID_ON_TIME",
        Some(_) => "PAID_LATE",
        None if due < today => "OVERDUE",
        None if due == today => "DUE_TODAY",
        None => "UPCOMING",
    }
}
pub fn view(row: &PaymentView, today: NaiveDate) -> Value {
    let mut value = serde_json::to_value(row).expect("payment serialization");
    value["status"] = json!(classify(
        row.payment.due_date,
        row.payment.settlement_date,
        today
    ));
    value["settlement_status"] = json!(if row.payment.settlement_date.is_some() {
        "settled"
    } else {
        "unpaid"
    });
    value["days_overdue"] = json!(if row.payment.settlement_date.is_none() {
        (today - row.payment.due_date).num_days().max(0)
    } else {
        0
    });
    value
}
pub fn metrics<'a>(payments: impl Iterator<Item = &'a Payment>, today: NaiveDate) -> Value {
    let mut groups: BTreeMap<String, (Decimal, Decimal, Decimal, Decimal, i64)> = BTreeMap::new();
    for p in payments {
        let totals = groups.entry(p.currency.clone()).or_default();
        totals.0 += p.amount;
        if p.settlement_date.is_some() {
            totals.1 += p.amount;
        } else {
            totals.2 += p.amount;
            if p.due_date < today {
                totals.3 += p.amount;
                totals.4 += 1;
            }
        }
    }
    json!(groups.into_iter().map(|(currency,(scheduled,paid,outstanding,overdue,overdue_count))| json!({"currency":currency,"scheduled":scheduled,"paid":paid,"outstanding":outstanding,"overdue":overdue,"overdue_count":overdue_count,"completion_percent":if scheduled>Decimal::ZERO{Some((paid/scheduled*Decimal::from(100)).round_dp(2))}else{None}})).collect::<Vec<_>>())
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn all_payment_statuses_and_rollover() {
        let due = NaiveDate::from_ymd_opt(2026, 1, 2).unwrap();
        assert_eq!(classify(due, None, due.pred_opt().unwrap()), "UPCOMING");
        assert_eq!(classify(due, None, due), "DUE_TODAY");
        assert_eq!(classify(due, None, due.succ_opt().unwrap()), "OVERDUE");
        assert_eq!(
            classify(due, Some(due.pred_opt().unwrap()), due),
            "PAID_ON_TIME"
        );
        assert_eq!(classify(due, Some(due), due), "PAID_ON_TIME");
        assert_eq!(
            classify(due, Some(due.succ_opt().unwrap()), due.succ_opt().unwrap()),
            "PAID_LATE"
        );
    }
}
