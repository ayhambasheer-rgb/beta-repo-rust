pub mod repository;
pub mod status;
use crate::{
    audit::{self, Change},
    auth::{Admin, AppState},
    common::{self, ApiJson, Filters, Id, ListQuery},
    error::ApiError,
};
use axum::{
    Extension, Json, Router,
    extract::State,
    http::StatusCode,
    routing::{get, post},
};
use chrono::NaiveDate;
use repository::Payment;
use serde::Deserialize;
use serde_json::{Value, json};
use sqlx::Row;
use uuid::Uuid;
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Create {
    project_id: Uuid,
    title: String,
    amount: String,
    currency: String,
    due_date: NaiveDate,
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Settlement {
    version: i64,
    settlement_date: NaiveDate,
}
#[derive(Deserialize)]
#[serde(deny_unknown_fields)]
pub struct Correction {
    version: i64,
    reason: String,
    title: String,
    amount: String,
    due_date: NaiveDate,
    #[serde(deserialize_with = "common::nullable_date")]
    settlement_date: Option<NaiveDate>,
}
pub fn routes() -> Router<AppState> {
    Router::new()
        .route("/api/v1/payments", get(list).post(create))
        .route("/api/v1/payments/{id}", get(detail))
        .route("/api/v1/payments/{id}/settlement", post(settle))
        .route("/api/v1/payments/{id}/corrections", post(correct))
        .route("/api/v1/payments/{id}/history", get(history))
}
async fn list(State(state): State<AppState>, Filters(q): Filters) -> Result<Json<Value>, ApiError> {
    listing(&state, q).await
}
pub async fn listing(state: &AppState, q: ListQuery) -> Result<Json<Value>, ApiError> {
    if let Some(s) = &q.status {
        common::status(s, status::STATUSES)?;
    }
    if let Some(s) = &q.settlement_status {
        common::status(s, &["settled", "unpaid"])?;
    }
    let today = common::business_date(state);
    let query = "FROM scheduled_payments p JOIN projects j ON j.id=p.project_id JOIN accounts a ON a.id=j.account_id WHERE ($1::uuid IS NULL OR a.id=$1) AND ($2::uuid IS NULL OR j.id=$2) AND (p.title ILIKE $3 OR a.name ILIKE $3 OR j.name ILIKE $3) AND ($4::date IS NULL OR p.due_date >= $4) AND ($5::date IS NULL OR p.due_date <= $5) AND ($6::text IS NULL OR CASE WHEN p.settlement_date IS NOT NULL THEN CASE WHEN p.settlement_date <= p.due_date THEN 'PAID_ON_TIME' ELSE 'PAID_LATE' END WHEN p.due_date < $7 THEN 'OVERDUE' WHEN p.due_date = $7 THEN 'DUE_TODAY' ELSE 'UPCOMING' END=$6) AND ($8::text IS NULL OR ($8='settled' AND p.settlement_date IS NOT NULL) OR ($8='unpaid' AND p.settlement_date IS NULL))";
    let total: i64 = sqlx::query_scalar(&format!("SELECT count(*) {query}"))
        .bind(q.account_id)
        .bind(q.project_id)
        .bind(q.pattern())
        .bind(q.date_from)
        .bind(q.date_to)
        .bind(&q.status)
        .bind(today)
        .bind(&q.settlement_status)
        .fetch_one(&state.db)
        .await?;
    let rows=sqlx::query_as::<_,repository::PaymentView>(&format!("SELECT p.*,a.id account_id,a.name account_name,j.name project_name {query} ORDER BY p.due_date,p.id LIMIT $9 OFFSET $10")).bind(q.account_id).bind(q.project_id).bind(q.pattern()).bind(q.date_from).bind(q.date_to).bind(&q.status).bind(today).bind(&q.settlement_status).bind(q.size()).bind(q.offset()).fetch_all(&state.db).await?;
    Ok(q.envelope(
        json!(
            rows.iter()
                .map(|p| status::view(p, today))
                .collect::<Vec<_>>()
        ),
        total,
        today,
    ))
}
async fn detail(State(state): State<AppState>, Id(id): Id) -> Result<Json<Value>, ApiError> {
    let today = common::business_date(&state);
    Ok(Json(
        json!({"data":status::view(&repository::one(&state.db,id).await?,today),"business_date":today}),
    ))
}
async fn create(
    State(state): State<AppState>,
    Extension(actor): Extension<Admin>,
    ApiJson(i): ApiJson<Create>,
) -> Result<(StatusCode, Json<Value>), ApiError> {
    let title = common::text(&i.title, 200)?;
    let amount = common::money(&i.amount, true)?;
    common::currency(&state, &i.currency)?;
    let id = Uuid::new_v4();
    let mut tx = state.db.begin().await?;
    let project = sqlx::query("SELECT currency,status FROM projects WHERE id=$1 FOR SHARE")
        .bind(i.project_id)
        .fetch_optional(&mut *tx)
        .await?
        .ok_or_else(common::missing)?;
    if project.get::<String, _>("currency") != i.currency
        || project.get::<String, _>("status") == "archived"
    {
        return Err(common::invalid(
            "Choose an unarchived project with matching currency.",
        ));
    }
    let p:Payment=sqlx::query_as("INSERT INTO scheduled_payments (id,project_id,title,amount,currency,due_date) VALUES ($1,$2,$3,$4,$5,$6) RETURNING *").bind(id).bind(i.project_id).bind(title).bind(amount).bind(i.currency).bind(i.due_date).fetch_one(&mut *tx).await?;
    audit::record(
        &mut tx,
        Change {
            actor: actor.id,
            entity: "payment",
            id,
            action: "scheduled",
            reason: "Payment scheduled",
            before: None,
            after: json!(p),
        },
    )
    .await?;
    tx.commit().await?;
    let today = common::business_date(&state);
    Ok((
        StatusCode::CREATED,
        Json(
            json!({"data":status::view(&repository::one(&state.db,id).await?,today),"business_date":today}),
        ),
    ))
}
async fn settle(
    State(state): State<AppState>,
    Extension(actor): Extension<Admin>,
    Id(id): Id,
    ApiJson(i): ApiJson<Settlement>,
) -> Result<Json<Value>, ApiError> {
    common::version(i.version)?;
    let today = common::business_date(&state);
    if i.settlement_date > today {
        return Err(common::invalid("Settlement date cannot be in the future."));
    }
    let mut tx = state.db.begin().await?;
    let old: Payment = sqlx::query_as("SELECT * FROM scheduled_payments WHERE id=$1 FOR UPDATE")
        .bind(id)
        .fetch_optional(&mut *tx)
        .await?
        .ok_or_else(common::missing)?;
    if old.version != i.version || old.settlement_date.is_some() {
        return Err(common::conflict());
    }
    let p:Payment=sqlx::query_as("UPDATE scheduled_payments SET settlement_date=$2,version=version+1,updated_at=now() WHERE id=$1 RETURNING *").bind(id).bind(i.settlement_date).fetch_one(&mut *tx).await?;
    audit::record(
        &mut tx,
        Change {
            actor: actor.id,
            entity: "payment",
            id,
            action: "settled",
            reason: "Full settlement recorded",
            before: Some(json!(old)),
            after: json!(p),
        },
    )
    .await?;
    tx.commit().await?;
    Ok(Json(
        json!({"data":status::view(&repository::one(&state.db,id).await?,today),"business_date":today}),
    ))
}
async fn correct(
    State(state): State<AppState>,
    Extension(actor): Extension<Admin>,
    Id(id): Id,
    ApiJson(i): ApiJson<Correction>,
) -> Result<Json<Value>, ApiError> {
    common::version(i.version)?;
    let reason = common::text(&i.reason, 1000)?;
    let title = common::text(&i.title, 200)?;
    let amount = common::money(&i.amount, true)?;
    let today = common::business_date(&state);
    if i.settlement_date.is_some_and(|d| d > today) {
        return Err(common::invalid("Settlement date cannot be in the future."));
    }
    let mut tx = state.db.begin().await?;
    let old: Payment = sqlx::query_as("SELECT * FROM scheduled_payments WHERE id=$1 FOR UPDATE")
        .bind(id)
        .fetch_optional(&mut *tx)
        .await?
        .ok_or_else(common::missing)?;
    if old.version != i.version {
        return Err(common::conflict());
    }
    let p:Payment=sqlx::query_as("UPDATE scheduled_payments SET title=$2,amount=$3,due_date=$4,settlement_date=$5,version=version+1,updated_at=now() WHERE id=$1 RETURNING *").bind(id).bind(title).bind(amount).bind(i.due_date).bind(i.settlement_date).fetch_one(&mut *tx).await?;
    audit::record(
        &mut tx,
        Change {
            actor: actor.id,
            entity: "payment",
            id,
            action: "corrected",
            reason: &reason,
            before: Some(json!(old)),
            after: json!(p),
        },
    )
    .await?;
    tx.commit().await?;
    Ok(Json(
        json!({"data":status::view(&repository::one(&state.db,id).await?,today),"business_date":today}),
    ))
}
async fn history(
    State(state): State<AppState>,
    Id(id): Id,
    Filters(q): Filters,
) -> Result<Json<Value>, ApiError> {
    repository::one(&state.db, id).await?;
    audit::history(&state, "payment", id, &q).await
}
