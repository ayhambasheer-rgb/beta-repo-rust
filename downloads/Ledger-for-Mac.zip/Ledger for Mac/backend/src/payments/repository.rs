use crate::error::ApiError;
use chrono::{DateTime, NaiveDate, Utc};
use rust_decimal::Decimal;
use serde::Serialize;
use sqlx::{FromRow, PgPool};
use uuid::Uuid;

#[derive(Clone, Serialize, FromRow)]
pub struct Payment {
    pub id: Uuid,
    pub project_id: Uuid,
    pub title: String,
    pub amount: Decimal,
    pub currency: String,
    pub due_date: NaiveDate,
    pub settlement_date: Option<NaiveDate>,
    pub version: i64,
    pub created_at: DateTime<Utc>,
    pub updated_at: DateTime<Utc>,
}
#[derive(Clone, Serialize, FromRow)]
pub struct PaymentView {
    #[serde(flatten)]
    #[sqlx(flatten)]
    pub payment: Payment,
    pub account_id: Uuid,
    pub account_name: String,
    pub project_name: String,
}
pub async fn snapshot(
    db: &PgPool,
    account: Option<Uuid>,
    project: Option<Uuid>,
) -> Result<Vec<PaymentView>, ApiError> {
    Ok(sqlx::query_as::<_,PaymentView>("SELECT p.*, a.id account_id, a.name account_name, j.name project_name FROM scheduled_payments p JOIN projects j ON j.id=p.project_id JOIN accounts a ON a.id=j.account_id WHERE ($1::uuid IS NULL OR a.id=$1) AND ($2::uuid IS NULL OR j.id=$2) ORDER BY p.due_date,p.id")
        .bind(account).bind(project).fetch_all(db).await?)
}
pub async fn one(db: &PgPool, id: Uuid) -> Result<PaymentView, ApiError> {
    sqlx::query_as::<_,PaymentView>("SELECT p.*, a.id account_id, a.name account_name, j.name project_name FROM scheduled_payments p JOIN projects j ON j.id=p.project_id JOIN accounts a ON a.id=j.account_id WHERE p.id=$1").bind(id).fetch_optional(db).await?.ok_or_else(crate::common::missing)
}
