use super::*;
use axum::{
    body::{Body, to_bytes},
    http::{Request, StatusCode},
};
use serde_json::{Value, json};
use sqlx::PgPool;
use tower::ServiceExt;

struct Client {
    app: Router,
    cookie: String,
    csrf: String,
    today: chrono::NaiveDate,
}
impl Client {
    async fn new(db: PgPool) -> Self {
        let hash = auth::hash_password("workflow-test-password").unwrap();
        sqlx::query(
            "INSERT INTO admin_users(id,email,password_hash) VALUES($1,'workflow@example.test',$2)",
        )
        .bind(Uuid::new_v4())
        .bind(&hash)
        .execute(&db)
        .await
        .unwrap();
        let state = AppState {
            db,
            origin: "http://localhost:5173".into(),
            secure: false,
            timezone: "Asia/Amman".into(),
            currency: Some("USD".into()),
            dummy_hash: Arc::new(hash),
            attempts: Arc::new(Mutex::new((Instant::now(), 0))),
        };
        let today = common::business_date(&state);
        let app = router(state);
        let response=app.clone().oneshot(Request::builder().method("POST").uri("/api/v1/auth/login").header("origin","http://localhost:5173").header("content-type","application/json").body(Body::from(json!({"email":"workflow@example.test","password":"workflow-test-password"}).to_string())).unwrap()).await.unwrap();
        assert_eq!(response.status(), StatusCode::OK);
        let cookie = response.headers()["set-cookie"]
            .to_str()
            .unwrap()
            .split(';')
            .next()
            .unwrap()
            .to_owned();
        let value: Value =
            serde_json::from_slice(&to_bytes(response.into_body(), 32768).await.unwrap()).unwrap();
        Self {
            app,
            cookie,
            csrf: value["data"]["csrf_token"].as_str().unwrap().into(),
            today,
        }
    }
    async fn send(&self, method: &str, path: &str, body: Value) -> (u16, Value) {
        let response = self
            .app
            .clone()
            .oneshot(
                Request::builder()
                    .method(method)
                    .uri(format!("/api/v1{path}"))
                    .header("origin", "http://localhost:5173")
                    .header("content-type", "application/json")
                    .header("cookie", &self.cookie)
                    .header("x-csrf-token", &self.csrf)
                    .body(Body::from(body.to_string()))
                    .unwrap(),
            )
            .await
            .unwrap();
        let code = response.status().as_u16();
        let bytes = to_bytes(response.into_body(), 2_000_000).await.unwrap();
        (
            code,
            if bytes.is_empty() {
                Value::Null
            } else {
                serde_json::from_slice(&bytes)
                    .unwrap_or_else(|_| panic!("Non-JSON response, status {code}"))
            },
        )
    }
    async fn ok(&self, method: &str, path: &str, body: Value) -> Value {
        let (code, value) = self.send(method, path, body).await;
        assert!((200..300).contains(&code), "{path}: {code} {value}");
        value["data"].clone()
    }
    async fn account(&self, name: &str) -> Value {
        self.ok("POST","/accounts",json!({"name":name,"contact_name":"Test contact","email":"contact@example.test","phone":"+1 555 0100","status":"active"})).await
    }
    async fn project(&self, account: &Value, name: &str, value: &str) -> Value {
        self.ok("POST","/projects",json!({"account_id":account["id"],"name":name,"description":"Integration fixture","contract_value":value,"currency":"USD","status":"active","start_date":self.today,"end_date":null})).await
    }
    async fn payment(&self, project: &Value, title: &str, amount: &str, offset: i64) -> Value {
        self.ok("POST","/payments",json!({"project_id":project["id"],"title":title,"amount":amount,"currency":"USD","due_date":self.today+chrono::Duration::days(offset)})).await
    }
}
#[sqlx::test]
async fn account_project_payment_vertical_slice(db: PgPool) {
    let c = Client::new(db.clone()).await;
    let a = c.account("Integration client").await;
    let p = c.project(&a, "First project", "100.00").await;
    let p2 = c.project(&a, "Second project", "50.50").await;
    let upcoming = c.payment(&p, "Upcoming", "10.10", 10).await;
    let due = c.payment(&p, "Due today", "20.20", 0).await;
    let overdue = c.payment(&p, "Overdue", "30.30", -5).await;
    let ontime = c.payment(&p, "On-time installment", "40.40", -10).await;
    let late = c.payment(&p2, "Late installment", "50.50", -10).await;
    assert_eq!(upcoming["status"], "UPCOMING");
    assert_eq!(due["status"], "DUE_TODAY");
    assert_eq!(overdue["status"], "OVERDUE");
    let settled = c
        .ok(
            "POST",
            &format!("/payments/{}/settlement", ontime["id"].as_str().unwrap()),
            json!({"version":1,"settlement_date":c.today-chrono::Duration::days(10)}),
        )
        .await;
    assert_eq!(settled["status"], "PAID_ON_TIME");
    let settled = c
        .ok(
            "POST",
            &format!("/payments/{}/settlement", late["id"].as_str().unwrap()),
            json!({"version":1,"settlement_date":c.today}),
        )
        .await;
    assert_eq!(settled["status"], "PAID_LATE");
    let detail = c
        .ok(
            "GET",
            &format!("/accounts/{}", a["id"].as_str().unwrap()),
            Value::Null,
        )
        .await;
    assert_eq!(detail["project_count"], 2);
    assert_eq!(detail["financial"][0]["scheduled"], "151.50");
    assert_eq!(detail["financial"][0]["paid"], "90.90");
    assert_eq!(detail["financial"][0]["outstanding"], "60.60");
    assert_eq!(detail["financial"][0]["overdue"], "30.30");
    assert_eq!(detail["credit_health"]["historical_late_count"], 1);
    let pd = c
        .ok(
            "GET",
            &format!("/projects/{}", p["id"].as_str().unwrap()),
            Value::Null,
        )
        .await;
    assert_eq!(pd["schedule_matches_contract"], false);
    assert_eq!(pd["schedule_difference"], "1.00");
    let (_, filtered) = c
        .send("GET", "/payments?status=OVERDUE&page_size=1", Value::Null)
        .await;
    assert_eq!(filtered["meta"]["total"], 1);
    assert_eq!(filtered["data"][0]["id"], overdue["id"]);
    let dashboard = c.ok("GET", "/dashboard", Value::Null).await;
    assert_eq!(dashboard["total_accounts"], 1);
    assert_eq!(dashboard["active_projects"], 2);
    assert_eq!(dashboard["payment_status_counts"]["PAID_LATE"], 1);
    let correction=c.ok("POST",&format!("/payments/{}/corrections",late["id"].as_str().unwrap()),json!({"version":2,"reason":"Settlement entered against the wrong obligation","title":"Late installment corrected","amount":"50.50","due_date":late["due_date"],"settlement_date":null})).await;
    assert_eq!(correction["status"], "OVERDUE");
    assert_eq!(correction["version"], 3);
    let history = c
        .ok(
            "GET",
            &format!("/payments/{}/history", late["id"].as_str().unwrap()),
            Value::Null,
        )
        .await;
    assert_eq!(history.as_array().unwrap().len(), 3);
    assert_eq!(history[0]["action"], "corrected");
    assert_eq!(history[0]["before"]["settlement_date"], c.today.to_string());
    assert_eq!(history[1]["action"], "settled");
    assert!(
        sqlx::query("UPDATE audit_events SET reason='tampered'")
            .execute(&db)
            .await
            .is_err()
    );
}
#[sqlx::test]
async fn validation_concurrency_and_archive(db: PgPool) {
    let c = Client::new(db.clone()).await;
    let a = c.account("A searchable client").await;
    let p = c.project(&a, "Precision", "1.00").await;
    for amount in ["0", "-1", "1.001", "1e2", "100000000000000000.00"] {
        assert_eq!(c.send("POST","/payments",json!({"project_id":p["id"],"title":"Invalid","amount":amount,"currency":"USD","due_date":c.today})).await.0,422);
    }
    assert_eq!(c.send("POST","/payments",json!({"project_id":p["id"],"title":"Wrong currency","amount":"1.00","currency":"EUR","due_date":c.today})).await.0,422);
    assert_eq!(c.send("POST","/projects",json!({"account_id":a["id"],"name":"Invalid dates","description":"","contract_value":"1","currency":"USD","status":"active","start_date":c.today,"end_date":c.today-chrono::Duration::days(1)})).await.0,422);
    let payment = c.payment(&p, "Concurrent", "0.10", 0).await;
    let path = format!("/payments/{}/settlement", payment["id"].as_str().unwrap());
    assert_eq!(
        c.send(
            "POST",
            &path,
            json!({"version":1,"settlement_date":c.today+chrono::Duration::days(1)})
        )
        .await
        .0,
        422
    );
    let body = json!({"version":1,"settlement_date":c.today});
    let (first, second) = tokio::join!(
        c.send("POST", &path, body.clone()),
        c.send("POST", &path, body)
    );
    let mut codes = [first.0, second.0];
    codes.sort();
    assert_eq!(codes, [200, 409]);
    let count: i64 = sqlx::query_scalar(
        "SELECT count(*) FROM audit_events WHERE payment_id=$1 AND action='settled'",
    )
    .bind(payment["id"].as_str().unwrap().parse::<Uuid>().unwrap())
    .fetch_one(&db)
    .await
    .unwrap();
    assert_eq!(count, 1);
    let update = json!({"name":a["name"],"contact_name":a["contact_name"],"email":a["email"],"phone":a["phone"],"status":"archived","version":1,"reason":"Client relationship ended"});
    c.ok(
        "PATCH",
        &format!("/accounts/{}", a["id"].as_str().unwrap()),
        update.clone(),
    )
    .await;
    assert_eq!(
        c.send(
            "PATCH",
            &format!("/accounts/{}", a["id"].as_str().unwrap()),
            update
        )
        .await
        .0,
        409
    );
    let detail = c
        .ok(
            "GET",
            &format!("/accounts/{}", a["id"].as_str().unwrap()),
            Value::Null,
        )
        .await;
    assert_eq!(detail["financial"][0]["paid"], "0.10");
    assert_eq!(c.send("POST","/projects",json!({"account_id":a["id"],"name":"Blocked","description":"","contract_value":"1","currency":"USD","status":"active","start_date":c.today,"end_date":null})).await.0,422);
    let (_, list) = c
        .send(
            "GET",
            "/accounts?search=searchable&status=archived&page_size=1",
            Value::Null,
        )
        .await;
    assert_eq!(list["meta"]["total"], 1);
    assert_eq!(
        c.send("GET", "/payments?page_size=0", Value::Null).await.0,
        422
    );
    assert_eq!(
        c.send("GET", "/payments?status=INVALID", Value::Null)
            .await
            .0,
        422
    );
    assert_eq!(
        c.send("GET", "/accounts?credit_health=UNRATED", Value::Null)
            .await
            .1["meta"]["total"],
        1
    );
}
#[sqlx::test]
async fn unauthorized_access_and_atomic_audit_failure(db: PgPool) {
    let c = Client::new(db.clone()).await;
    for path in [
        "/accounts",
        "/projects",
        "/payments",
        "/dashboard",
        "/settings",
    ] {
        let response = c
            .app
            .clone()
            .oneshot(
                Request::builder()
                    .uri(format!("/api/v1{path}"))
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(response.status(), StatusCode::UNAUTHORIZED);
    }
    let response = c
        .app
        .clone()
        .oneshot(
            Request::builder()
                .method("POST")
                .uri("/api/v1/accounts")
                .header("cookie", &c.cookie)
                .header("origin", "http://localhost:5173")
                .header("content-type", "application/json")
                .body(Body::from("{}"))
                .unwrap(),
        )
        .await
        .unwrap();
    assert_eq!(response.status(), StatusCode::FORBIDDEN);
    let a = c.account("Rollback fixture").await;
    let p = c.project(&a, "Rollback", "100").await;
    let payment = c.payment(&p, "Rollback obligation", "100", -1).await;
    sqlx::raw_sql("CREATE FUNCTION reject_test_settlement() RETURNS trigger LANGUAGE plpgsql AS $$ BEGIN IF NEW.action='settled' THEN RAISE EXCEPTION 'test audit failure'; END IF; RETURN NEW; END; $$; CREATE TRIGGER reject_settlement BEFORE INSERT ON audit_events FOR EACH ROW EXECUTE FUNCTION reject_test_settlement();").execute(&db).await.unwrap();
    assert_eq!(
        c.send(
            "POST",
            &format!("/payments/{}/settlement", payment["id"].as_str().unwrap()),
            json!({"version":1,"settlement_date":c.today})
        )
        .await
        .0,
        500
    );
    let detail = c
        .ok(
            "GET",
            &format!("/payments/{}", payment["id"].as_str().unwrap()),
            Value::Null,
        )
        .await;
    assert_eq!(detail["settlement_date"], Value::Null);
    assert_eq!(detail["version"], 1);
    assert!(sqlx::query("INSERT INTO scheduled_payments(id,project_id,title,amount,currency,due_date) VALUES($1,$2,'Invalid',0,'USD',current_date)").bind(Uuid::new_v4()).bind(p["id"].as_str().unwrap().parse::<Uuid>().unwrap()).execute(&db).await.is_err());
    assert!(sqlx::query("INSERT INTO scheduled_payments(id,project_id,title,amount,currency,due_date) VALUES($1,$2,'Orphan',1,'USD',current_date)").bind(Uuid::new_v4()).bind(Uuid::new_v4()).execute(&db).await.is_err());
}
