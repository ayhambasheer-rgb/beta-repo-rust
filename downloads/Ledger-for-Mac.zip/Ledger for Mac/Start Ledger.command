#!/bin/bash
source "$(cd "$(dirname "$0")" && pwd)/scripts/mac-common.sh"
printf 'Starting Ledger — Rust, React, and PostgreSQL\n\n'
ledger_docker
if [ ! -e "$LEDGER_CONFIG" ]; then
    # Refuse a new password if a previous database still exists.
    if docker volume inspect ledger-mac_postgres_data >/dev/null 2>&1; then
        printf 'An existing Ledger database was found, but its configuration is missing.\n'
        printf 'Restore the original app folder and its .local folder before continuing.\n'
        ledger_error
    fi
    mkdir -p "$LEDGER_ROOT/.local"
    chmod 700 "$LEDGER_ROOT/.local"
    LEDGER_NEW_PASSWORD="$(openssl rand -hex 32)"
    (set -o noclobber; printf 'POSTGRES_PASSWORD=%s\n' "$LEDGER_NEW_PASSWORD" > "$LEDGER_CONFIG")
    unset LEDGER_NEW_PASSWORD
fi
ledger_config
printf 'The first start downloads and builds the app. This can take several minutes.\n'
printf 'Please leave this window open until your browser appears.\n\n'
ledger_compose up -d --build --wait --wait-timeout 1200 </dev/null
LEDGER_ADMIN_COUNT="$(ledger_compose exec -T db psql -U payment -d payment_health -Atc 'SELECT count(*) FROM admin_users WHERE active=true' </dev/null)"
if [ "$LEDGER_ADMIN_COUNT" = 0 ]; then
    printf '\nLet us create your login. Choose an email and remember your password.\n'
    while true; do
        read -r -p 'Your email address: ' ADMIN_EMAIL
        case "$ADMIN_EMAIL" in
            *@*) if [ "${#ADMIN_EMAIL}" -le 254 ]; then break; fi ;;
        esac
        printf 'Please enter an email address containing @ (up to 254 characters).\n'
    done
    while true; do
        read -r -s -p 'Choose a password (at least 12 characters): ' ADMIN_PASSWORD
        printf '\n'
        read -r -s -p 'Enter the password again: ' LEDGER_CONFIRM
        printf '\n'
        LEDGER_PASSWORD_BYTES="$(printf '%s' "$ADMIN_PASSWORD" | wc -c | tr -d ' ')"
        if [ "$LEDGER_PASSWORD_BYTES" -ge 12 ] && [ "$LEDGER_PASSWORD_BYTES" -le 1024 ] && \
            [ "$ADMIN_PASSWORD" = "$LEDGER_CONFIRM" ]; then
            break
        fi
        printf 'Passwords must match and contain at least 12 characters (maximum 1024 bytes).\n'
    done
    unset LEDGER_CONFIRM LEDGER_PASSWORD_BYTES
    export ADMIN_EMAIL ADMIN_PASSWORD
    ledger_compose run --rm --no-deps -T -e ADMIN_EMAIL -e ADMIN_PASSWORD api provision-admin </dev/null
    unset ADMIN_EMAIL ADMIN_PASSWORD
fi
printf '\nLedger is ready. Sign in with the email and password you chose.\n'
if [ "$(uname -s)" = Darwin ]; then
    open 'http://localhost:8787'
else
    printf 'Open localhost port 8787 in a browser on this computer.\n'
fi
printf 'You can close this window. To stop the app, use Stop Ledger.command.\n'
ledger_pause
