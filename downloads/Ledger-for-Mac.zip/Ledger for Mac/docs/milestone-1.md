# Milestone 1: Foundation and administrator access

Historical milestone report. Later milestones are now implemented; see README and validation.md for current capabilities.

## Approved scope

Prepare Rust/Axum, PostgreSQL migrations, a React/Vite/TypeScript application shell, and secure administrator login/logout. Do not implement account, project, payment, or credit-health workflows in this milestone.

## Acceptance criteria

- API startup connects to PostgreSQL and applies migrations safely.
- Readiness checks query the database.
- Administrator provisioning hashes passwords and rejects duplicate accounts.
- Unauthenticated, expired, and revoked sessions cannot retrieve administrator data.
- Login uses generic credential errors, rate limits, and origin verification.
- Logout requires CSRF verification and revokes the session.
- Frontend signs in, restores the tab's session, navigates the shell, and signs out.
- Desktop and mobile layouts contain accessible labels, loading feedback, and errors.
- Backend and frontend builds and relevant automated tests pass.

## Decisions carried forward

- Configurable business timezone, initially Asia/Amman.
- Single-business administrator access, with no public registration.
- One PostgreSQL database and one Rust backend.
- No sample or fabricated financial data.
- Currency must be selected before implementing financial records.
- The approved credit policy remains a future milestone; it is not represented as an official credit score.

## Implementation boundaries

Migrations currently create administrator and session tables only. Domain tables will arrive with their vertical slices. The shell's Accounts, Projects, and Payments sections explicitly explain that those workflows are forthcoming. Production reverse-proxy deployment and financial data backup/restore exercises remain later work.

## Validation

Milestone validation uses a real local PostgreSQL 17 instance, an isolated SQLx test database, component tests, and a Chromium end-to-end test against running Vite and Axum servers. See README for repeatable commands. Test credentials are local, randomly generated, and excluded from source control.

Verified results in this development instance:

- Backend build, formatting, and Clippy with warnings denied: passed.
- Rust tests: 3 passed, including a real-PostgreSQL session/security integration test.
- Frontend production build and TypeScript check: passed.
- React component tests: 2 passed.
- Chromium end-to-end test: 1 passed.
- npm audit after updating Vitest to 4.1.11: zero reported vulnerabilities.
- Live API readiness: database query succeeded, timezone Asia/Amman.

These results do not establish production deployment or completion of later milestones.
