# Local macOS package validation

The package keeps the Rust, React, and PostgreSQL application unchanged. Docker Desktop supplies the local runtime; an Nginx container serves the built React frontend and forwards API requests. No developer tool installation is required on the user's Mac.

Validated in the Linux amd64 cloud machine with Docker 28.4.0:

- Built the release Rust API and production React assets from the packaged sources and frozen lockfiles. The frontend install reported zero vulnerabilities.
- Started the Finder launcher's Bash script from an extracted folder containing spaces; generated a private local database configuration and provisioned an administrator through the prompts. Invalid email, short password, and mismatched password inputs were rejected.
- Verified the actual database health request through the web proxy. Only the web service publishes a host port, bound to `127.0.0.1:8787`; API and PostgreSQL have no published ports.
- Both existing Chromium browser tests passed through the packaged web service: authentication/session restoration/navigation/logout, and accounts/projects/payment scheduling/settlement/corrections/credit recovery.
- Ran the backup launcher, restored its dump into a separate temporary database, and reconciled administrator, account, project, payment, and audit counts plus the exact settled total.
- Ran stop and start launchers and confirmed all records and the existing administrator survived. An unrelated terminal database-password variable did not override the retained configuration.
- Removed the configuration temporarily and confirmed startup refused to generate a replacement password while the existing database volume remained intact.
- Checked that all base images publish both Linux amd64 and arm64 variants, and that the ZIP retains executable launcher permissions and excludes private configuration, backups, dependency caches, and generated test outputs.

Cloud container builds required a temporary proxy, host-resolution, and certificate-trust override. It is not shipped in the Mac download. The Dockerfiles accept an optional `build_ca` secret for build-time trust configuration; absent that secret, they use their standard certificate stores. TLS checks and package-signature verification were retained.

This validates the container workflow, not native macOS Finder execution, macOS Gatekeeper prompts, or a complete build on Apple silicon. Those have not been run in this cloud machine. The Mac guide explains the local launch and security prompts.
