# Internal payment-discipline policy v1

Approved during planning. Currency: USD. Business timezone: Asia/Amman by default, configurable. This is not a credit bureau score, external credit report, payment-processing system, or debt-collection tool.

## Inputs

The backend captures one business date for each assessment. It consolidates every project associated with an account, including archived projects. The inclusive recent window starts 365 days before that date and ends on that date. Future-due settlements are excluded from reliability and recovery, while remaining included in financial totals.

- Recent settled count and on-time rate, weighted by obligation count.
- Recent settlements after their due date.
- All currently unpaid overdue obligations, including older ones.
- Maximum outstanding days overdue.
- Overdue amount as a share of matured exposure, calculated separately per currency.
- Consecutive subsequent matured due-date groups paid on time.

Matured exposure includes all obligations due within the window plus older unpaid overdue obligations, each counted once. Currency amounts are never combined. All amount and threshold calculations use exact decimals.

## Classification precedence

Apply the first matching rule:

| Classification | Rule |
| --- | --- |
| POOR | Any obligation at least 30 days overdue; at least 3 overdue obligations; overdue share at least 25% in any currency; or at least 3 recent late settlements with a late rate at least 40% |
| AT_RISK | Any other unresolved overdue obligation |
| HEALTHY | Historical recent lateness exists, debt is clear, at least 6 subsequent on-time due-date groups, and on-time rate at least 90% |
| RECOVERING | Historical recent lateness exists, debt is clear, and at least 3 subsequent on-time due-date groups |
| AT_RISK | Other recent historical lateness |
| UNRATED | No recent lateness or overdue debt, fewer than 3 matured settlements |
| HEALTHY | At least 3 matured settlements, all recent settlements on time, and no overdue debt |

Severe-risk rules take precedence over recovery. For example, three late settlements followed by three on-time groups remain POOR because the late rate is still 50%; additional on-time history can bring that rate below 40% and permit recovery.

Recovery groups must follow the most recent late obligation's due date. Multiple obligations on one due date count as one group, and every obligation in the group must be on time. An unfinished due-today group does not advance or break the prior streak until its deadline passes. Settling an overdue obligation preserves its due/settlement-date comparison. Earlier late settlements outside the window remain visible in lifetime history.

Every assessment includes classification, policy version, business date, window, numerical factors, reasons, currency-specific exposure, and contributing payment IDs. Corrections change current facts but never remove their prior values from audit history.

## Payment status

Paid status is evaluated first: settlement on/before due date is PAID_ON_TIME, otherwise PAID_LATE. Unsettled obligations are UPCOMING, DUE_TODAY, or OVERDUE according to the backend's business date. The browser displays these statuses and does not recalculate them.
