# REST API

Base: `/api/v1`. All business endpoints require an active administrator session. Mutations also require the exact configured Origin and the session's `X-CSRF-Token`. Monetary inputs and outputs are decimal strings with at most two decimal places. Dates are ISO dates; timestamps are RFC 3339 UTC.

## Endpoints

| Method | Path | Behavior |
| --- | --- | --- |
| GET | `/health` | Public database readiness |
| POST | `/auth/login` | Email/password JSON; Origin required; returns user/CSRF token and sets cookie |
| GET | `/auth/me` | Current administrator |
| POST | `/auth/logout` | Origin/CSRF required; revoke cookie session |
| GET | `/settings` | Business currency, timezone, date, and monetary precision |
| GET, POST | `/accounts` | Paginated list / create |
| GET, PATCH | `/accounts/{id}` | Consolidated detail / edit or archive |
| GET | `/accounts/{id}/payments` | Paginated consolidated payment history |
| GET | `/accounts/{id}/credit-health` | Current assessment |
| GET | `/accounts/{id}/history` | Audited account changes |
| GET, POST | `/projects` | Paginated list / create under an account |
| GET, PATCH | `/projects/{id}` | Financial detail / edit or archive |
| GET | `/projects/{id}/history` | Audited project and contract changes |
| GET, POST | `/payments` | Paginated list / schedule an obligation |
| GET | `/payments/{id}` | Current payment facts and calculated status |
| POST | `/payments/{id}/settlement` | Full settlement with date and expected version |
| POST | `/payments/{id}/corrections` | Correct facts with a required reason and expected version |
| GET | `/payments/{id}/history` | Audited scheduling, settlement, and corrections |
| GET | `/dashboard` | Counts, currency totals, attention accounts, schedule, and activity |

No hard-delete API exists. Archiving preserves obligations and history. Projects cannot be reassigned to other accounts; payments cannot be reassigned to other projects or currencies.

## Request fields

- Create account: `name`, `contact_name`, `email`, `phone`, `status` (`active` or `archived`).
- Edit account: all editable fields above, plus `version`, `reason`.
- Create project: `account_id`, `name`, `description`, `contract_value`, `currency`, `status`, `start_date`, nullable `end_date`.
- Edit project: all editable fields except account/currency, plus `version`, `reason`.
- Project statuses: `planned`, `active`, `completed`, `archived`.
- Schedule payment: `project_id`, `title`, `amount`, `currency`, `due_date`.
- Settle: `version`, `settlement_date`.
- Correct: `version`, `reason`, `title`, `amount`, `due_date`, explicitly nullable `settlement_date`.

PATCH operations accept the complete editable representation. They do not silently default omitted required fields. Settlement dates cannot be in the future. Deposits and historical obligations may precede project start dates.

## Listing

Common pagination: `page` (default 1), `page_size` (default 20, maximum 100). Search is case-insensitive.

- Accounts: `search`, `status`, `credit_health`.
- Projects: `search`, `status`, `account_id`.
- Payments: `search`, `status`, `settlement_status` (`settled`/`unpaid`), `account_id`, `project_id`, `date_from`, `date_to` (inclusive due-date range).

Payment statuses: UPCOMING, DUE_TODAY, OVERDUE, PAID_ON_TIME, PAID_LATE. Health classifications: HEALTHY, AT_RISK, RECOVERING, POOR, UNRATED. Unsupported statuses and malformed identifiers return 422.

Lists return `{ "data": [], "meta": { "page", "page_size", "total" }, "business_date" }`. Other JSON successes use `{ "data": ... }`, with business date where relevant. Creation returns 201; logout returns 204. Errors use `{ "error": { "code", "message", "request_id" } }` with 401, 403, 404, 409, 413, 415, 422, 429, or 500 as appropriate. Conflicting versions and repeated settlements return 409.

## Financial consistency

Settlement/correction operations lock the payment, validate its expected version, update facts, and append an audit event in one transaction. Failure to append history rolls back the payment change. Account and project changes are likewise audited. The database rejects orphaned relationships, nonpositive payments, and mismatched project/payment currencies. Audit events reject UPDATE and DELETE.

Read totals and credit classifications are derived rather than manually editable. A configured currency cannot be changed while existing projects use another currency. Dashboard counts include retained archived history; active-project count includes only active projects.
