# MVP validation report

The user approved all remaining implementation milestones and selected USD. Milestones 2–6 are implemented in the current development workspace. Monetary precision is two decimal places; the configured business timezone is Asia/Amman.

## Verified results

| Check | Result |
| --- | --- |
| Rust tests | 17 passed, including real PostgreSQL integration tests |
| React component tests | 4 passed |
| Chromium end-to-end tests | 2 passed |
| Optimized Rust build | Passed (`cargo build --release --locked --jobs 2`) |
| Frontend production build and TypeScript | Passed |
| Clippy, Rust formatting, frontend formatting | Passed |
| Locked npm installation | Passed |
| npm audit | Zero reported vulnerabilities |
| Backup/restore | Fixture account/project/payment/audit counts and exact USD 180.00 settled total reconciled |
| Restricted runtime role | Read-only migration validation, authenticated reads, and transactional audited update passed; schema creation and audit UPDATE/DELETE privileges absent |
| Live optimized API | Readiness, login, all business reads, USD settings, logout, and unauthorized rejection passed |

## Scenarios exercised

- One account with multiple projects and multiple installments.
- All five payment statuses, including settlement before/on/after the due date.
- Business-date rollover under UTC and Asia/Amman.
- Exact cent arithmetic and values beyond JavaScript's safe integer range.
- Positive amounts, currency relationships, valid dates, and foreign keys.
- Concurrent settlements: one succeeds, the other conflicts; only one settlement event is recorded.
- Audit insertion failure rolls back payment changes.
- Corrections retain earlier settlement facts and a reason in append-only history.
- Archived accounts retain financial totals and reject new project creation.
- Unrated, poor, at-risk, recovering, and healthy assessments, historical-window boundaries, severe-risk precedence, same-day recovery groups, and currency-specific exposure.
- Real browser creation, settlement, correction, contract adjustment, cross-project recovery, filtered dashboard links, mobile layout, and logout.
- Missing migration metadata is rejected in read-only runtime mode.

## Data and process isolation

SQLx tests use temporary databases. Browser tests use a new local database and random administrator each run. They reconcile an independent restore, validate a restricted runtime role, and remove their own databases, roles, and services. No test business records remain in the application database. Private local runtime configuration and generated outputs are ignored by Git; credential values are not included in documentation or saved startup instructions.

## Remaining deployment work

The application is verified locally. Public hosting, domain/TLS configuration, production credentials, encrypted backup retention, and production recovery procedures are not provisioned. The Caddy template is documentation and has not been deployed or validated against a public hostname. Cloud configuration instructions are saved as a draft; publication and fresh-task restoration are separate platform operations.

The existing Milestone 1 document records its earlier acceptance gate; its reference to later features being pending is historical. README and this report describe the current implementation.
