#!/usr/bin/env python3
"""Load a private local configuration without displaying credential values."""
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
CONFIG = ROOT / '.local' / 'dev-config.json'
NAMES = ('DATABASE_URL', 'POSTGRES_PASSWORD', 'APP_ORIGIN', 'COOKIE_SECURE', 'BUSINESS_TIMEZONE', 'BUSINESS_CURRENCY', 'BIND_ADDRESS')
if sys.argv[1:] == ['--capture']:
    if not all(os.environ.get(name) for name in NAMES):
        raise SystemExit('Configure the variables documented in README before capturing local configuration.')
    CONFIG.parent.mkdir(mode=0o700, exist_ok=True)
    # Never overwrite an existing configuration or capture administrator passwords.
    fd = os.open(CONFIG, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'w') as file:
        json.dump({name: os.environ[name] for name in NAMES}, file)
    print('Private development configuration saved under .local (ignored by Git).')
else:
    if len(sys.argv) < 2:
        raise SystemExit('Usage: with-dev-env.py --capture | with-dev-env.py COMMAND [ARGUMENTS]')
    if not CONFIG.exists():
        raise SystemExit('No local configuration exists. Follow README and use --capture, or run commands with your own secure environment variables.')
    if not CONFIG.is_file() or CONFIG.is_symlink() or CONFIG.stat().st_mode & 0o077:
        raise SystemExit('Local configuration must be a private regular file (mode 600).')
    with CONFIG.open() as file:
        values = json.load(file)
    if set(values) != set(NAMES) or not all(isinstance(v, str) for v in values.values()):
        raise SystemExit('Local configuration has unexpected fields.')
    # Explicit bindings from the caller take precedence over retained local values.
    environment = {**values, **os.environ}
    os.chdir(ROOT)
    os.execvpe(sys.argv[1], sys.argv[1:], environment)
