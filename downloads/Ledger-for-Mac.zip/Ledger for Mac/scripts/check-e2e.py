#!/usr/bin/env python3
"""Run real browser checks against a disposable local Docker database."""
import json
import importlib.util
import os
from pathlib import Path
import secrets
import signal
import subprocess
import time
import urllib.parse
import urllib.request

ROOT = Path(__file__).resolve().parents[1]

def main():
    source = urllib.parse.urlsplit(os.environ['DATABASE_URL'])
    if source.hostname not in ('127.0.0.1', 'localhost') or source.port != 5432 or source.username != 'payment':
        raise SystemExit('Use the local Compose database (payment user, loopback port 5432), never production.')
    env = {**os.environ, 'POSTGRES_PASSWORD': os.environ.get('POSTGRES_PASSWORD') or urllib.parse.unquote(source.password or '')}
    container = subprocess.check_output(['docker', 'compose', 'ps', '-q', 'db'], cwd=ROOT, env=env, text=True).strip()
    if not container:
        raise SystemExit('Start the local Compose database first.')
    name = 'payment_health_e2e_' + secrets.token_hex(6)
    def sql(statement):
        subprocess.run(['docker', 'exec', container, 'psql', '-v', 'ON_ERROR_STOP=1', '-U', 'payment', '-d', 'postgres', '-c', statement], check=True, stdout=subprocess.DEVNULL)
    subprocess.run(['cargo', 'build', '--locked', '--manifest-path', 'backend/Cargo.toml'], cwd=ROOT, check=True)
    sql(f'CREATE DATABASE {name}')
    env.update(DATABASE_URL=urllib.parse.urlunsplit((source.scheme, source.netloc, '/' + name, '', '')),
               BUSINESS_CURRENCY='USD', BUSINESS_TIMEZONE='Asia/Amman', COOKIE_SECURE='false',
               APP_ORIGIN='http://localhost:5174', BIND_ADDRESS='127.0.0.1:3001',
               API_PROXY_TARGET='http://127.0.0.1:3001', E2E_BASE_URL='http://localhost:5174',
               ADMIN_EMAIL='e2e@example.test', ADMIN_PASSWORD=secrets.token_urlsafe(32))
    env['E2E_ADMIN_EMAIL'], env['E2E_ADMIN_PASSWORD'] = env['ADMIN_EMAIL'], env['ADMIN_PASSWORD']
    if Path('/usr/bin/chromium').exists():
        env.setdefault('PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH', '/usr/bin/chromium')
    processes = []
    logs = ROOT / '.local'
    logs.mkdir(mode=0o700, exist_ok=True)
    log_path = logs / 'e2e-server.log'
    log_fd = os.open(log_path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    try:
        subprocess.run(['backend/target/debug/payment-health-api', 'provision-admin'], cwd=ROOT, env=env, check=True)
        with os.fdopen(log_fd, 'w') as log:
            processes.append(subprocess.Popen(['backend/target/debug/payment-health-api'], cwd=ROOT, env=env, stdout=log, stderr=log, start_new_session=True))
            processes.append(subprocess.Popen(['npm', 'run', 'dev', '--prefix', 'frontend', '--', '--port', '5174'], cwd=ROOT, env=env, stdout=log, stderr=log, start_new_session=True))
            for _ in range(100):
                if any(p.poll() is not None for p in processes):
                    raise RuntimeError('A test server exited. See .local/e2e-server.log.')
                try:
                    with urllib.request.urlopen('http://localhost:5174/api/v1/health', timeout=1) as response:
                        if json.load(response)['data']['status'] == 'ok':
                            break
                except (OSError, ValueError):
                    pass
                time.sleep(.2)
            else:
                raise RuntimeError('Test services did not become ready. See .local/e2e-server.log.')
            subprocess.run(['npm', 'run', 'test:e2e', '--prefix', 'frontend'], cwd=ROOT, env=env, check=True)
            # Exercise backup/restore with this run's financial fixtures, not real records.
            restore_name = name + '_restore'
            backup_path = logs / 'e2e-backup.dump'
            backup_fd = os.open(backup_path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(backup_fd, 'wb') as backup:
                subprocess.run(['docker', 'exec', container, 'pg_dump', '-U', 'payment', '-Fc', name], stdout=backup, check=True)
            sql(f'CREATE DATABASE {restore_name}')
            try:
                with backup_path.open('rb') as backup:
                    subprocess.run(['docker', 'exec', '-i', container, 'pg_restore', '--exit-on-error', '--no-owner', '-U', 'payment', '-d', restore_name], stdin=backup, check=True)
                counts_query = "SELECT (SELECT count(*) FROM accounts), (SELECT count(*) FROM projects), (SELECT count(*) FROM scheduled_payments), (SELECT count(*) FROM audit_events), (SELECT sum(amount) FROM scheduled_payments WHERE settlement_date IS NOT NULL)"
                def counts(database):
                    return subprocess.check_output(['docker', 'exec', container, 'psql', '-U', 'payment', '-d', database, '-At', '-c', counts_query], text=True).strip()
                original, restored = counts(name), counts(restore_name)
                if original != restored or not original.startswith('1|2|10|') or not original.endswith('|180.00'):
                    raise RuntimeError('Backup/restore financial reconciliation failed.')
                print('Backup/restore: account, project, payment, audit counts and exact settled total reconciled.')
            finally:
                sql(f'DROP DATABASE {restore_name} WITH (FORCE)')
                backup_path.unlink(missing_ok=True)
            spec=importlib.util.spec_from_file_location('runtime_check',ROOT/'scripts'/'check-runtime-role.py')
            runtime_check=importlib.util.module_from_spec(spec)
            spec.loader.exec_module(runtime_check)
            runtime_check.verify(container,name,env,log_path)


    finally:
        for process in processes:
            try:
                os.killpg(process.pid, signal.SIGINT)
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                process.wait()
            except ProcessLookupError:
                pass
        sql(f'DROP DATABASE {name} WITH (FORCE)')

if __name__ == '__main__':
    main()
