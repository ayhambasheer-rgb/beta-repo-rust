#!/bin/bash
# Shared by the Finder launchers. Compatible with macOS's bundled Bash 3.2.
set -Eeuo pipefail
umask 077
LEDGER_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$LEDGER_ROOT"
export PATH="/Applications/Docker.app/Contents/Resources/bin:/usr/local/bin:/opt/homebrew/bin:$PATH"
LEDGER_CONFIG="$LEDGER_ROOT/.local/mac.env"

ledger_pause() {
    if [ -t 0 ]; then
        printf '\nPress Return to close this window. '
        read -r _ledger_reply || true
    fi
}
ledger_error() {
    trap - ERR
    printf '\nLedger could not complete this step. Your saved records have not been deleted.\n'
    printf 'Read the message above and the troubleshooting section in START HERE - macOS.txt.\n'
    ledger_pause
    exit 1
}
trap ledger_error ERR

ledger_docker() {
    if ! command -v docker >/dev/null 2>&1; then
        printf 'First install Docker Desktop for Mac from https://www.docker.com/products/docker-desktop/\n'
        printf 'Open Docker Desktop, finish its welcome screens, then run this launcher again.\n'
        ledger_pause
        exit 1
    fi
    if ! docker info >/dev/null 2>&1; then
        if [ "$(uname -s)" = Darwin ]; then
            open -a Docker || true
        fi
        printf 'Waiting for Docker Desktop to start (up to two minutes)...\n'
        local ledger_attempt=0
        until docker info >/dev/null 2>&1; do
            ledger_attempt=$((ledger_attempt + 1))
            if [ "$ledger_attempt" -ge 60 ]; then
                printf 'Open Docker Desktop, finish its welcome screens, and try again.\n'
                ledger_error
            fi
            sleep 2
        done
    fi
    docker compose version >/dev/null
}

ledger_config() {
    if [ ! -f "$LEDGER_CONFIG" ] || [ -L "$LEDGER_CONFIG" ]; then
        printf 'The saved local database configuration is missing. Run Start Ledger.command first.\n'
        ledger_error
    fi
    # Only one generated hexadecimal password is accepted; never execute this file.
    if [ "$(wc -l < "$LEDGER_CONFIG" | tr -d ' ')" != 1 ] || \
        ! LC_ALL=C grep -Eq '^POSTGRES_PASSWORD=[0-9a-f]{64}$' "$LEDGER_CONFIG"; then
        printf 'The saved database configuration is invalid. Do not replace it or reset the database.\n'
        ledger_error
    fi
    chmod 600 "$LEDGER_CONFIG"
    # An unrelated terminal variable must not override this installation's password.
    unset POSTGRES_PASSWORD
}

ledger_compose() {
    docker compose --project-name ledger-mac --env-file "$LEDGER_CONFIG" -f "$LEDGER_ROOT/compose.mac.yaml" "$@"
}
