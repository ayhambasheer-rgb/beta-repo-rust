#!/usr/bin/env python3
"""Verify a restricted role against a disposable database made by check-e2e."""
import json
import os
from pathlib import Path
import secrets
import signal
import subprocess
import time
import urllib.parse
import urllib.request


def verify(container, database, environment, log_path):
    role = 'ledger_runtime_' + secrets.token_hex(6)
    password = secrets.token_hex(32)
    def execute(sql, target='postgres'):
        # SQL through stdin keeps the temporary password out of process arguments.
        return subprocess.check_output(['docker', 'exec', '-i', container, 'psql', '-v', 'ON_ERROR_STOP=1', '-U', 'payment', '-d', target, '-At'], input=sql, text=True)
    execute(f"CREATE ROLE {role} LOGIN PASSWORD '{password}'; GRANT CONNECT ON DATABASE {database} TO {role};")
    process = None
    try:
        execute(f'''GRANT USAGE ON SCHEMA public TO {role};
GRANT SELECT ON admin_users, _sqlx_migrations TO {role};
GRANT SELECT,INSERT,DELETE ON sessions TO {role};
GRANT SELECT,INSERT,UPDATE ON accounts,projects,scheduled_payments TO {role};
GRANT SELECT,INSERT ON audit_events TO {role};''', database)
        permissions = execute(f"SELECT has_schema_privilege('{role}','public','CREATE'),has_table_privilege('{role}','audit_events','UPDATE'),has_table_privilege('{role}','audit_events','DELETE');", database).strip()
        if permissions != 'f|f|f':
            raise RuntimeError('Restricted runtime permissions are broader than expected.')
        source = urllib.parse.urlsplit(environment['DATABASE_URL'])
        runtime_url = urllib.parse.urlunsplit((source.scheme, f'{role}:{password}@127.0.0.1:5432', '/' + database, '', ''))
        env = {**environment, 'DATABASE_URL': runtime_url, 'MIGRATE_ON_START': 'false', 'BIND_ADDRESS': '127.0.0.1:3002'}
        root = Path(__file__).resolve().parents[1]
        with log_path.open('a') as log:
            process = subprocess.Popen(['backend/target/debug/payment-health-api'], cwd=root, env=env, stdout=log, stderr=log, start_new_session=True)
            for _ in range(100):
                if process.poll() is not None:
                    raise RuntimeError('Restricted runtime exited; inspect the private test server log.')
                try:
                    urllib.request.urlopen('http://127.0.0.1:3002/api/v1/health', timeout=1).close()
                    break
                except OSError:
                    time.sleep(.1)
            else:
                raise RuntimeError('Restricted runtime did not become ready.')
            origin = env['APP_ORIGIN']
            req = urllib.request.Request('http://127.0.0.1:3002/api/v1/auth/login', data=json.dumps({'email':env['ADMIN_EMAIL'],'password':env['ADMIN_PASSWORD']}).encode(), headers={'Origin':origin,'Content-Type':'application/json'})
            with urllib.request.urlopen(req) as response:
                cookie=response.headers['Set-Cookie'].split(';')[0]
                csrf=json.load(response)['data']['csrf_token']
            headers={'Cookie':cookie,'Origin':origin,'X-CSRF-Token':csrf,'Content-Type':'application/json'}
            with urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:3002/api/v1/accounts',headers=headers)) as response:
                body=json.load(response)
            if body['meta']['total'] != 1:
                raise RuntimeError('Restricted runtime could not read the fixture account.')
            account=body['data'][0]
            update={field:account[field] for field in ('name','contact_name','email','phone','status','version')}
            update['reason']='Restricted runtime authorization validation'
            req=urllib.request.Request(f"http://127.0.0.1:3002/api/v1/accounts/{account['id']}",method='PATCH',headers=headers,data=json.dumps(update).encode())
            with urllib.request.urlopen(req) as response:
                if response.status != 200:
                    raise RuntimeError('Restricted runtime could not append a transactional change.')
            print('Restricted runtime: read-only migration checks, authenticated reads and audited updates passed; schema creation and audit mutation privileges denied.')
    finally:
        if process is not None and process.poll() is None:
            os.killpg(process.pid,signal.SIGINT)
            try: process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(process.pid,signal.SIGKILL)
                process.wait()
        execute(f'DROP OWNED BY {role};',database)
        execute(f'DROP ROLE {role};')
